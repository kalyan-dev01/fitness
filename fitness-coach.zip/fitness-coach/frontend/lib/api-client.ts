const API_BASE_URL =
  process.env.NEXT_PUBLIC_API_BASE_URL ?? "http://localhost:8000/api";

export class ApiError extends Error {
  status: number;
  detail: string;

  constructor(status: number, detail: string) {
    super(detail);
    this.status = status;
    this.detail = detail;
  }
}

async function request<T>(
  path: string,
  options: RequestInit = {}
): Promise<T> {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    credentials: "include", // send/receive the HTTP-only session cookie
    headers: {
      "Content-Type": "application/json",
      ...(options.headers ?? {}),
    },
  });

  if (!res.ok) {
    let detail = res.statusText;
    try {
      const body = await res.json();
      detail = body.detail ?? detail;
    } catch {
      // response wasn't JSON — fall back to statusText
    }
    throw new ApiError(res.status, detail);
  }

  if (res.status === 204) {
    return undefined as T;
  }
  return (await res.json()) as T;
}

export interface UserOut {
  id: string;
  email: string;
  is_active: boolean;
}

export interface ProfileOut {
  id: string;
  user_id: string;
  name: string | null;
  age: number | null;
  sex: "MALE" | "FEMALE" | "OTHER" | null;
  height_cm: number | null;
  activity_level: string | null;
  training_frequency: number | null;
  dietary_preferences: string[] | null;
  foods_to_avoid: string[] | null;
  notes: string | null;
}

export interface FoodServingOut {
  id: string;
  unit: string;
  raw_cooked: "RAW" | "COOKED" | "NA";
  calories: number;
  protein_g: number;
  carbs_g: number;
  fat_g: number;
}

export interface FoodOut {
  id: string;
  name: string;
  brand: string | null;
  is_verified: boolean;
  default_unit: string;
  servings: FoodServingOut[];
}

export interface MealItemInput {
  food_id?: string;
  custom_food_id?: string;
  recipe_id?: string;
  quantity: number;
  unit: string;
  raw_cooked?: "RAW" | "COOKED" | "NA";
}

export interface MealOut {
  id: string;
  date: string;
  meal_type: string;
  items: Array<{
    id: string;
    label_snapshot: string;
    quantity: number;
    unit: string;
    raw_cooked: string;
    calories_snapshot: number;
    protein_snapshot: number;
    carbs_snapshot: number;
    fat_snapshot: number;
  }>;
}

export interface DailyNutritionSummary {
  date: string;
  calories: number;
  protein_g: number;
  carbs_g: number;
  fat_g: number;
  meals: MealOut[];
}

export interface WeightEntryOut {
  id: string;
  date: string;
  weight_kg: number;
  time_of_day: string | null;
  source: string | null;
  note: string | null;
}

export interface WeightTrendOut {
  latest_kg: number | null;
  latest_date: string | null;
  change_from_previous_kg: number | null;
  seven_day_avg_kg: number | null;
  thirty_day_avg_kg: number | null;
  thirty_day_change_kg: number | null;
  goal_weight_kg: number | null;
}

export interface WaterDailyOut {
  date: string;
  total_ml: number;
  target_ml: number | null;
  entries: Array<{ id: string; ml: number; logged_at: string }>;
}

export interface ExerciseOut {
  id: string;
  name: string;
  muscle_group: string;
  is_custom: boolean;
}

export interface ExerciseSetInput {
  weight_kg: number;
  reps: number;
  rpe?: number;
  rir?: number;
}

export interface WorkoutSessionOut {
  id: string;
  date: string;
  notes: string | null;
  exercises: Array<{
    id: string;
    exercise_id: string;
    sets: Array<{
      id: string;
      set_number: number;
      weight_kg: number;
      reps: number;
      is_pr: boolean;
    }>;
  }>;
}

export interface ProgressionOut {
  status: string;
  suggested_next_weight_kg: number | null;
  reasoning: string;
}

export interface AIProviderOut {
  id: string;
  name: string;
  display_name: string;
  base_url: string | null;
  model: string | null;
  is_enabled: boolean;
  is_free_only: boolean;
  priority: number;
  auto_fallback_enabled: boolean;
  key_hint: string | null;
  health: {
    status: string;
    last_tested_at: string | null;
    last_latency_ms: number | null;
    last_error_category: string | null;
  } | null;
}

export interface TestConnectionOut {
  success: boolean;
  model: string | null;
  latency_ms: number | null;
  error_category: string | null;
  error_message: string | null;
}

export interface AIMessageOut {
  id: string;
  role: string;
  content: string;
  provider_name: string | null;
  model: string | null;
  created_at: string;
}

export interface AIConversationOut {
  id: string;
  title: string | null;
  messages: AIMessageOut[];
}

export interface CoachMessageOut {
  conversation_id: string;
  reply: string;
  provider_name: string | null;
  model: string | null;
  ai_unavailable: boolean;
}

export interface ParsedFoodItem {
  raw_name: string;
  quantity: number;
  unit: string;
  raw_cooked: string;
  matched_food_id: string | null;
  matched_food_name: string | null;
  is_verified: boolean | null;
  calories: number | null;
  protein_g: number | null;
  carbs_g: number | null;
  fat_g: number | null;
  needs_manual_match: boolean;
}

export interface DailyReviewOut {
  date: string;
  calories: number;
  protein_g: number;
  carbs_g: number;
  fat_g: number;
  calorie_target: number | null;
  protein_target_g: number | null;
  water_ml: number;
  workout_logged: boolean;
  weight_kg: number | null;
  review_text: string;
  ai_unavailable: boolean;
}

export interface WeeklyReportOut {
  id: string | null;
  week_start: string;
  week_end: string;
  avg_calories: number;
  avg_protein_g: number;
  calorie_target: number | null;
  protein_target_g: number | null;
  workouts_logged: number;
  avg_water_ml: number;
  weight_change_kg: number | null;
  latest_weight_kg: number | null;
  goal_type: string | null;
  conclusion: string;
  next_week_targets: Record<string, unknown>;
  ai_unavailable: boolean;
}

export interface SeriesPoint {
  date: string;
  value: number;
}

export interface ProgressPhotoOut {
  id: string;
  date: string;
  angle: "FRONT" | "SIDE" | "BACK";
  notes: string | null;
  content_type: string;
}

export interface NotificationSettingsOut {
  remind_log_weight: boolean;
  remind_drink_water: boolean;
  remind_workout: boolean;
  remind_log_meals: boolean;
  remind_weekly_report: boolean;
}

export interface ExerciseVolumePoint {
  date: string;
  volume: number;
}

export interface ExerciseStrengthPoint {
  date: string;
  best_weight_kg: number;
}

export const API_BASE = API_BASE_URL;

export const api = {
  auth: {
    register: (email: string, password: string) =>
      request<UserOut>("/auth/register", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      }),
    login: (email: string, password: string) =>
      request<UserOut>("/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      }),
    logout: () => request<void>("/auth/logout", { method: "POST" }),
    me: () => request<UserOut>("/auth/me"),
  },
  profile: {
    get: () => request<ProfileOut>("/profile"),
    update: (payload: Partial<ProfileOut>) =>
      request<ProfileOut>("/profile", {
        method: "PUT",
        body: JSON.stringify(payload),
      }),
  },
  foods: {
    search: (q: string) =>
      request<FoodOut[]>(`/foods?q=${encodeURIComponent(q)}`),
  },
  meals: {
    create: (payload: {
      date: string;
      meal_type: string;
      items: MealItemInput[];
    }) =>
      request<MealOut>("/meals", {
        method: "POST",
        body: JSON.stringify(payload),
      }),
    delete: (id: string) =>
      request<void>(`/meals/${id}`, { method: "DELETE" }),
  },
  nutrition: {
    daily: (date: string) =>
      request<DailyNutritionSummary>(`/nutrition/daily?date=${date}`),
  },
  weight: {
    list: () => request<WeightEntryOut[]>("/weight"),
    log: (payload: { date: string; weight_kg: number; source?: string; note?: string }) =>
      request<WeightEntryOut>("/weight", {
        method: "POST",
        body: JSON.stringify(payload),
      }),
    delete: (id: string) => request<void>(`/weight/${id}`, { method: "DELETE" }),
    trend: () => request<WeightTrendOut>("/weight/trend"),
  },
  water: {
    log: (date: string, ml: number) =>
      request<void>("/water", { method: "POST", body: JSON.stringify({ date, ml }) }),
    daily: (date: string) => request<WaterDailyOut>(`/water/daily?date=${date}`),
  },
  exercises: {
    list: () => request<ExerciseOut[]>("/exercises"),
  },
  workouts: {
    list: () => request<WorkoutSessionOut[]>("/workouts"),
    log: (payload: {
      date: string;
      exercises: Array<{ exercise_id: string; sets: ExerciseSetInput[] }>;
    }) =>
      request<WorkoutSessionOut>("/workouts", {
        method: "POST",
        body: JSON.stringify(payload),
      }),
    delete: (id: string) => request<void>(`/workouts/${id}`, { method: "DELETE" }),
  },
  progression: {
    suggestion: (exerciseId: string) =>
      request<ProgressionOut>(`/progression/exercises/${exerciseId}/suggestion`),
  },
  aiProviders: {
    list: () => request<AIProviderOut[]>("/ai/providers"),
    create: (payload: {
      name: string;
      api_key: string;
      model?: string;
      base_url?: string;
    }) =>
      request<AIProviderOut>("/ai/providers", {
        method: "POST",
        body: JSON.stringify(payload),
      }),
    update: (id: string, payload: Partial<{ is_enabled: boolean; auto_fallback_enabled: boolean; priority: number }>) =>
      request<AIProviderOut>(`/ai/providers/${id}`, {
        method: "PUT",
        body: JSON.stringify(payload),
      }),
    delete: (id: string) => request<void>(`/ai/providers/${id}`, { method: "DELETE" }),
    test: (id: string) =>
      request<TestConnectionOut>(`/ai/providers/${id}/test`, { method: "POST" }),
  },
  coach: {
    send: (message: string, conversationId?: string) =>
      request<CoachMessageOut>("/coach/message", {
        method: "POST",
        body: JSON.stringify({ message, conversation_id: conversationId }),
      }),
    getConversation: (id: string) =>
      request<AIConversationOut>(`/coach/conversations/${id}`),
    listConversations: () => request<AIConversationOut[]>("/coach/conversations"),
    parseFood: (text: string) =>
      request<{ items: ParsedFoodItem[]; ai_unavailable: boolean }>("/coach/parse-food", {
        method: "POST",
        body: JSON.stringify({ text }),
      }),
  },
  reports: {
    daily: () => request<DailyReviewOut>("/reports/daily"),
    weekly: () => request<WeeklyReportOut>("/reports/weekly"),
    weeklyHistory: () => request<WeeklyReportOut[]>("/reports/weekly/history"),
  },
  analytics: {
    weight: (days = 90) => request<{ points: SeriesPoint[] }>(`/analytics/weight?days=${days}`),
    nutrition: (days = 30) =>
      request<{ calories: SeriesPoint[]; protein: SeriesPoint[] }>(
        `/analytics/nutrition?days=${days}`
      ),
    workoutVolume: (exerciseId: string, days = 90) =>
      request<{ exercise_name: string; points: ExerciseVolumePoint[] }>(
        `/analytics/workout-volume/${exerciseId}?days=${days}`
      ),
    strength: (exerciseId: string, days = 180) =>
      request<{ exercise_name: string; points: ExerciseStrengthPoint[] }>(
        `/analytics/strength/${exerciseId}?days=${days}`
      ),
  },
  progressPhotos: {
    list: () => request<ProgressPhotoOut[]>("/progress-photos"),
    upload: async (file: File, date: string, angle: string, notes?: string) => {
      const form = new FormData();
      form.append("file", file);
      form.append("date", date);
      form.append("angle", angle);
      if (notes) form.append("notes", notes);
      const res = await fetch(`${API_BASE_URL}/progress-photos`, {
        method: "POST",
        credentials: "include",
        body: form,
      });
      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new ApiError(res.status, body.detail ?? res.statusText);
      }
      return (await res.json()) as ProgressPhotoOut;
    },
    imageUrl: (id: string) => `${API_BASE_URL}/progress-photos/${id}/image`,
    delete: (id: string) => request<void>(`/progress-photos/${id}`, { method: "DELETE" }),
  },
  notificationSettings: {
    get: () => request<NotificationSettingsOut>("/notification-settings"),
    update: (payload: Partial<NotificationSettingsOut>) =>
      request<NotificationSettingsOut>("/notification-settings", {
        method: "PUT",
        body: JSON.stringify(payload),
      }),
  },
  export: {
    downloadUrl: () => `${API_BASE_URL}/export/data`,
  },
};
