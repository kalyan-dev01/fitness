"use client";

import { useEffect, useState } from "react";
import { api, NotificationSettingsOut, ProfileOut } from "@/lib/api-client";

const ACTIVITY_LEVELS = [
  "SEDENTARY",
  "LIGHT",
  "MODERATE",
  "ACTIVE",
  "VERY_ACTIVE",
] as const;

export default function SettingsPage() {
  const [profile, setProfile] = useState<ProfileOut | null>(null);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<number | null>(null);

  const [notifSettings, setNotifSettings] = useState<NotificationSettingsOut | null>(null);
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    api.profile.get().then(setProfile);
    api.notificationSettings.get().then(setNotifSettings);
    setIsDark(document.documentElement.classList.contains("dark"));
  }, []);

  function toggleTheme() {
    const next = !isDark;
    setIsDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("theme", next ? "dark" : "light");
  }

  async function toggleNotification(key: keyof NotificationSettingsOut) {
    if (!notifSettings) return;
    const updated = await api.notificationSettings.update({
      [key]: !notifSettings[key],
    });
    setNotifSettings(updated);
  }

  async function downloadExport() {
    const res = await fetch(api.export.downloadUrl(), { credentials: "include" });
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `fitness-coach-export-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  useEffect(() => {
    api.profile.get().then(setProfile);
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!profile) return;
    setSaving(true);
    try {
      const updated = await api.profile.update({
        name: profile.name,
        age: profile.age,
        sex: profile.sex,
        height_cm: profile.height_cm,
        activity_level: profile.activity_level,
        training_frequency: profile.training_frequency,
      });
      setProfile(updated);
      setSavedAt(Date.now());
    } finally {
      setSaving(false);
    }
  }

  if (!profile) {
    return <p className="text-sm text-neutral-400">Loading…</p>;
  }

  return (
    <div className="max-w-lg">
      <h1 className="mb-6 text-xl font-semibold">Profile</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="mb-1 block text-sm font-medium">Name</label>
          <input
            value={profile.name ?? ""}
            onChange={(e) => setProfile({ ...profile, name: e.target.value })}
            className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="mb-1 block text-sm font-medium">Age</label>
            <input
              type="number"
              value={profile.age ?? ""}
              onChange={(e) =>
                setProfile({
                  ...profile,
                  age: e.target.value ? Number(e.target.value) : null,
                })
              }
              className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium">Sex</label>
            <select
              value={profile.sex ?? ""}
              onChange={(e) =>
                setProfile({
                  ...profile,
                  sex: (e.target.value || null) as ProfileOut["sex"],
                })
              }
              className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm"
            >
              <option value="">—</option>
              <option value="MALE">Male</option>
              <option value="FEMALE">Female</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="mb-1 block text-sm font-medium">Height (cm)</label>
            <input
              type="number"
              step="0.1"
              value={profile.height_cm ?? ""}
              onChange={(e) =>
                setProfile({
                  ...profile,
                  height_cm: e.target.value ? Number(e.target.value) : null,
                })
              }
              className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium">
              Training days/week
            </label>
            <input
              type="number"
              min={0}
              max={14}
              value={profile.training_frequency ?? ""}
              onChange={(e) =>
                setProfile({
                  ...profile,
                  training_frequency: e.target.value
                    ? Number(e.target.value)
                    : null,
                })
              }
              className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm"
            />
          </div>
        </div>

        <div>
          <label className="mb-1 block text-sm font-medium">
            Activity level
          </label>
          <select
            value={profile.activity_level ?? ""}
            onChange={(e) =>
              setProfile({
                ...profile,
                activity_level: e.target.value || null,
              })
            }
            className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm"
          >
            <option value="">—</option>
            {ACTIVITY_LEVELS.map((level) => (
              <option key={level} value={level}>
                {level.replace("_", " ").toLowerCase()}
              </option>
            ))}
          </select>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="rounded-lg bg-brand px-4 py-2 text-sm font-medium text-white hover:bg-brand-dark disabled:opacity-60"
        >
          {saving ? "Saving…" : "Save"}
        </button>
        {savedAt && (
          <span className="ml-3 text-sm text-neutral-400">Saved</span>
        )}
      </form>

      <div className="mt-8 rounded-xl border border-neutral-200 bg-white p-4">
        <h2 className="mb-3 text-sm font-semibold">Appearance</h2>
        <button
          onClick={toggleTheme}
          className="rounded-lg bg-neutral-100 px-4 py-2 text-sm font-medium text-neutral-700 hover:bg-neutral-200"
        >
          {isDark ? "Switch to light mode" : "Switch to dark mode"}
        </button>
      </div>

      {notifSettings && (
        <div className="mt-6 rounded-xl border border-neutral-200 bg-white p-4">
          <h2 className="mb-3 text-sm font-semibold">Notifications</h2>
          <p className="mb-3 text-xs text-neutral-400">
            These show as reminder banners while the app is open. They
            don't yet work as background push notifications when the app
            is closed.
          </p>
          <div className="space-y-2">
            {(
              [
                ["remind_log_weight", "Log weight"],
                ["remind_drink_water", "Drink water"],
                ["remind_workout", "Workout"],
                ["remind_log_meals", "Log meals"],
                ["remind_weekly_report", "Weekly report"],
              ] as const
            ).map(([key, label]) => (
              <label key={key} className="flex items-center justify-between text-sm">
                {label}
                <input
                  type="checkbox"
                  checked={notifSettings[key]}
                  onChange={() => toggleNotification(key)}
                  className="h-4 w-4 accent-brand"
                />
              </label>
            ))}
          </div>
        </div>
      )}

      <div className="mt-6 rounded-xl border border-neutral-200 bg-white p-4">
        <h2 className="mb-2 text-sm font-semibold">Data export</h2>
        <p className="mb-3 text-xs text-neutral-400">
          Download your nutrition, weight, workout, and AI conversation
          history as a JSON file.
        </p>
        <button
          onClick={downloadExport}
          className="rounded-lg bg-neutral-100 px-4 py-2 text-sm font-medium text-neutral-700 hover:bg-neutral-200"
        >
          Export my data
        </button>
      </div>
    </div>
  );
}
