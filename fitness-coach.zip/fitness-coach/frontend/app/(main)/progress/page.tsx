"use client";

import { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import {
  api,
  DailyReviewOut,
  ProgressPhotoOut,
  SeriesPoint,
  WeeklyReportOut,
  WeightEntryOut,
  WeightTrendOut,
} from "@/lib/api-client";

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

export default function ProgressPage() {
  const [entries, setEntries] = useState<WeightEntryOut[]>([]);
  const [trend, setTrend] = useState<WeightTrendOut | null>(null);
  const [chartPoints, setChartPoints] = useState<SeriesPoint[]>([]);
  const [weight, setWeight] = useState("");
  const [source, setSource] = useState("Gym");
  const [saving, setSaving] = useState(false);

  const [dailyReview, setDailyReview] = useState<DailyReviewOut | null>(null);
  const [loadingDaily, setLoadingDaily] = useState(false);
  const [weeklyReport, setWeeklyReport] = useState<WeeklyReportOut | null>(null);
  const [loadingWeekly, setLoadingWeekly] = useState(false);

  const [photos, setPhotos] = useState<ProgressPhotoOut[]>([]);
  const [photoAngle, setPhotoAngle] = useState("FRONT");
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  async function load() {
    const [list, t, chart] = await Promise.all([
      api.weight.list(),
      api.weight.trend(),
      api.analytics.weight(90),
    ]);
    setEntries(list);
    setTrend(t);
    setChartPoints(chart.points);
  }

  useEffect(() => {
    load();
    api.progressPhotos.list().then(setPhotos);
  }, []);

  async function handleLog(e: React.FormEvent) {
    e.preventDefault();
    if (!weight) return;
    setSaving(true);
    try {
      await api.weight.log({
        date: today(),
        weight_kg: Number(weight),
        source: source || undefined,
      });
      setWeight("");
      await load();
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    await api.weight.delete(id);
    await load();
  }

  async function loadDailyReview() {
    setLoadingDaily(true);
    try {
      setDailyReview(await api.reports.daily());
    } finally {
      setLoadingDaily(false);
    }
  }

  async function loadWeeklyReport() {
    setLoadingWeekly(true);
    try {
      setWeeklyReport(await api.reports.weekly());
    } finally {
      setLoadingWeekly(false);
    }
  }

  async function handlePhotoUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingPhoto(true);
    try {
      await api.progressPhotos.upload(file, today(), photoAngle);
      setPhotos(await api.progressPhotos.list());
    } finally {
      setUploadingPhoto(false);
      e.target.value = "";
    }
  }

  async function handleDeletePhoto(id: string) {
    await api.progressPhotos.delete(id);
    setPhotos(await api.progressPhotos.list());
  }

  return (
    <div className="max-w-xl">
      <h1 className="mb-6 text-xl font-semibold">Progress</h1>

      {trend && trend.latest_kg !== null && (
        <div className="mb-6 rounded-xl border border-neutral-200 bg-white p-4">
          <div className="flex items-baseline justify-between">
            <div>
              <div className="text-2xl font-semibold">{trend.latest_kg} kg</div>
              <div className="text-xs text-neutral-400">
                as of {trend.latest_date}
                {trend.change_from_previous_kg !== null &&
                  ` · ${trend.change_from_previous_kg > 0 ? "+" : ""}${trend.change_from_previous_kg}kg from last entry`}
              </div>
            </div>
            {trend.goal_weight_kg !== null && (
              <div className="text-right text-xs text-neutral-400">
                Goal
                <div className="text-sm font-medium text-neutral-700">
                  {trend.goal_weight_kg} kg
                </div>
              </div>
            )}
          </div>

          {chartPoints.length > 1 && (
            <div className="mt-3 h-32">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartPoints}>
                  <XAxis dataKey="date" hide />
                  <YAxis domain={["dataMin - 1", "dataMax + 1"]} hide />
                  <Tooltip
                    formatter={(v: number) => [`${v} kg`, "Weight"]}
                    labelFormatter={(d) => d}
                  />
                  <Line
                    type="monotone"
                    dataKey="value"
                    stroke="#16a34a"
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          <div className="mt-3 grid grid-cols-2 gap-3 border-t border-neutral-100 pt-3 text-sm">
            <div>
              <span className="text-neutral-400">7-day avg: </span>
              {trend.seven_day_avg_kg ?? "–"} kg
            </div>
            <div>
              <span className="text-neutral-400">30-day change: </span>
              {trend.thirty_day_change_kg ?? "–"} kg
            </div>
          </div>
        </div>
      )}

      <form
        onSubmit={handleLog}
        className="mb-6 flex items-end gap-3 rounded-xl border border-neutral-200 bg-white p-4"
      >
        <div className="flex-1">
          <label className="mb-1 block text-xs text-neutral-500">Weight (kg)</label>
          <input
            type="number"
            step="0.1"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            required
            className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm"
          />
        </div>
        <div className="flex-1">
          <label className="mb-1 block text-xs text-neutral-500">Source</label>
          <input
            value={source}
            onChange={(e) => setSource(e.target.value)}
            placeholder="Gym"
            className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm"
          />
        </div>
        <button
          type="submit"
          disabled={saving}
          className="rounded-lg bg-brand px-4 py-2 text-sm font-medium text-white hover:bg-brand-dark disabled:opacity-60"
        >
          Log
        </button>
      </form>

      <div className="mb-6 rounded-xl border border-neutral-200 bg-white">
        <h2 className="border-b border-neutral-100 px-4 py-3 text-sm font-semibold">
          History
        </h2>
        <ul className="divide-y divide-neutral-100">
          {entries.map((entry) => (
            <li key={entry.id} className="flex items-center justify-between px-4 py-3 text-sm">
              <div>
                <span className="font-medium">{entry.weight_kg} kg</span>
                <span className="ml-2 text-neutral-400">
                  {entry.date}
                  {entry.source && ` · ${entry.source}`}
                </span>
              </div>
              <button
                onClick={() => handleDelete(entry.id)}
                className="text-xs text-neutral-400 hover:text-red-600"
              >
                delete
              </button>
            </li>
          ))}
          {entries.length === 0 && (
            <li className="px-4 py-6 text-center text-sm text-neutral-400">
              No weight entries yet.
            </li>
          )}
        </ul>
      </div>

      <div className="mb-6 rounded-xl border border-neutral-200 bg-white p-4">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-sm font-semibold">Today's Review</h2>
          <button
            onClick={loadDailyReview}
            disabled={loadingDaily}
            className="text-xs font-medium text-brand-dark hover:underline disabled:opacity-60"
          >
            {loadingDaily ? "Loading…" : dailyReview ? "Refresh" : "Generate"}
          </button>
        </div>
        {dailyReview && (
          <div className="space-y-2 text-sm">
            <p className="whitespace-pre-line text-neutral-700">{dailyReview.review_text}</p>
            <div className="grid grid-cols-2 gap-2 border-t border-neutral-100 pt-2 text-xs text-neutral-500">
              <span>
                Calories: {dailyReview.calories}
                {dailyReview.calorie_target ? ` / ${dailyReview.calorie_target}` : ""}
              </span>
              <span>
                Protein: {dailyReview.protein_g}g
                {dailyReview.protein_target_g ? ` / ${dailyReview.protein_target_g}g` : ""}
              </span>
              <span>Water: {(dailyReview.water_ml / 1000).toFixed(1)}L</span>
              <span>Workout: {dailyReview.workout_logged ? "Logged" : "Not logged"}</span>
            </div>
          </div>
        )}
      </div>

      <div className="mb-6 rounded-xl border border-neutral-200 bg-white p-4">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-sm font-semibold">Weekly Coach Report</h2>
          <button
            onClick={loadWeeklyReport}
            disabled={loadingWeekly}
            className="text-xs font-medium text-brand-dark hover:underline disabled:opacity-60"
          >
            {loadingWeekly ? "Loading…" : "Generate this week's report"}
          </button>
        </div>
        {weeklyReport && (
          <div className="space-y-3 text-sm">
            <p className="text-neutral-700">{weeklyReport.conclusion}</p>
            <div className="grid grid-cols-2 gap-2 border-t border-neutral-100 pt-2 text-xs text-neutral-500">
              <span>Avg calories: {weeklyReport.avg_calories}</span>
              <span>Avg protein: {weeklyReport.avg_protein_g}g</span>
              <span>Workouts: {weeklyReport.workouts_logged}</span>
              <span>Weight change: {weeklyReport.weight_change_kg ?? "–"}kg</span>
            </div>
            <div className="rounded-lg bg-neutral-50 p-2 text-xs text-neutral-600">
              <div className="mb-1 font-medium text-neutral-700">Next week (suggested)</div>
              <pre className="whitespace-pre-wrap font-sans">
                {JSON.stringify(weeklyReport.next_week_targets, null, 2)}
              </pre>
            </div>
          </div>
        )}
      </div>

      <div className="rounded-xl border border-neutral-200 bg-white p-4">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-semibold">Progress Photos</h2>
          <span className="text-xs text-neutral-400">Private — never public</span>
        </div>

        <div className="mb-4 flex items-center gap-2">
          <select
            value={photoAngle}
            onChange={(e) => setPhotoAngle(e.target.value)}
            className="rounded-lg border border-neutral-300 px-2 py-1.5 text-sm"
          >
            <option value="FRONT">Front</option>
            <option value="SIDE">Side</option>
            <option value="BACK">Back</option>
          </select>
          <label className="cursor-pointer rounded-lg bg-neutral-100 px-3 py-1.5 text-sm font-medium text-neutral-600 hover:bg-neutral-200">
            {uploadingPhoto ? "Uploading…" : "Add photo"}
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp"
              onChange={handlePhotoUpload}
              disabled={uploadingPhoto}
              className="hidden"
            />
          </label>
        </div>

        {photos.length > 0 ? (
          <div className="grid grid-cols-3 gap-2">
            {photos.map((photo) => (
              <div key={photo.id} className="group relative aspect-square overflow-hidden rounded-lg bg-neutral-100">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={api.progressPhotos.imageUrl(photo.id)}
                  alt={`${photo.angle} progress photo from ${photo.date}`}
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-x-0 bottom-0 bg-black/50 px-1.5 py-1 text-[10px] text-white">
                  {photo.date} · {photo.angle.toLowerCase()}
                </div>
                <button
                  onClick={() => handleDeletePhoto(photo.id)}
                  className="absolute right-1 top-1 rounded-full bg-black/50 px-1.5 py-0.5 text-[10px] text-white opacity-0 transition group-hover:opacity-100"
                >
                  delete
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-sm text-neutral-400">No progress photos yet.</p>
        )}
      </div>
    </div>
  );
}
