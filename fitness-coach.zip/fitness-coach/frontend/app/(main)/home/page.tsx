"use client";

import { useEffect, useState } from "react";
import { api, DailyNutritionSummary, WaterDailyOut, WeightTrendOut } from "@/lib/api-client";

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

const WATER_QUICK_ADD = [250, 500, 750];

export default function HomePage() {
  const [summary, setSummary] = useState<DailyNutritionSummary | null>(null);
  const [water, setWater] = useState<WaterDailyOut | null>(null);
  const [weightTrend, setWeightTrend] = useState<WeightTrendOut | null>(null);
  const [insight, setInsight] = useState<string | null>(null);
  const [insightUnavailable, setInsightUnavailable] = useState(false);

  async function loadWater() {
    setWater(await api.water.daily(today()));
  }

  useEffect(() => {
    api.nutrition.daily(today()).then(setSummary);
    loadWater();
    api.weight.trend().then(setWeightTrend);
    api.coach.send("Give me a one or two sentence insight on how my day is going so far.").then((r) => {
      if (r.ai_unavailable) {
        setInsightUnavailable(true);
      } else {
        setInsight(r.reply);
      }
    });
  }, []);

  async function addWater(ml: number) {
    await api.water.log(today(), ml);
    await loadWater();
  }

  return (
    <div>
      <h1 className="mb-1 text-xl font-semibold">Today</h1>
      <p className="mb-6 text-sm text-neutral-500">How am I doing today?</p>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Card label="Calories" value={summary?.calories ?? "–"} unit="kcal" />
        <Card label="Protein" value={summary?.protein_g ?? "–"} unit="g" />
        <Card label="Carbs" value={summary?.carbs_g ?? "–"} unit="g" />
        <Card label="Fat" value={summary?.fat_g ?? "–"} unit="g" />
      </div>

      {insight && !insightUnavailable && (
        <div className="mt-4 rounded-xl border border-brand/20 bg-brand/5 p-4">
          <div className="mb-1 text-xs font-medium text-brand-dark">Coach Insight</div>
          <p className="text-sm text-neutral-700">{insight}</p>
        </div>
      )}

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <div className="rounded-xl border border-neutral-200 bg-white p-4">
          <div className="mb-2 flex items-baseline justify-between">
            <span className="text-xs text-neutral-400">Water</span>
            <span className="text-sm font-medium">
              {water ? `${(water.total_ml / 1000).toFixed(1)}L` : "–"}
              {water?.target_ml ? ` / ${(water.target_ml / 1000).toFixed(1)}L` : ""}
            </span>
          </div>
          <div className="flex gap-2">
            {WATER_QUICK_ADD.map((ml) => (
              <button
                key={ml}
                onClick={() => addWater(ml)}
                className="flex-1 rounded-lg bg-neutral-100 py-2 text-xs font-medium text-neutral-600 hover:bg-neutral-200"
              >
                +{ml}ml
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-xl border border-neutral-200 bg-white p-4">
          <div className="mb-1 text-xs text-neutral-400">Weight</div>
          <div className="text-lg font-semibold">
            {weightTrend?.latest_kg !== null && weightTrend?.latest_kg !== undefined
              ? `${weightTrend.latest_kg} kg`
              : "No entries yet"}
          </div>
          {weightTrend?.seven_day_avg_kg != null && (
            <div className="text-xs text-neutral-400">
              7-day avg: {weightTrend.seven_day_avg_kg} kg
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function Card({
  label,
  value,
  unit,
}: {
  label: string;
  value: number | string;
  unit: string;
}) {
  return (
    <div className="rounded-xl border border-neutral-200 bg-white p-4">
      <div className="text-xs text-neutral-400">{label}</div>
      <div className="mt-1 text-2xl font-semibold">
        {value} <span className="text-sm font-normal text-neutral-400">{unit}</span>
      </div>
    </div>
  );
}
