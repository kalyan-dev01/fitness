"use client";

import { useEffect, useState } from "react";
import { api, AIProviderOut, ApiError } from "@/lib/api-client";

const KNOWN_PROVIDERS = [
  { value: "gemini", label: "Google Gemini" },
  { value: "groq", label: "Groq" },
  { value: "openrouter", label: "OpenRouter" },
  { value: "mistral", label: "Mistral" },
  { value: "ollama", label: "Ollama (local)" },
  { value: "anthropic", label: "Anthropic (paid — manual only)" },
];

const STATUS_COLORS: Record<string, string> = {
  HEALTHY: "bg-green-100 text-green-700",
  RATE_LIMITED: "bg-amber-100 text-amber-700",
  QUOTA_EXHAUSTED: "bg-amber-100 text-amber-700",
  INVALID_KEY: "bg-red-100 text-red-700",
  UNAVAILABLE: "bg-red-100 text-red-700",
  DISABLED: "bg-neutral-100 text-neutral-500",
  UNKNOWN: "bg-neutral-100 text-neutral-500",
};

export default function AIProvidersPage() {
  const [providers, setProviders] = useState<AIProviderOut[]>([]);
  const [name, setName] = useState("gemini");
  const [apiKey, setApiKey] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [testResults, setTestResults] = useState<Record<string, string>>({});

  async function load() {
    setProviders(await api.aiProviders.list());
  }

  useEffect(() => {
    load();
  }, []);

  async function handleAdd(e: React.FormEvent) {
    e.preventDefault();
    if (!apiKey) return;
    setSaving(true);
    setError(null);
    try {
      await api.aiProviders.create({ name, api_key: apiKey });
      setApiKey("");
      await load();
    } catch (err) {
      setError(err instanceof ApiError ? err.detail : "Couldn't add provider.");
    } finally {
      setSaving(false);
    }
  }

  async function handleTest(id: string) {
    setTestResults((prev) => ({ ...prev, [id]: "Testing…" }));
    const result = await api.aiProviders.test(id);
    setTestResults((prev) => ({
      ...prev,
      [id]: result.success
        ? `✅ Test passed — ${result.latency_ms}ms`
        : `❌ ${result.error_category ?? "Failed"}: ${result.error_message ?? ""}`,
    }));
    await load();
  }

  async function toggleEnabled(provider: AIProviderOut) {
    await api.aiProviders.update(provider.id, { is_enabled: !provider.is_enabled });
    await load();
  }

  async function toggleAutoFallback(provider: AIProviderOut) {
    if (!provider.is_free_only) return; // cost safety — enforced server-side too
    await api.aiProviders.update(provider.id, {
      auto_fallback_enabled: !provider.auto_fallback_enabled,
    });
    await load();
  }

  async function handleDelete(id: string) {
    await api.aiProviders.delete(id);
    await load();
  }

  return (
    <div className="max-w-xl">
      <h1 className="mb-1 text-xl font-semibold">AI Providers</h1>
      <p className="mb-6 text-sm text-neutral-500">
        The Coach uses these to generate responses. Paid providers (like
        Anthropic) are never used for automatic fallback — only when you
        explicitly select them.
      </p>

      <form
        onSubmit={handleAdd}
        className="mb-6 space-y-3 rounded-xl border border-neutral-200 bg-white p-4"
      >
        <h2 className="text-sm font-semibold">Add a provider</h2>
        <select
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm"
        >
          {KNOWN_PROVIDERS.map((p) => (
            <option key={p.value} value={p.value}>
              {p.label}
            </option>
          ))}
        </select>
        <input
          type="password"
          placeholder="API key"
          value={apiKey}
          onChange={(e) => setApiKey(e.target.value)}
          className="w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm"
        />
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button
          type="submit"
          disabled={saving}
          className="w-full rounded-lg bg-brand py-2 text-sm font-medium text-white hover:bg-brand-dark disabled:opacity-60"
        >
          {saving ? "Adding…" : "Add provider"}
        </button>
      </form>

      <div className="space-y-3">
        {providers.map((p) => (
          <div key={p.id} className="rounded-xl border border-neutral-200 bg-white p-4">
            <div className="mb-2 flex items-center justify-between">
              <div>
                <div className="font-medium">{p.display_name}</div>
                <div className="text-xs text-neutral-400">
                  {p.model} · key {p.key_hint}
                </div>
              </div>
              <span
                className={`rounded px-2 py-0.5 text-xs font-medium ${
                  STATUS_COLORS[p.health?.status ?? "UNKNOWN"]
                }`}
              >
                {p.health?.status ?? "UNKNOWN"}
              </span>
            </div>

            <div className="mb-3 flex flex-wrap gap-2 text-xs">
              <button
                onClick={() => toggleEnabled(p)}
                className="rounded-full bg-neutral-100 px-3 py-1 text-neutral-600 hover:bg-neutral-200"
              >
                {p.is_enabled ? "Disable" : "Enable"}
              </button>
              <button
                onClick={() => toggleAutoFallback(p)}
                disabled={!p.is_free_only}
                title={!p.is_free_only ? "Paid providers can't auto-fallback" : ""}
                className="rounded-full bg-neutral-100 px-3 py-1 text-neutral-600 hover:bg-neutral-200 disabled:opacity-40"
              >
                Auto-fallback: {p.auto_fallback_enabled ? "On" : "Off"}
              </button>
              <button
                onClick={() => handleTest(p.id)}
                className="rounded-full bg-neutral-100 px-3 py-1 text-neutral-600 hover:bg-neutral-200"
              >
                Test Connection
              </button>
              <button
                onClick={() => handleDelete(p.id)}
                className="rounded-full bg-neutral-100 px-3 py-1 text-neutral-600 hover:bg-red-100 hover:text-red-600"
              >
                Delete
              </button>
            </div>

            {testResults[p.id] && (
              <p className="text-xs text-neutral-500">{testResults[p.id]}</p>
            )}
            {!p.is_free_only && (
              <p className="mt-1 text-xs text-amber-600">
                Paid provider — only used when explicitly selected, never as
                an automatic fallback.
              </p>
            )}
          </div>
        ))}
        {providers.length === 0 && (
          <p className="text-center text-sm text-neutral-400">
            No providers configured yet. The Coach will show as unavailable
            until you add one.
          </p>
        )}
      </div>
    </div>
  );
}
