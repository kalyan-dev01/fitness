"use client";

import { useEffect, useState } from "react";
import { LineChart, Line, XAxis, Tooltip, ResponsiveContainer } from "recharts";
import {
  api,
  ExerciseOut,
  ExerciseSetInput,
  ExerciseStrengthPoint,
  ExerciseVolumePoint,
  ProgressionOut,
  WorkoutSessionOut,
} from "@/lib/api-client";

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

export default function WorkoutPage() {
  const [exercises, setExercises] = useState<ExerciseOut[]>([]);
  const [sessions, setSessions] = useState<WorkoutSessionOut[]>([]);
  const [selectedExerciseId, setSelectedExerciseId] = useState("");
  const [sets, setSets] = useState<ExerciseSetInput[]>([{ weight_kg: 0, reps: 0 }]);
  const [suggestion, setSuggestion] = useState<ProgressionOut | null>(null);
  const [saving, setSaving] = useState(false);
  const [volumePoints, setVolumePoints] = useState<ExerciseVolumePoint[]>([]);
  const [strengthPoints, setStrengthPoints] = useState<ExerciseStrengthPoint[]>([]);

  useEffect(() => {
    api.exercises.list().then((list) => {
      setExercises(list);
      if (list.length) setSelectedExerciseId(list[0].id);
    });
    api.workouts.list().then(setSessions);
  }, []);

  useEffect(() => {
    if (!selectedExerciseId) return;
    api.progression
      .suggestion(selectedExerciseId)
      .then(setSuggestion)
      .catch(() => setSuggestion(null));
    api.analytics
      .workoutVolume(selectedExerciseId)
      .then((r) => setVolumePoints(r.points))
      .catch(() => setVolumePoints([]));
    api.analytics
      .strength(selectedExerciseId)
      .then((r) => setStrengthPoints(r.points))
      .catch(() => setStrengthPoints([]));
  }, [selectedExerciseId]);

  function updateSet(index: number, field: keyof ExerciseSetInput, value: number) {
    setSets((prev) => prev.map((s, i) => (i === index ? { ...s, [field]: value } : s)));
  }

  function addSet() {
    setSets((prev) => [...prev, { weight_kg: prev.at(-1)?.weight_kg ?? 0, reps: 0 }]);
  }

  async function handleLog() {
    if (!selectedExerciseId) return;
    setSaving(true);
    try {
      await api.workouts.log({
        date: today(),
        exercises: [{ exercise_id: selectedExerciseId, sets }],
      });
      setSets([{ weight_kg: 0, reps: 0 }]);
      setSessions(await api.workouts.list());
      setSuggestion(await api.progression.suggestion(selectedExerciseId));
      api.analytics.workoutVolume(selectedExerciseId).then((r) => setVolumePoints(r.points));
      api.analytics.strength(selectedExerciseId).then((r) => setStrengthPoints(r.points));
    } finally {
      setSaving(false);
    }
  }

  const exerciseName = (id: string) => exercises.find((e) => e.id === id)?.name ?? "—";

  return (
    <div className="max-w-xl">
      <h1 className="mb-6 text-xl font-semibold">Workout</h1>

      <div className="mb-6 rounded-xl border border-neutral-200 bg-white p-4">
        <label className="mb-1 block text-xs text-neutral-500">Exercise</label>
        <select
          value={selectedExerciseId}
          onChange={(e) => setSelectedExerciseId(e.target.value)}
          className="mb-3 w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm"
        >
          {exercises.map((e) => (
            <option key={e.id} value={e.id}>
              {e.name}
            </option>
          ))}
        </select>

        {suggestion && (
          <div className="mb-3 rounded-lg bg-brand/5 px-3 py-2 text-sm text-neutral-700">
            {suggestion.suggested_next_weight_kg ? (
              <>
                Suggested next weight:{" "}
                <span className="font-semibold">
                  {suggestion.suggested_next_weight_kg}kg
                </span>
              </>
            ) : (
              suggestion.reasoning
            )}
          </div>
        )}

        {strengthPoints.length > 1 && (
          <div className="mb-1 h-24">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={strengthPoints}>
                <XAxis dataKey="date" hide />
                <Tooltip formatter={(v: number) => [`${v}kg`, "Best weight"]} />
                <Line
                  type="monotone"
                  dataKey="best_weight_kg"
                  stroke="#16a34a"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
        {volumePoints.length > 1 && (
          <div className="mb-3 h-20">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={volumePoints}>
                <XAxis dataKey="date" hide />
                <Tooltip formatter={(v: number) => [`${v}`, "Volume (kg×reps)"]} />
                <Line
                  type="monotone"
                  dataKey="volume"
                  stroke="#94a3b8"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        <div className="space-y-2">
          {sets.map((set, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="w-6 text-xs text-neutral-400">#{i + 1}</span>
              <input
                type="number"
                placeholder="kg"
                value={set.weight_kg || ""}
                onChange={(e) => updateSet(i, "weight_kg", Number(e.target.value))}
                className="w-20 rounded-lg border border-neutral-300 px-2 py-1.5 text-sm"
              />
              <span className="text-neutral-400">×</span>
              <input
                type="number"
                placeholder="reps"
                value={set.reps || ""}
                onChange={(e) => updateSet(i, "reps", Number(e.target.value))}
                className="w-20 rounded-lg border border-neutral-300 px-2 py-1.5 text-sm"
              />
            </div>
          ))}
        </div>

        <button
          onClick={addSet}
          className="mt-2 text-xs font-medium text-brand-dark hover:underline"
        >
          + Add set
        </button>

        <button
          onClick={handleLog}
          disabled={saving}
          className="mt-4 w-full rounded-lg bg-brand py-2 text-sm font-medium text-white hover:bg-brand-dark disabled:opacity-60"
        >
          {saving ? "Saving…" : "Log workout"}
        </button>
      </div>

      <div className="rounded-xl border border-neutral-200 bg-white">
        <h2 className="border-b border-neutral-100 px-4 py-3 text-sm font-semibold">
          Recent sessions
        </h2>
        <ul className="divide-y divide-neutral-100">
          {sessions.map((session) => (
            <li key={session.id} className="px-4 py-3 text-sm">
              <div className="mb-1 font-medium">{session.date}</div>
              {session.exercises.map((we) => (
                <div key={we.id} className="text-neutral-600">
                  {exerciseName(we.exercise_id)}:{" "}
                  {we.sets
                    .map((s) => `${s.weight_kg}kg×${s.reps}${s.is_pr ? " 🏆" : ""}`)
                    .join(", ")}
                </div>
              ))}
            </li>
          ))}
          {sessions.length === 0 && (
            <li className="px-4 py-6 text-center text-sm text-neutral-400">
              No workouts logged yet.
            </li>
          )}
        </ul>
      </div>
    </div>
  );
}
