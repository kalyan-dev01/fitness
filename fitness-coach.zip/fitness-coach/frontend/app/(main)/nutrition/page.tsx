"use client";

import { useEffect, useState } from "react";
import { LineChart, Line, XAxis, Tooltip, ResponsiveContainer } from "recharts";
import { api, ApiError, FoodOut, DailyNutritionSummary, ParsedFoodItem } from "@/lib/api-client";

const MEAL_TYPES = [
  "BREAKFAST",
  "LUNCH",
  "DINNER",
  "SNACK",
  "PRE_WORKOUT",
  "POST_WORKOUT",
] as const;

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

export default function NutritionPage() {
  const [summary, setSummary] = useState<DailyNutritionSummary | null>(null);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<FoodOut[]>([]);
  const [selectedFood, setSelectedFood] = useState<FoodOut | null>(null);
  const [quantity, setQuantity] = useState(100);
  const [rawCooked, setRawCooked] = useState<"RAW" | "COOKED" | "NA">("RAW");
  const [mealType, setMealType] = useState<(typeof MEAL_TYPES)[number]>("BREAKFAST");
  const [error, setError] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);

  const [quickAddText, setQuickAddText] = useState("");
  const [parsedItems, setParsedItems] = useState<ParsedFoodItem[]>([]);
  const [parsing, setParsing] = useState(false);
  const [parseUnavailable, setParseUnavailable] = useState(false);
  const [nutritionTrend, setNutritionTrend] = useState<
    { date: string; calories: number; protein: number }[]
  >([]);

  const date = today();

  async function loadSummary() {
    const data = await api.nutrition.daily(date);
    setSummary(data);
  }

  useEffect(() => {
    loadSummary();
    api.analytics.nutrition(14).then((series) => {
      const byDate = new Map<string, { calories: number; protein: number }>();
      series.calories.forEach((p) => byDate.set(p.date, { calories: p.value, protein: 0 }));
      series.protein.forEach((p) => {
        const existing = byDate.get(p.date) ?? { calories: 0, protein: 0 };
        byDate.set(p.date, { ...existing, protein: p.value });
      });
      setNutritionTrend(
        Array.from(byDate.entries())
          .sort((a, b) => a[0].localeCompare(b[0]))
          .map(([date, v]) => ({ date, ...v }))
      );
    });
  }, []);

  useEffect(() => {
    if (!query) {
      setResults([]);
      return;
    }
    const handle = setTimeout(() => {
      api.foods.search(query).then(setResults).catch(() => setResults([]));
    }, 250);
    return () => clearTimeout(handle);
  }, [query]);

  async function handleQuickAddParse() {
    if (!quickAddText.trim()) return;
    setParsing(true);
    setParseUnavailable(false);
    try {
      const result = await api.coach.parseFood(quickAddText);
      if (result.ai_unavailable) {
        setParseUnavailable(true);
        setParsedItems([]);
      } else {
        setParsedItems(result.items);
      }
    } finally {
      setParsing(false);
    }
  }

  async function handleConfirmQuickAdd() {
    const matched = parsedItems.filter((i) => i.matched_food_id && !i.needs_manual_match);
    if (matched.length === 0) return;
    setAdding(true);
    try {
      await api.meals.create({
        date,
        meal_type: mealType,
        items: matched.map((i) => ({
          food_id: i.matched_food_id!,
          quantity: i.quantity,
          unit: i.unit,
          raw_cooked: i.raw_cooked as "RAW" | "COOKED" | "NA",
        })),
      });
      setParsedItems([]);
      setQuickAddText("");
      await loadSummary();
    } finally {
      setAdding(false);
    }
  }

  function removeParsedItem(index: number) {
    setParsedItems((prev) => prev.filter((_, i) => i !== index));
  }

    setSelectedFood(food);
    setError(null);
    const states = new Set(food.servings.map((s) => s.raw_cooked));
    setRawCooked(states.has("RAW") ? "RAW" : (food.servings[0]?.raw_cooked as any) ?? "NA");
  }

  async function handleAdd() {
    if (!selectedFood) return;
    setAdding(true);
    setError(null);
    try {
      const unit = selectedFood.servings.find((s) => s.raw_cooked === rawCooked)?.unit
        ?? selectedFood.default_unit;
      await api.meals.create({
        date,
        meal_type: mealType,
        items: [
          {
            food_id: selectedFood.id,
            quantity,
            unit,
            raw_cooked: rawCooked,
          },
        ],
      });
      setSelectedFood(null);
      setQuery("");
      setResults([]);
      await loadSummary();
    } catch (err) {
      setError(err instanceof ApiError ? err.detail : "Couldn't add that item.");
    } finally {
      setAdding(false);
    }
  }

  return (
    <div className="max-w-xl">
      <h1 className="mb-1 text-xl font-semibold">Nutrition</h1>
      <p className="mb-6 text-sm text-neutral-500">{date}</p>

      {summary && (
        <div className="mb-6 grid grid-cols-4 gap-2 rounded-xl border border-neutral-200 bg-white p-4">
          <Stat label="Calories" value={summary.calories} />
          <Stat label="Protein" value={`${summary.protein_g}g`} />
          <Stat label="Carbs" value={`${summary.carbs_g}g`} />
          <Stat label="Fat" value={`${summary.fat_g}g`} />
        </div>
      )}

      {nutritionTrend.length > 1 && (
        <div className="mb-6 rounded-xl border border-neutral-200 bg-white p-4">
          <h2 className="mb-2 text-xs font-semibold text-neutral-500">
            Calories — last 14 days
          </h2>
          <div className="h-24">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={nutritionTrend}>
                <XAxis dataKey="date" hide />
                <Tooltip formatter={(v: number) => [`${v} kcal`, "Calories"]} />
                <Line type="monotone" dataKey="calories" stroke="#16a34a" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      <div className="mb-6 rounded-xl border border-neutral-200 bg-white p-4">
        <h2 className="mb-3 text-sm font-semibold">Quick Add</h2>
        <p className="mb-2 text-xs text-neutral-400">
          Describe what you ate in plain language — e.g. "50g oats, 150ml milk and 2 eggs".
        </p>
        <div className="mb-2 flex gap-2">
          <input
            value={quickAddText}
            onChange={(e) => setQuickAddText(e.target.value)}
            placeholder="50g oats, 150ml milk and 2 eggs"
            className="flex-1 rounded-lg border border-neutral-300 px-3 py-2 text-sm"
          />
          <button
            onClick={handleQuickAddParse}
            disabled={parsing}
            className="rounded-lg bg-neutral-100 px-4 py-2 text-sm font-medium text-neutral-600 hover:bg-neutral-200 disabled:opacity-60"
          >
            {parsing ? "Parsing…" : "Parse"}
          </button>
        </div>

        {parseUnavailable && (
          <p className="text-xs text-amber-600">
            AI Coach is unavailable right now, so Quick Add can't parse text.
            Use the search box below to add foods manually.
          </p>
        )}

        {parsedItems.length > 0 && (
          <div className="space-y-2">
            {parsedItems.map((item, i) => (
              <div
                key={i}
                className={`flex items-center justify-between rounded-lg border px-3 py-2 text-sm ${
                  item.needs_manual_match
                    ? "border-amber-200 bg-amber-50"
                    : "border-neutral-200"
                }`}
              >
                <div>
                  <span className="font-medium">
                    {item.matched_food_name ?? item.raw_name}
                  </span>
                  <span className="ml-2 text-neutral-400">
                    {item.quantity}
                    {item.unit}
                  </span>
                  {item.needs_manual_match ? (
                    <span className="ml-2 text-xs text-amber-600">
                      no match — add manually below
                    </span>
                  ) : (
                    <span className="ml-2 text-xs text-neutral-400">
                      {item.calories} kcal · {item.protein_g}g protein
                      {!item.is_verified && " (estimated)"}
                    </span>
                  )}
                </div>
                <button
                  onClick={() => removeParsedItem(i)}
                  className="text-xs text-neutral-400 hover:text-red-600"
                >
                  remove
                </button>
              </div>
            ))}
            <button
              onClick={handleConfirmQuickAdd}
              disabled={adding || !parsedItems.some((i) => i.matched_food_id)}
              className="w-full rounded-lg bg-brand py-2 text-sm font-medium text-white hover:bg-brand-dark disabled:opacity-60"
            >
              {adding ? "Adding…" : "Confirm & add to diary"}
            </button>
          </div>
        )}
      </div>

      <div className="rounded-xl border border-neutral-200 bg-white p-4">
        <h2 className="mb-3 text-sm font-semibold">Search &amp; add food</h2>

        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search foods, e.g. chicken, rice, dal…"
          className="mb-2 w-full rounded-lg border border-neutral-300 px-3 py-2 text-sm"
        />

        {results.length > 0 && !selectedFood && (
          <ul className="mb-2 max-h-48 divide-y divide-neutral-100 overflow-y-auto rounded-lg border border-neutral-200">
            {results.map((food) => (
              <li key={food.id}>
                <button
                  onClick={() => selectFood(food)}
                  className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-neutral-50"
                >
                  <span>{food.name}</span>
                  {!food.is_verified && (
                    <span className="rounded bg-amber-100 px-1.5 py-0.5 text-xs text-amber-700">
                      estimated
                    </span>
                  )}
                </button>
              </li>
            ))}
          </ul>
        )}

        {selectedFood && (
          <div className="mb-2 space-y-3 rounded-lg border border-neutral-200 p-3">
            <div className="flex items-center justify-between text-sm font-medium">
              <span>{selectedFood.name}</span>
              <button
                onClick={() => setSelectedFood(null)}
                className="text-xs text-neutral-400 hover:text-neutral-600"
              >
                change
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1 block text-xs text-neutral-500">Quantity</label>
                <input
                  type="number"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="w-full rounded-lg border border-neutral-300 px-2 py-1.5 text-sm"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs text-neutral-500">Meal</label>
                <select
                  value={mealType}
                  onChange={(e) => setMealType(e.target.value as any)}
                  className="w-full rounded-lg border border-neutral-300 px-2 py-1.5 text-sm"
                >
                  {MEAL_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {t.replace("_", " ").toLowerCase()}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {new Set(selectedFood.servings.map((s) => s.raw_cooked)).size > 1 && (
              <div className="flex gap-2 text-xs">
                {["RAW", "COOKED"].map((state) => (
                  <button
                    key={state}
                    onClick={() => setRawCooked(state as "RAW" | "COOKED")}
                    className={`rounded-full px-3 py-1 ${
                      rawCooked === state
                        ? "bg-brand text-white"
                        : "bg-neutral-100 text-neutral-600"
                    }`}
                  >
                    {state.toLowerCase()}
                  </button>
                ))}
              </div>
            )}

            <button
              onClick={handleAdd}
              disabled={adding}
              className="w-full rounded-lg bg-brand py-2 text-sm font-medium text-white hover:bg-brand-dark disabled:opacity-60"
            >
              {adding ? "Adding…" : "Add to diary"}
            </button>
          </div>
        )}

        {error && (
          <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-600">{error}</p>
        )}
      </div>

      {summary && summary.meals.length > 0 && (
        <div className="mt-6 space-y-4">
          {summary.meals.map((meal) => (
            <div key={meal.id} className="rounded-xl border border-neutral-200 bg-white p-4">
              <h3 className="mb-2 text-sm font-semibold capitalize">
                {meal.meal_type.replace("_", " ").toLowerCase()}
              </h3>
              <ul className="space-y-1 text-sm text-neutral-600">
                {meal.items.map((item) => (
                  <li key={item.id} className="flex justify-between">
                    <span>
                      {item.label_snapshot} — {item.quantity}
                      {item.unit}
                      {item.raw_cooked !== "NA" && ` (${item.raw_cooked.toLowerCase()})`}
                    </span>
                    <span>{item.calories_snapshot} kcal</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div>
      <div className="text-lg font-semibold">{value}</div>
      <div className="text-xs text-neutral-400">{label}</div>
    </div>
  );
}
