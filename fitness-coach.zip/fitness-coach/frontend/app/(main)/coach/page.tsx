"use client";

import { useEffect, useRef, useState } from "react";
import { api, AIConversationOut, AIMessageOut } from "@/lib/api-client";

const QUICK_ACTIONS = [
  "Can I eat this?",
  "What should I eat tonight?",
  "Analyze my day",
  "Should I train today?",
  "Why am I not losing weight?",
  "Am I getting stronger?",
];

export default function CoachPage() {
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<AIMessageOut[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [history, setHistory] = useState<AIConversationOut[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  async function loadHistory() {
    setHistory(await api.coach.listConversations());
  }

  function openConversation(conversation: AIConversationOut) {
    setConversationId(conversation.id);
    setMessages(conversation.messages);
    setShowHistory(false);
  }

  function startNewConversation() {
    setConversationId(null);
    setMessages([]);
    setShowHistory(false);
  }

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function send(text: string) {
    if (!text.trim() || sending) return;
    setSending(true);
    setInput("");

    setMessages((prev) => [
      ...prev,
      {
        id: `local-${Date.now()}`,
        role: "USER",
        content: text,
        provider_name: null,
        model: null,
        created_at: new Date().toISOString(),
      },
    ]);

    try {
      const result = await api.coach.send(text, conversationId ?? undefined);
      setConversationId(result.conversation_id);
      setMessages((prev) => [
        ...prev,
        {
          id: `local-reply-${Date.now()}`,
          role: "ASSISTANT",
          content: result.reply,
          provider_name: result.provider_name,
          model: result.model,
          created_at: new Date().toISOString(),
        },
      ]);
      loadHistory();
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="flex h-[calc(100vh-8rem)] max-w-xl flex-col md:h-[calc(100vh-3rem)]">
      <div className="mb-3 flex items-center justify-between">
        <h1 className="text-xl font-semibold">🧠 Your Coach</h1>
        <div className="flex gap-2 text-xs">
          <button
            onClick={startNewConversation}
            className="rounded-full border border-neutral-200 px-3 py-1 text-neutral-500 hover:bg-neutral-50"
          >
            New
          </button>
          <button
            onClick={() => {
              setShowHistory((v) => !v);
              if (!showHistory) loadHistory();
            }}
            className="rounded-full border border-neutral-200 px-3 py-1 text-neutral-500 hover:bg-neutral-50"
          >
            History
          </button>
        </div>
      </div>

      {showHistory && (
        <div className="mb-3 max-h-40 overflow-y-auto rounded-xl border border-neutral-200 bg-white">
          {history.length === 0 && (
            <p className="px-3 py-3 text-center text-xs text-neutral-400">
              No past conversations yet.
            </p>
          )}
          {history.map((c) => (
            <button
              key={c.id}
              onClick={() => openConversation(c)}
              className="block w-full border-b border-neutral-100 px-3 py-2 text-left text-xs last:border-0 hover:bg-neutral-50"
            >
              {c.messages[0]?.content.slice(0, 60) || "Conversation"}
              {c.messages[0]?.content && c.messages[0].content.length > 60 ? "…" : ""}
            </button>
          ))}
        </div>
      )}

      {messages.length === 0 && (
        <div className="mb-4 flex flex-wrap gap-2">
          {QUICK_ACTIONS.map((action) => (
            <button
              key={action}
              onClick={() => send(action)}
              className="rounded-full border border-neutral-200 bg-white px-3 py-1.5 text-xs text-neutral-600 hover:bg-neutral-50"
            >
              {action}
            </button>
          ))}
        </div>
      )}

      <div className="flex-1 space-y-3 overflow-y-auto rounded-xl border border-neutral-200 bg-white p-4">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex ${m.role === "USER" ? "justify-end" : "justify-start"}`}
          >
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${
                m.role === "USER"
                  ? "bg-brand text-white"
                  : "bg-neutral-100 text-neutral-800"
              }`}
            >
              {m.content}
            </div>
          </div>
        ))}
        {sending && (
          <div className="flex justify-start">
            <div className="rounded-2xl bg-neutral-100 px-4 py-2 text-sm text-neutral-400">
              Thinking…
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
        className="mt-3 flex gap-2"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Type a message…"
          className="flex-1 rounded-full border border-neutral-300 px-4 py-2 text-sm"
        />
        <button
          type="submit"
          disabled={sending}
          className="rounded-full bg-brand px-5 py-2 text-sm font-medium text-white hover:bg-brand-dark disabled:opacity-60"
        >
          ➤
        </button>
      </form>
    </div>
  );
}
