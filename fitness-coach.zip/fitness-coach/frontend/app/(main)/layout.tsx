"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { api, ApiError, UserOut } from "@/lib/api-client";

const NAV_ITEMS = [
  { href: "/home", label: "Home" },
  { href: "/nutrition", label: "Nutrition" },
  { href: "/workout", label: "Workout" },
  { href: "/progress", label: "Progress" },
  { href: "/coach", label: "Coach" },
];

export default function MainLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [user, setUser] = useState<UserOut | null>(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    api.auth
      .me()
      .then(setUser)
      .catch((err) => {
        if (err instanceof ApiError && err.status === 401) {
          router.replace("/login");
        }
      })
      .finally(() => setChecking(false));
  }, [router]);

  async function handleLogout() {
    await api.auth.logout();
    router.replace("/login");
  }

  if (checking) {
    return (
      <div className="flex min-h-screen items-center justify-center text-sm text-neutral-400">
        Loading…
      </div>
    );
  }

  if (!user) return null; // redirect already in flight

  return (
    <div className="flex min-h-screen flex-col pb-16 md:pb-0 md:pl-56">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 hidden w-56 flex-col border-r border-neutral-200 bg-white p-4 dark:border-neutral-800 dark:bg-neutral-900 md:flex">
        <div className="mb-6 text-lg font-semibold">🏋️ Fitness Coach</div>
        <nav className="flex-1 space-y-1">
          {[...NAV_ITEMS, { href: "/ai-providers", label: "AI Providers" }, { href: "/settings", label: "Settings" }].map(
            (item) => (
              <Link
                key={item.href}
                href={item.href}
                className={`block rounded-lg px-3 py-2 text-sm font-medium ${
                  pathname?.startsWith(item.href)
                    ? "bg-brand/10 text-brand-dark"
                    : "text-neutral-600 hover:bg-neutral-100 dark:text-neutral-300 dark:hover:bg-neutral-800"
                }`}
              >
                {item.label}
              </Link>
            )
          )}
        </nav>
        <button
          onClick={handleLogout}
          className="mt-4 rounded-lg px-3 py-2 text-left text-sm text-neutral-500 hover:bg-neutral-100"
        >
          Log out
        </button>
      </aside>

      <main className="flex-1 px-4 py-6 md:px-8">{children}</main>

      {/* Mobile bottom nav */}
      <nav className="fixed inset-x-0 bottom-0 flex border-t border-neutral-200 bg-white dark:border-neutral-800 dark:bg-neutral-900 md:hidden">
        {NAV_ITEMS.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={`flex-1 py-3 text-center text-xs font-medium ${
              pathname?.startsWith(item.href)
                ? "text-brand-dark"
                : "text-neutral-400"
            }`}
          >
            {item.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}
