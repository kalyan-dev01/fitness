Drop real 192x192 and 512x512 PNG icons here as `icon-192.png` and
`icon-512.png` before shipping — the manifest references them by these exact
names. Placeholder icons aren't included since they'd just be noise; the app
works and installs without them, but Lighthouse/PWA install prompts will
complain about the missing image assets until they're added.
