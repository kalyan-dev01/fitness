// Minimal offline-friendly shell (spec section 57). This intentionally
// does NOT cache API responses long-term — nutrition/workout/weight data
// changes constantly and stale cached data would be actively misleading.
// It only makes the static app shell (HTML/CSS/JS) available offline so
// the app doesn't show a blank browser error page with no connectivity;
// AI features and any data fetch still require a live connection.

const CACHE_NAME = "fitness-coach-shell-v1";
const SHELL_URLS = ["/", "/home", "/manifest.json"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_URLS))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // Never cache API calls — always go to the network so data stays fresh.
  // If the network fails, let the request fail normally rather than
  // silently returning stale data the user would mistake for current.
  if (url.pathname.startsWith("/api/")) {
    return;
  }

  // Static shell: network-first, falling back to cache when offline.
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        const clone = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});
