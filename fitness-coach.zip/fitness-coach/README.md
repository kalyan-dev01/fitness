# Fitness Coach

Personal AI fitness & nutrition coach — Next.js + FastAPI + PostgreSQL.

## Status

- **Phase 1 (Foundation):** done — auth, user profile, goals, Docker dev
  environment, migrations, tests.
- **Phase 2 (Nutrition):** done — deterministic calorie/macro engine,
  food database (raw/cooked aware), custom foods, recipes, meal diary,
  daily nutrition summary, starter Indian food seed data, nutrition page
  + home dashboard wired to real data.
- **Phase 3 (Weight & Hydration):** done — weight logging with 7/30-day
  trend math (deliberately dampens single-outlier overreaction), water
  logging with quick-add buttons and a customizable daily target, both
  wired into the Home dashboard and a real Progress page.
- **Phase 4 (Workout):** done — predefined exercise database, workout
  logging with sets/reps/optional RPE-RIR, deterministic PR detection on
  every save, and a progressive-overload suggestion engine (explicit rule:
  hit the top of the rep range on every set → suggest +2.5kg upper body /
  +5kg lower body next time).
- **Phase 5 (AI Provider Manager):** done — provider abstraction
  (`AIProvider` interface), an `OpenAICompatibleProvider` shared by
  Gemini/Groq/OpenRouter/Mistral/Ollama, encrypted-at-rest API keys,
  `ProviderManager` with priority-ordered automatic fallback restricted to
  `is_free_only` providers, cooldowns after hard failures (429/timeout/5xx/
  network — never on a merely slow success), usage/health/event tracking,
  and a Settings page to add/test/enable/disable providers. Anthropic is
  registered as paid (`is_free_only=False`) and the cost-safety guardrail
  is enforced server-side, not just in the UI: the API refuses to let a
  paid provider have automatic fallback turned on, regardless of what's
  sent in the request.
- **Phase 6 (AI Coach):** done — Context Builder (keyword-based question
  classification → minimal targeted DB queries, never a full-DB dump),
  versioned system prompt, `/coach/message` with full conversation
  persistence and graceful degradation (returns 200 + a clear "unavailable"
  message when no provider is configured or all fail — never a 500),
  natural-language Quick Add food parsing (`/coach/parse-food` — AI extracts
  structure only, deterministic matching + nutrition calc, nothing is ever
  auto-saved), quick-action buttons, and a Coach Insight card on the Home
  dashboard.
- **Phase 7 (Reports & Analytics):** done — deterministic daily/weekly data
  gathering (`report_engine.py`; the AI only ever writes narrative text
  around numbers the app already computed, never recalculates them),
  `/reports/daily` (Today's Review) and `/reports/weekly` (Weekly Coach
  Report, persisted to `weekly_reports` with suggested — never
  auto-applied — next-week targets), analytics endpoints for weight/
  nutrition/workout-volume/strength series, a weight trend chart
  (recharts) on the Progress page, and both review types wired into the UI
  there. Both report endpoints degrade gracefully with the same
  `ai_unavailable` pattern as Phase 6 when no provider is configured.
- **Phase 8 (Progress Photos):** done — private per-user file storage
  outside any public web root, a single authenticated streaming endpoint
  (`GET /progress-photos/{id}/image`) that checks ownership before ever
  touching disk, upload with content-type/size validation, and delete that
  removes both the file and the DB row (no soft-delete grace period for
  these — sensitive photos get properly deleted). Wired into the Progress
  page with a private photo grid.
- **Phase 9 (PWA & Deployment):** done — basic offline app-shell service
  worker (static shell only; API calls are never cached, so data always
  reflects the network or fails honestly), in-app notification preferences
  (banners while the app is open — see the honest limitation note below),
  full JSON data export, dark/light theme toggle, security headers
  middleware, a lightweight in-memory rate limiter on login/register,
  production Docker Compose (`docker-compose.prod.yml`) with Caddy as the
  reverse proxy for automatic HTTPS behind Cloudflare, and a backup script
  with restore instructions.

This completes all 9 phases from the original spec.

⚠️ **Known gaps and simplifications, called out honestly rather than
faking completeness:**
- **Notifications are not real push notifications.** They're in-app
  banners shown only while the app is open. True background push (working
  when the app/browser is closed) needs a push service — VAPID keys, a
  service worker `push` event handler, and a backend endpoint to manage
  push subscriptions — none of which is implemented. The Settings page
  toggles are real and persist, but they don't yet drive any actual
  reminder delivery mechanism beyond what a future "check reminders on
  load" client feature could add.
- **Rate limiting is in-memory, single-instance only.** Fine for one VPS;
  would need a shared store (Redis) the moment this runs on more than one
  backend instance.
- **Dark mode styling is not exhaustive.** The toggle and persistence work
  correctly and the app shell (sidebar/nav) is dark-mode aware, but
  individual page cards still use light-mode-only Tailwind classes
  (`bg-white`, etc.) — a full pass adding `dark:` variants across every
  page wasn't done in this session.
- **PWA icons are still placeholders** — see
  `frontend/public/icons/README.md`, unchanged since Phase 1.
- **`backup.sh` executable bit** may not survive the zip download —
  run `chmod +x backup.sh` after extracting if `./backup.sh` fails to run.

## Frontend completeness pass (post-Phase-9)

A few backend features from earlier phases didn't have frontend UI yet —
closed the gaps:
- **Quick Add** (natural-language food logging) is now live on the
  Nutrition page — parses text via the AI, shows matched items with an
  "estimated" badge where relevant, flags unmatched items instead of
  guessing, and only logs to the diary after you confirm.
- **Coach conversation history** — a "History" button on the Coach page
  lists past conversations and lets you reopen one instead of always
  starting fresh.
- **Analytics charts** — a calorie trend on the Nutrition page, and
  strength/volume charts per exercise on the Workout page, both backed by
  the Phase 7 analytics endpoints that had no UI before now.

## Deploying to a VPS

1. Point your domain's DNS at your VPS through Cloudflare (proxied /
   orange-cloud record).
2. In Cloudflare, set SSL/TLS mode to **Full (strict)**.
3. On the VPS: clone/copy this repo, copy `.env.example` to `.env` and
   fill in real values (`DOMAIN`, `POSTGRES_PASSWORD`, `JWT_SECRET`,
   `FIELD_ENCRYPTION_KEY`, `COOKIE_SECURE=true`).
4. Edit `infra/nginx/Caddyfile` — replace `fitness.example.com` with your
   real domain.
5. `docker compose -f docker-compose.prod.yml up --build -d`
6. Open a firewall for ports 80/443 only — Postgres has no published port
   in the production compose file, by design.
7. Set up `backup.sh` on a daily cron job.

⚠️ **Known gap, called out honestly:** spec section 19 mentions the AI may
give general visual observations on progress photos. I did not implement
this — the provider abstraction built in Phase 5 only sends text to
providers, not images, and adding real vision support (provider-specific
multipart/base64 image APIs, safe prompting to avoid body-fat-percentage
claims, etc.) is a meaningfully sized feature on its own. Storage/security/
timeline (the parts of section 19 that matter most) are fully implemented;
AI photo analysis is not, rather than faking it with a canned response.

⚠️ **Known simplification:** question classification in
`context_builder.py` is keyword-based, not AI-based — deliberately, since
it's free, fast, deterministic, and auditable, but it can misclassify
phrasing it doesn't recognize (falls back to a general context in that
case rather than guessing narrower and missing data). The Home page's
Coach Insight card also starts a new conversation on every page load
rather than reusing a daily one — fine for now, worth tightening in a
later pass if conversation clutter becomes annoying.

⚠️ **Verify before real use:** `backend/app/ai/registry.py` has base
URLs/default models for each provider — these are reasonable-as-of-training
starting points, not live-verified. I don't have working web search in this
session to confirm current values; check each provider's docs before
trusting the defaults, especially free-tier limits and model availability
(spec section 77 flags this explicitly for the same reason).

See `docs/` (added as phases land) for what each phase actually implements.

⚠️ **Testing note:** this sandbox has no network access and no Postgres/Docker
available to actually run the test suite or boot the containers. Every file
was syntax-checked (`python -m py_compile`), and the code was written and
reviewed carefully, but it has not been executed end-to-end. Run
`docker compose up --build` and the test commands below yourself before
relying on this — treat it as reviewed-but-unverified until then.

## Run it locally

```bash
cp .env.example .env
# edit .env: set JWT_SECRET and FIELD_ENCRYPTION_KEY (commands are in the file's comments)

docker compose up --build
```

- Frontend: http://localhost:3000
- Backend: http://localhost:8000/api/health
- Postgres: localhost:5432 (dev only — not exposed in production)

The backend container runs `alembic upgrade head` automatically on startup.

## Run backend tests

Tests need a real Postgres database (UUID/ARRAY/Enum columns aren't
SQLite-compatible). With `docker compose up` already running:

```bash
docker compose exec postgres psql -U fitness -c "CREATE DATABASE fitness_coach_test;"
docker compose exec backend pytest
```

## Seed the Indian food starter database (Phase 2)

```bash
docker compose exec backend python -m app.db.seed_foods
```

Every seeded food is inserted with `is_verified=False` — the frontend shows
an "estimated" badge for these. Cross-check your most-logged staples
against IFCT/USDA before trusting the numbers for real tracking; see the
docstring in `backend/app/db/seed_foods.py` for details.

## Seed the exercise database (Phase 4)

```bash
docker compose exec backend python -m app.db.seed_exercises
```

## Project layout

```
backend/    FastAPI app, SQLAlchemy models, Alembic migrations, tests
frontend/   Next.js PWA
infra/      reverse proxy + postgres init (filled in during Phase 9)
```

## Generating secrets

```bash
# JWT_SECRET
python -c "import secrets; print(secrets.token_urlsafe(48))"

# FIELD_ENCRYPTION_KEY (used from Phase 5 onward to encrypt AI provider API keys)
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

## Notes

- Progress photos, once added (Phase 8), are never served from a public
  path — always through an authenticated backend endpoint.
- AI providers are entirely optional; every core feature (logging food,
  workouts, weight, water) works with zero providers configured.
- Don't commit `.env`. `.env.example` documents every variable with no real
  values.
