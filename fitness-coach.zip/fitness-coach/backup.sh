#!/usr/bin/env bash
# Timestamped backup of the Postgres database and progress-photo storage
# volume. Intended to be run via cron on the VPS, e.g.:
#   0 3 * * * /path/to/fitness-coach/backup.sh >> /var/log/fitness-backup.log 2>&1
#
# Restore instructions are at the bottom of this file (as comments).

set -euo pipefail

BACKUP_DIR="${BACKUP_DIR:-./backups}"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.prod.yml}"

mkdir -p "$BACKUP_DIR"

echo "[$TIMESTAMP] Starting backup..."

# --- Database ---
DB_BACKUP_PATH="$BACKUP_DIR/db-$TIMESTAMP.sql.gz"
docker compose -f "$COMPOSE_FILE" exec -T postgres \
  pg_dump -U "${POSTGRES_USER:-fitness}" "${POSTGRES_DB:-fitness_coach}" \
  | gzip > "$DB_BACKUP_PATH"
echo "Database backup written to $DB_BACKUP_PATH"

# --- Progress photos ---
PHOTOS_BACKUP_PATH="$BACKUP_DIR/photos-$TIMESTAMP.tar.gz"
docker run --rm \
  -v "$(basename "$(pwd)")_photo_storage:/data" \
  -v "$(pwd)/$BACKUP_DIR:/backup" \
  alpine tar czf "/backup/photos-$TIMESTAMP.tar.gz" -C /data .
echo "Photo storage backup written to $PHOTOS_BACKUP_PATH"

# Keep the last 14 daily backups, delete anything older.
find "$BACKUP_DIR" -name "db-*.sql.gz" -mtime +14 -delete
find "$BACKUP_DIR" -name "photos-*.tar.gz" -mtime +14 -delete

echo "Backup complete."

# ─────────────────────────────────────────────────────────────────────
# RESTORE INSTRUCTIONS
#
# Database:
#   gunzip -c backups/db-<timestamp>.sql.gz | \
#     docker compose -f docker-compose.prod.yml exec -T postgres \
#     psql -U fitness fitness_coach
#
# Photo storage (stop the backend first so nothing writes mid-restore):
#   docker compose -f docker-compose.prod.yml stop backend
#   docker run --rm \
#     -v <project>_photo_storage:/data \
#     -v "$(pwd)/backups:/backup" \
#     alpine sh -c "rm -rf /data/* && tar xzf /backup/photos-<timestamp>.tar.gz -C /data"
#   docker compose -f docker-compose.prod.yml start backend
# ─────────────────────────────────────────────────────────────────────
