import enum
import uuid
from datetime import date as date_type

from sqlalchemy import Date, Enum, Float, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin, UUIDPK
from app.db.models.food import RawCooked, Unit


class MealType(str, enum.Enum):
    BREAKFAST = "BREAKFAST"
    LUNCH = "LUNCH"
    DINNER = "DINNER"
    SNACK = "SNACK"
    PRE_WORKOUT = "PRE_WORKOUT"
    POST_WORKOUT = "POST_WORKOUT"


class Meal(UUIDPK, TimestampMixin, Base):
    __tablename__ = "meals"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    date: Mapped[date_type] = mapped_column(Date, index=True)
    meal_type: Mapped[MealType] = mapped_column(Enum(MealType, name="meal_type_enum"))

    items: Mapped[list["MealItem"]] = relationship(
        back_populates="meal", cascade="all, delete-orphan"
    )


class MealItem(UUIDPK, Base):
    """
    Nutrition values are snapshotted at log time (calories_snapshot etc.)
    so that later edits to a food's nutrition data, or deletion of a custom
    food, never silently rewrite historical diary entries.
    """

    __tablename__ = "meal_items"

    meal_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("meals.id", ondelete="CASCADE"), index=True
    )
    food_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("foods.id", ondelete="SET NULL"), nullable=True
    )
    custom_food_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("custom_foods.id", ondelete="SET NULL"),
        nullable=True,
    )
    recipe_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("recipes.id", ondelete="SET NULL"), nullable=True
    )
    label_snapshot: Mapped[str] = mapped_column(
        default=""
    )  # e.g. "Chicken" — kept even if the source food is later deleted
    quantity: Mapped[float] = mapped_column(Float)
    unit: Mapped[Unit] = mapped_column(Enum(Unit, name="unit_enum"))
    raw_cooked: Mapped[RawCooked] = mapped_column(
        Enum(RawCooked, name="raw_cooked_enum")
    )

    calories_snapshot: Mapped[float] = mapped_column(Float)
    protein_snapshot: Mapped[float] = mapped_column(Float)
    carbs_snapshot: Mapped[float] = mapped_column(Float)
    fat_snapshot: Mapped[float] = mapped_column(Float)

    meal: Mapped["Meal"] = relationship(back_populates="items")
