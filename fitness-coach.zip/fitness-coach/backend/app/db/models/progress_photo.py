import enum
import uuid
from datetime import date as date_type

from sqlalchemy import Date, Enum, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, TimestampMixin, UUIDPK


class PhotoAngle(str, enum.Enum):
    FRONT = "FRONT"
    SIDE = "SIDE"
    BACK = "BACK"


class ProgressPhoto(UUIDPK, TimestampMixin, Base):
    """
    storage_key is a path relative to settings.PROGRESS_PHOTO_STORAGE_DIR —
    never a public URL. The only way to retrieve the actual image bytes is
    GET /progress-photos/{id}/image, which checks ownership before reading
    anything from disk. Deleting a photo removes both the row and the file
    on disk (see api/progress_photos.py) — sensitive personal photos don't
    get a soft-delete grace period the way diary entries do.
    """

    __tablename__ = "progress_photos"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    date: Mapped[date_type] = mapped_column(Date, index=True)
    angle: Mapped[PhotoAngle] = mapped_column(Enum(PhotoAngle, name="photo_angle_enum"))
    storage_key: Mapped[str] = mapped_column(String(300))
    content_type: Mapped[str] = mapped_column(String(50))
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
