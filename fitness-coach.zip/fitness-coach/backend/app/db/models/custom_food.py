import uuid

from sqlalchemy import Enum, Float, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, TimestampMixin, UUIDPK
from app.db.models.food import RawCooked, Unit


class CustomFood(UUIDPK, TimestampMixin, Base):
    __tablename__ = "custom_foods"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    name: Mapped[str] = mapped_column(String(200))
    brand: Mapped[str | None] = mapped_column(String(120), nullable=True)
    serving_size: Mapped[float] = mapped_column(Float)
    unit: Mapped[Unit] = mapped_column(Enum(Unit, name="unit_enum"))
    calories: Mapped[float] = mapped_column(Float)
    protein_g: Mapped[float] = mapped_column(Float)
    carbs_g: Mapped[float] = mapped_column(Float)
    fat_g: Mapped[float] = mapped_column(Float)
    fiber_g: Mapped[float | None] = mapped_column(Float, nullable=True)
    sugar_g: Mapped[float | None] = mapped_column(Float, nullable=True)
    sodium_mg: Mapped[float | None] = mapped_column(Float, nullable=True)
    raw_cooked: Mapped[RawCooked] = mapped_column(
        Enum(RawCooked, name="raw_cooked_enum")
    )
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
