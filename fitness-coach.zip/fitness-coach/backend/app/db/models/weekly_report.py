import uuid
from datetime import date as date_type, datetime

from sqlalchemy import Date, DateTime, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, UUIDPK, utcnow


class WeeklyReport(UUIDPK, Base):
    """
    summary_json and next_week_targets_json are freeform JSON strings (shape
    documented in report_engine.py) — kept as text rather than typed columns
    since the report structure may evolve without needing a migration.
    """

    __tablename__ = "weekly_reports"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    week_start: Mapped[date_type] = mapped_column(Date)
    week_end: Mapped[date_type] = mapped_column(Date)
    summary_json: Mapped[str] = mapped_column(Text)
    conclusion: Mapped[str] = mapped_column(Text)
    next_week_targets_json: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
