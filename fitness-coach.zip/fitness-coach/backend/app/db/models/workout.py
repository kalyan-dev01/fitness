import enum
import uuid
from datetime import date as date_type, datetime

from sqlalchemy import Boolean, Date, DateTime, Enum, Float, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin, UUIDPK


class MuscleGroup(str, enum.Enum):
    CHEST = "CHEST"
    BACK = "BACK"
    SHOULDERS = "SHOULDERS"
    LEGS = "LEGS"
    ARMS = "ARMS"
    CORE = "CORE"
    OTHER = "OTHER"


class Exercise(UUIDPK, TimestampMixin, Base):
    """
    Predefined exercise database, seeded once (see seed_exercises.py).
    `user_id` is set only for custom exercises a user adds themselves —
    null means it's part of the shared predefined set.
    """

    __tablename__ = "exercises"

    name: Mapped[str] = mapped_column(String(150), index=True)
    muscle_group: Mapped[MuscleGroup] = mapped_column(
        Enum(MuscleGroup, name="muscle_group_enum")
    )
    is_custom: Mapped[bool] = mapped_column(Boolean, default=False)
    user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=True
    )


class WorkoutSession(UUIDPK, TimestampMixin, Base):
    __tablename__ = "workout_sessions"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    date: Mapped[date_type] = mapped_column(Date, index=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    exercises: Mapped[list["WorkoutExercise"]] = relationship(
        back_populates="session", cascade="all, delete-orphan", order_by="WorkoutExercise.order_index"
    )


class WorkoutExercise(UUIDPK, Base):
    __tablename__ = "workout_exercises"

    session_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("workout_sessions.id", ondelete="CASCADE"), index=True
    )
    exercise_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("exercises.id", ondelete="RESTRICT")
    )
    order_index: Mapped[int] = mapped_column(Integer, default=0)

    session: Mapped["WorkoutSession"] = relationship(back_populates="exercises")
    sets: Mapped[list["ExerciseSet"]] = relationship(
        back_populates="workout_exercise", cascade="all, delete-orphan",
        order_by="ExerciseSet.set_number",
    )


class ExerciseSet(UUIDPK, Base):
    __tablename__ = "exercise_sets"

    workout_exercise_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("workout_exercises.id", ondelete="CASCADE"), index=True
    )
    set_number: Mapped[int] = mapped_column(Integer)
    weight_kg: Mapped[float] = mapped_column(Float)
    reps: Mapped[int] = mapped_column(Integer)
    rpe: Mapped[float | None] = mapped_column(Float, nullable=True)
    rir: Mapped[int | None] = mapped_column(Integer, nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_pr: Mapped[bool] = mapped_column(Boolean, default=False)

    workout_exercise: Mapped["WorkoutExercise"] = relationship(back_populates="sets")
