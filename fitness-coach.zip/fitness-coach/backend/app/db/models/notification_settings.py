import uuid

from sqlalchemy import Boolean, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, TimestampMixin, UUIDPK


class NotificationSettings(UUIDPK, TimestampMixin, Base):
    """
    One row per user. These flags only control in-app reminder banners
    shown while the app is open (see frontend NotificationScheduler) —
    true background push notifications need a push service (VAPID keys +
    service worker push subscriptions) which isn't implemented; see the
    README note in Phase 9 for why that's out of scope for this pass.
    """

    __tablename__ = "notification_settings"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), unique=True
    )
    remind_log_weight: Mapped[bool] = mapped_column(Boolean, default=True)
    remind_drink_water: Mapped[bool] = mapped_column(Boolean, default=True)
    remind_workout: Mapped[bool] = mapped_column(Boolean, default=False)
    remind_log_meals: Mapped[bool] = mapped_column(Boolean, default=True)
    remind_weekly_report: Mapped[bool] = mapped_column(Boolean, default=True)
