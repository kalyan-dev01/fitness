import enum
import uuid
from datetime import date as date_type, datetime

from sqlalchemy import Boolean, Date, DateTime, Enum, ForeignKey, Integer, String, Text
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin, UUIDPK, utcnow


class ProviderHealthStatus(str, enum.Enum):
    HEALTHY = "HEALTHY"
    RATE_LIMITED = "RATE_LIMITED"
    QUOTA_EXHAUSTED = "QUOTA_EXHAUSTED"
    INVALID_KEY = "INVALID_KEY"
    UNAVAILABLE = "UNAVAILABLE"
    DISABLED = "DISABLED"
    UNKNOWN = "UNKNOWN"


class AIProvider(UUIDPK, TimestampMixin, Base):
    """
    One row per configured provider (Gemini, Groq, OpenRouter, ...).
    The API key itself lives in AIProviderCredential, never here — this
    table is safe to query/log/display without redaction concerns beyond
    the usual.
    """

    __tablename__ = "ai_providers"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    name: Mapped[str] = mapped_column(String(60))  # e.g. "gemini", "groq"
    display_name: Mapped[str] = mapped_column(String(100))
    base_url: Mapped[str | None] = mapped_column(String(300), nullable=True)
    model: Mapped[str | None] = mapped_column(String(150), nullable=True)
    is_enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    is_free_only: Mapped[bool] = mapped_column(
        Boolean, default=True
    )  # gates participation in AUTOMATIC fallback — see ProviderManager
    priority: Mapped[int] = mapped_column(Integer, default=100)  # lower = tried first
    auto_fallback_enabled: Mapped[bool] = mapped_column(Boolean, default=False)

    credential: Mapped["AIProviderCredential"] = relationship(
        back_populates="provider", uselist=False, cascade="all, delete-orphan"
    )
    health: Mapped["AIProviderHealth"] = relationship(
        back_populates="provider", uselist=False, cascade="all, delete-orphan"
    )


class AIProviderCredential(UUIDPK, Base):
    """
    Encrypted at rest via app.core.security.encrypt_secret/decrypt_secret
    (Fernet symmetric encryption, key from FIELD_ENCRYPTION_KEY env var —
    never the database itself). key_hint is the only form ever sent to the
    frontend or written to logs.
    """

    __tablename__ = "ai_provider_credentials"

    provider_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("ai_providers.id", ondelete="CASCADE"), unique=True
    )
    encrypted_api_key: Mapped[str] = mapped_column(Text)
    key_hint: Mapped[str] = mapped_column(String(30))  # e.g. "******...ab12"

    provider: Mapped["AIProvider"] = relationship(back_populates="credential")


class AIProviderModel(UUIDPK, Base):
    __tablename__ = "ai_provider_models"

    provider_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("ai_providers.id", ondelete="CASCADE"), index=True
    )
    model_name: Mapped[str] = mapped_column(String(150))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    last_refreshed_at: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )


class AIProviderHealth(UUIDPK, Base):
    __tablename__ = "ai_provider_health"

    provider_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("ai_providers.id", ondelete="CASCADE"), unique=True
    )
    status: Mapped[ProviderHealthStatus] = mapped_column(
        Enum(ProviderHealthStatus, name="provider_health_status_enum"),
        default=ProviderHealthStatus.UNKNOWN,
    )
    last_tested_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_success_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_failure_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_latency_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    last_error_category: Mapped[str | None] = mapped_column(String(100), nullable=True)
    cooldown_until: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    provider: Mapped["AIProvider"] = relationship(back_populates="health")


class AIProviderUsage(UUIDPK, Base):
    """One row per provider per day — incremented, not appended per-request."""

    __tablename__ = "ai_provider_usage"

    provider_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("ai_providers.id", ondelete="CASCADE"), index=True
    )
    date: Mapped[date_type] = mapped_column(Date)
    requests: Mapped[int] = mapped_column(Integer, default=0)
    successes: Mapped[int] = mapped_column(Integer, default=0)
    failures: Mapped[int] = mapped_column(Integer, default=0)
    input_tokens_approx: Mapped[int] = mapped_column(Integer, default=0)
    output_tokens_approx: Mapped[int] = mapped_column(Integer, default=0)
    total_latency_ms: Mapped[int] = mapped_column(Integer, default=0)  # divide by requests for avg


class AIProviderEvent(UUIDPK, Base):
    __tablename__ = "ai_provider_events"

    provider_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("ai_providers.id", ondelete="CASCADE"), index=True
    )
    event_type: Mapped[str] = mapped_column(String(50))  # e.g. "fallback_triggered", "test_passed"
    detail: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
