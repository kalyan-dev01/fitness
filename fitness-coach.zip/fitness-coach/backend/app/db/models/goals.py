import enum
import uuid
from datetime import datetime

from sqlalchemy import Boolean, DateTime, Enum, Float, ForeignKey, Integer
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin, UUIDPK


class GoalType(str, enum.Enum):
    CUT = "CUT"
    MAINTAIN = "MAINTAIN"
    LEAN_BULK = "LEAN_BULK"
    BULK = "BULK"


class Goal(UUIDPK, TimestampMixin, Base):
    """
    A goal record is versioned: starting a new goal ends the previous one
    (sets ended_at) rather than overwriting it, so goal history is preserved
    for the weekly report / "why" analysis later.
    """

    __tablename__ = "goals"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    goal_type: Mapped[GoalType] = mapped_column(Enum(GoalType, name="goal_type_enum"))
    weight_kg: Mapped[float | None] = mapped_column(Float, nullable=True)
    goal_weight_kg: Mapped[float | None] = mapped_column(Float, nullable=True)

    calorie_target: Mapped[int | None] = mapped_column(Integer, nullable=True)
    protein_target_g: Mapped[int | None] = mapped_column(Integer, nullable=True)
    carb_target_g: Mapped[int | None] = mapped_column(Integer, nullable=True)
    fat_target_g: Mapped[int | None] = mapped_column(Integer, nullable=True)
    is_auto_calculated: Mapped[bool] = mapped_column(Boolean, default=True)

    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    ended_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    user: Mapped["User"] = relationship(back_populates="goals")  # noqa: F821
