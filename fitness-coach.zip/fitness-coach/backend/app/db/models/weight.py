import uuid
from datetime import date as date_type

from sqlalchemy import Date, Float, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base, TimestampMixin, UUIDPK


class WeightEntry(UUIDPK, TimestampMixin, Base):
    """
    Manually recorded — the user doesn't own a scale, measurements are
    taken elsewhere (e.g. at the gym) and logged after the fact. No
    automatic sync of any kind.
    """

    __tablename__ = "weight_entries"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True
    )
    date: Mapped[date_type] = mapped_column(Date, index=True)
    time_of_day: Mapped[str | None] = mapped_column(String(20), nullable=True)
    weight_kg: Mapped[float] = mapped_column(Float)
    source: Mapped[str | None] = mapped_column(String(60), nullable=True)
    note: Mapped[str | None] = mapped_column(String(500), nullable=True)
