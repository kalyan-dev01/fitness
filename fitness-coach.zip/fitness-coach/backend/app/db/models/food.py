import enum
import uuid

from sqlalchemy import Boolean, Enum, Float, ForeignKey, String
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, TimestampMixin, UUIDPK


class FoodSource(str, enum.Enum):
    IFCT = "IFCT"          # Indian Food Composition Tables
    USDA = "USDA"
    MANUAL = "MANUAL"      # entered by app maintainers, not from a primary source


class RawCooked(str, enum.Enum):
    RAW = "RAW"
    COOKED = "COOKED"
    NA = "NA"  # doesn't apply (e.g. oil, sugar, packaged branded items)


class Unit(str, enum.Enum):
    G = "g"
    ML = "ml"
    PIECE = "piece"
    TSP = "tsp"
    TBSP = "tbsp"
    CUP = "cup"
    SERVING = "serving"


class Food(UUIDPK, TimestampMixin, Base):
    """
    Shared nutrition database (not user-owned). Seeded from IFCT/USDA data
    in Phase 2's seed script. `is_verified` distinguishes values pulled from
    a primary source from anything entered manually as a best-effort
    estimate — the frontend must show this distinction, never present an
    estimate as authoritative.
    """

    __tablename__ = "foods"

    name: Mapped[str] = mapped_column(String(200), index=True)
    brand: Mapped[str | None] = mapped_column(String(120), nullable=True)
    source: Mapped[FoodSource] = mapped_column(Enum(FoodSource, name="food_source_enum"))
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    default_unit: Mapped[Unit] = mapped_column(Enum(Unit, name="unit_enum"))

    servings: Mapped[list["FoodServing"]] = relationship(
        back_populates="food", cascade="all, delete-orphan"
    )


class FoodServing(UUIDPK, Base):
    """
    Nutrition values per 100 units of `unit` (100g / 100ml / 1 piece etc.),
    scoped to a specific raw/cooked state. A food like "chicken" has two
    FoodServing rows (RAW and COOKED) with different values — the app must
    never silently mix them (see section 9 of the spec).
    """

    __tablename__ = "food_servings"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    food_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("foods.id", ondelete="CASCADE"), index=True
    )
    unit: Mapped[Unit] = mapped_column(Enum(Unit, name="unit_enum"))
    raw_cooked: Mapped[RawCooked] = mapped_column(
        Enum(RawCooked, name="raw_cooked_enum")
    )
    grams_per_unit: Mapped[float | None] = mapped_column(Float, nullable=True)

    # Values per 100 base-units (100g/100ml) or per 1 piece/serving, per unit above.
    calories: Mapped[float] = mapped_column(Float)
    protein_g: Mapped[float] = mapped_column(Float)
    carbs_g: Mapped[float] = mapped_column(Float)
    fat_g: Mapped[float] = mapped_column(Float)
    fiber_g: Mapped[float | None] = mapped_column(Float, nullable=True)
    sugar_g: Mapped[float | None] = mapped_column(Float, nullable=True)
    sodium_mg: Mapped[float | None] = mapped_column(Float, nullable=True)

    food: Mapped["Food"] = relationship(back_populates="servings")
