"""
Import every model module here so that:
  1. Alembic's autogenerate can see the full metadata.
  2. SQLAlchemy can resolve string-based relationship() references between
     models defined in different files.

Phase 1 models only. Later phases append their model modules to this file.
"""
from app.db.models.goals import Goal  # noqa: F401
from app.db.models.profile import UserProfile  # noqa: F401
from app.db.models.user import User  # noqa: F401

# Phase 2 — Nutrition
from app.db.models.food import Food, FoodServing  # noqa: F401
from app.db.models.custom_food import CustomFood  # noqa: F401
from app.db.models.recipe import Recipe, RecipeIngredient  # noqa: F401
from app.db.models.meal import Meal, MealItem  # noqa: F401

# Phase 3 — Weight & Hydration
from app.db.models.weight import WeightEntry  # noqa: F401
from app.db.models.water import WaterEntry  # noqa: F401

# Phase 4 — Workout
from app.db.models.workout import (  # noqa: F401
    Exercise,
    ExerciseSet,
    WorkoutExercise,
    WorkoutSession,
)

# Phase 5 — AI Provider Manager
from app.db.models.ai_provider import (  # noqa: F401
    AIProvider,
    AIProviderCredential,
    AIProviderEvent,
    AIProviderHealth,
    AIProviderModel,
    AIProviderUsage,
)

# Phase 6 — AI Coach
from app.db.models.ai_conversation import AIConversation, AIMessage  # noqa: F401
from app.db.models.ai_recommendation import AIRecommendation  # noqa: F401

# Phase 7 — Reports
from app.db.models.weekly_report import WeeklyReport  # noqa: F401

# Phase 8 — Progress Photos
from app.db.models.progress_photo import ProgressPhoto  # noqa: F401

# Phase 9 — PWA & Deployment
from app.db.models.notification_settings import NotificationSettings  # noqa: F401
