"""
Seed a starter set of common Indian foods.

IMPORTANT — READ BEFORE RUNNING IN PRODUCTION:
Every row below is inserted with source=MANUAL and is_verified=False. These
values are reasonable ballpark figures assembled from memory, NOT pulled
live from IFCT (Indian Food Composition Tables) or USDA FoodData Central.
Per spec section 8 ("Do NOT invent nutrition values and present them as
authoritative"), the frontend must surface is_verified=False foods with a
visible "estimated" label, and before relying on this data for real macro
tracking you should cross-check the values that matter most to you (your
most-logged staples) against IFCT/USDA directly and mark them verified.

This is a starter list (staples + common proteins), not the full spec-9
category list (fruits, vegetables, full cooking-ingredient set) — extend
FOODS below following the same pattern as more categories are added.

Run with:
    docker compose exec backend python -m app.db.seed_foods
"""
from app.db.models.food import Food, FoodServing, FoodSource, RawCooked, Unit
from app.db.session import SessionLocal

# (name, default_unit, [(unit, raw_cooked, calories, protein_g, carbs_g, fat_g, fiber_g)])
# Values are per 100g/100ml, or per 1 piece/tsp/tbsp/cup/serving as noted by unit.
FOODS: list[tuple[str, Unit, list[tuple[Unit, RawCooked, float, float, float, float, float | None]]]] = [
    ("Chicken breast", Unit.G, [
        (Unit.G, RawCooked.RAW, 165, 31.0, 0.0, 3.6, 0.0),
        (Unit.G, RawCooked.COOKED, 239, 41.0, 0.0, 5.0, 0.0),
    ]),
    ("Rice, white", Unit.G, [
        (Unit.G, RawCooked.RAW, 365, 7.1, 80.0, 0.7, 1.3),
        (Unit.G, RawCooked.COOKED, 130, 2.7, 28.0, 0.3, 0.4),
    ]),
    ("Roti (whole wheat)", Unit.PIECE, [
        (Unit.PIECE, RawCooked.COOKED, 120, 3.6, 22.0, 2.5, 3.0),
    ]),
    ("Paneer", Unit.G, [
        (Unit.G, RawCooked.NA, 265, 18.3, 1.2, 20.8, 0.0),
    ]),
    ("Dal (cooked, generic)", Unit.G, [
        (Unit.G, RawCooked.COOKED, 116, 9.0, 20.0, 0.4, 7.6),
    ]),
    ("Idli", Unit.PIECE, [
        (Unit.PIECE, RawCooked.COOKED, 39, 1.6, 7.9, 0.2, 0.4),
    ]),
    ("Dosa, plain", Unit.PIECE, [
        (Unit.PIECE, RawCooked.COOKED, 133, 2.7, 22.0, 3.7, 0.5),
    ]),
    ("Poha", Unit.G, [
        (Unit.G, RawCooked.COOKED, 130, 2.5, 24.0, 3.0, 0.7),
    ]),
    ("Oats, rolled", Unit.G, [
        (Unit.G, RawCooked.RAW, 389, 16.9, 66.3, 6.9, 10.6),
        (Unit.G, RawCooked.COOKED, 71, 2.5, 12.0, 1.5, 1.7),
    ]),
    ("Eggs, whole", Unit.PIECE, [
        (Unit.PIECE, RawCooked.COOKED, 72, 6.3, 0.4, 4.8, 0.0),
    ]),
    ("Curd (dahi), plain", Unit.G, [
        (Unit.G, RawCooked.NA, 60, 3.5, 4.7, 3.3, 0.0),
    ]),
    ("Greek yogurt, plain", Unit.G, [
        (Unit.G, RawCooked.NA, 59, 10.0, 3.6, 0.4, 0.0),
    ]),
    ("Rajma (kidney beans, cooked)", Unit.G, [
        (Unit.G, RawCooked.COOKED, 127, 8.7, 22.8, 0.5, 6.4),
    ]),
    ("Chana (chickpeas, cooked)", Unit.G, [
        (Unit.G, RawCooked.COOKED, 164, 8.9, 27.4, 2.6, 7.6),
    ]),
    ("Soya chunks (dry)", Unit.G, [
        (Unit.G, RawCooked.RAW, 345, 52.0, 33.0, 0.5, 13.0),
    ]),
    ("Ghee", Unit.TSP, [
        (Unit.TSP, RawCooked.NA, 40, 0.0, 0.0, 4.5, 0.0),
    ]),
    ("Cooking oil (generic)", Unit.TSP, [
        (Unit.TSP, RawCooked.NA, 40, 0.0, 0.0, 4.5, 0.0),
    ]),
    ("Sugar, white", Unit.TSP, [
        (Unit.TSP, RawCooked.NA, 16, 0.0, 4.2, 0.0, 0.0),
    ]),
    ("Milk, whole", Unit.ML, [
        (Unit.ML, RawCooked.NA, 61, 3.2, 4.8, 3.3, 0.0),
    ]),
    ("Banana", Unit.PIECE, [
        (Unit.PIECE, RawCooked.NA, 105, 1.3, 27.0, 0.4, 3.1),
    ]),
]


def seed() -> None:
    db = SessionLocal()
    try:
        for name, default_unit, servings in FOODS:
            existing = db.query(Food).filter(Food.name == name).first()
            if existing is not None:
                print(f"skip (exists): {name}")
                continue
            food = Food(
                name=name,
                source=FoodSource.MANUAL,
                is_verified=False,
                default_unit=default_unit,
            )
            for unit, raw_cooked, calories, protein_g, carbs_g, fat_g, fiber_g in servings:
                food.servings.append(
                    FoodServing(
                        unit=unit,
                        raw_cooked=raw_cooked,
                        calories=calories,
                        protein_g=protein_g,
                        carbs_g=carbs_g,
                        fat_g=fat_g,
                        fiber_g=fiber_g,
                    )
                )
            db.add(food)
            print(f"seeded: {name}")
        db.commit()
    finally:
        db.close()


if __name__ == "__main__":
    seed()
