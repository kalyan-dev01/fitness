"""
Seed the predefined exercise database.

Run with:
    docker compose exec backend python -m app.db.seed_exercises
"""
from app.db.models.workout import Exercise, MuscleGroup
from app.db.session import SessionLocal

EXERCISES: dict[MuscleGroup, list[str]] = {
    MuscleGroup.CHEST: [
        "Bench Press", "Incline Dumbbell Press", "Cable Fly", "Dips", "Push-up",
    ],
    MuscleGroup.BACK: [
        "Lat Pulldown", "Barbell Row", "Seated Cable Row", "Pull-up", "Deadlift",
    ],
    MuscleGroup.SHOULDERS: [
        "Overhead Press", "Lateral Raise", "Face Pull", "Rear Delt Fly",
    ],
    MuscleGroup.LEGS: [
        "Squat", "Leg Press", "Leg Curl", "Leg Extension", "Romanian Deadlift",
        "Calf Raise",
    ],
    MuscleGroup.ARMS: [
        "Bicep Curl", "Hammer Curl", "Triceps Pushdown", "Skull Crusher",
    ],
    MuscleGroup.CORE: [
        "Plank", "Hanging Leg Raise", "Cable Crunch",
    ],
}


def seed() -> None:
    db = SessionLocal()
    try:
        for muscle_group, names in EXERCISES.items():
            for name in names:
                existing = (
                    db.query(Exercise)
                    .filter(Exercise.name == name, Exercise.user_id.is_(None))
                    .first()
                )
                if existing is not None:
                    print(f"skip (exists): {name}")
                    continue
                db.add(Exercise(name=name, muscle_group=muscle_group, is_custom=False))
                print(f"seeded: {name} ({muscle_group.value})")
        db.commit()
    finally:
        db.close()


if __name__ == "__main__":
    seed()
