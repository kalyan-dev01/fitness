import uuid
from datetime import datetime

from pydantic import BaseModel, Field

from app.db.models.goals import GoalType


class GoalCreate(BaseModel):
    goal_type: GoalType
    weight_kg: float | None = Field(default=None, gt=0, lt=400)
    goal_weight_kg: float | None = Field(default=None, gt=0, lt=400)
    calorie_target: int | None = Field(default=None, gt=0, lt=10000)
    protein_target_g: int | None = Field(default=None, ge=0, lt=1000)
    carb_target_g: int | None = Field(default=None, ge=0, lt=2000)
    fat_target_g: int | None = Field(default=None, ge=0, lt=1000)
    is_auto_calculated: bool = True


class GoalOut(BaseModel):
    id: uuid.UUID
    user_id: uuid.UUID
    goal_type: GoalType
    weight_kg: float | None
    goal_weight_kg: float | None
    calorie_target: int | None
    protein_target_g: int | None
    carb_target_g: int | None
    fat_target_g: int | None
    is_auto_calculated: bool
    started_at: datetime
    ended_at: datetime | None

    model_config = {"from_attributes": True}
