import uuid

from pydantic import BaseModel, Field, model_validator

from app.db.models.food import Unit


class RecipeIngredientCreate(BaseModel):
    food_id: uuid.UUID | None = None
    custom_food_id: uuid.UUID | None = None
    quantity: float = Field(gt=0)
    unit: Unit

    @model_validator(mode="after")
    def exactly_one_food_reference(self) -> "RecipeIngredientCreate":
        if bool(self.food_id) == bool(self.custom_food_id):
            raise ValueError(
                "Exactly one of food_id or custom_food_id must be set"
            )
        return self


class RecipeCreate(BaseModel):
    name: str = Field(max_length=200)
    servings: int = Field(default=1, ge=1, le=100)
    notes: str | None = None
    ingredients: list[RecipeIngredientCreate] = Field(min_length=1)


class RecipeIngredientOut(BaseModel):
    id: uuid.UUID
    food_id: uuid.UUID | None
    custom_food_id: uuid.UUID | None
    quantity: float
    unit: Unit

    model_config = {"from_attributes": True}


class RecipeOut(BaseModel):
    id: uuid.UUID
    user_id: uuid.UUID
    name: str
    servings: int
    notes: str | None
    ingredients: list[RecipeIngredientOut]

    model_config = {"from_attributes": True}


class RecipeNutritionOut(BaseModel):
    total: dict
    per_serving: dict
