import uuid
from datetime import datetime

from pydantic import BaseModel, Field


class CoachMessageCreate(BaseModel):
    message: str = Field(min_length=1, max_length=2000)
    conversation_id: uuid.UUID | None = None
    provider_id: uuid.UUID | None = None  # explicit override, e.g. user picked a paid provider


class CoachMessageOut(BaseModel):
    conversation_id: uuid.UUID
    reply: str
    provider_name: str | None
    model: str | None
    ai_unavailable: bool = False


class AIMessageOut(BaseModel):
    id: uuid.UUID
    role: str
    content: str
    provider_name: str | None
    model: str | None
    created_at: datetime

    model_config = {"from_attributes": True}


class AIConversationOut(BaseModel):
    id: uuid.UUID
    title: str | None
    messages: list[AIMessageOut]

    model_config = {"from_attributes": True}


class ParsedFoodItem(BaseModel):
    raw_name: str
    quantity: float
    unit: str
    raw_cooked: str = "NA"
    matched_food_id: uuid.UUID | None = None
    matched_food_name: str | None = None
    is_verified: bool | None = None
    calories: float | None = None
    protein_g: float | None = None
    carbs_g: float | None = None
    fat_g: float | None = None
    needs_manual_match: bool = False


class ParseFoodRequest(BaseModel):
    text: str = Field(min_length=1, max_length=1000)


class ParseFoodResponse(BaseModel):
    items: list[ParsedFoodItem]
    ai_unavailable: bool = False
