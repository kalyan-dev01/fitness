import uuid

from pydantic import BaseModel, Field

from app.db.models.profile import ActivityLevel, Sex


class ProfileBase(BaseModel):
    name: str | None = Field(default=None, max_length=120)
    age: int | None = Field(default=None, ge=10, le=120)
    sex: Sex | None = None
    height_cm: float | None = Field(default=None, gt=0, lt=300)
    activity_level: ActivityLevel | None = None
    training_frequency: int | None = Field(default=None, ge=0, le=14)
    dietary_preferences: list[str] | None = None
    foods_to_avoid: list[str] | None = None
    notes: str | None = None
    water_target_ml: int | None = Field(default=None, gt=0, le=10000)


class ProfileUpdate(ProfileBase):
    pass


class ProfileOut(ProfileBase):
    id: uuid.UUID
    user_id: uuid.UUID

    model_config = {"from_attributes": True}
