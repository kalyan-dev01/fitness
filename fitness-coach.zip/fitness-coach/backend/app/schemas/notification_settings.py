from pydantic import BaseModel


class NotificationSettingsUpdate(BaseModel):
    remind_log_weight: bool | None = None
    remind_drink_water: bool | None = None
    remind_workout: bool | None = None
    remind_log_meals: bool | None = None
    remind_weekly_report: bool | None = None


class NotificationSettingsOut(BaseModel):
    remind_log_weight: bool
    remind_drink_water: bool
    remind_workout: bool
    remind_log_meals: bool
    remind_weekly_report: bool

    model_config = {"from_attributes": True}
