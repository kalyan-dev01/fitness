import uuid
from datetime import date

from pydantic import BaseModel, Field


class WeightEntryCreate(BaseModel):
    date: date
    weight_kg: float = Field(gt=0, lt=400)
    time_of_day: str | None = Field(default=None, max_length=20)
    source: str | None = Field(default=None, max_length=60)
    note: str | None = Field(default=None, max_length=500)


class WeightEntryOut(WeightEntryCreate):
    id: uuid.UUID
    user_id: uuid.UUID

    model_config = {"from_attributes": True}


class WeightTrendOut(BaseModel):
    latest_kg: float | None
    latest_date: date | None
    change_from_previous_kg: float | None
    seven_day_avg_kg: float | None
    thirty_day_avg_kg: float | None
    thirty_day_change_kg: float | None
    goal_weight_kg: float | None = None
