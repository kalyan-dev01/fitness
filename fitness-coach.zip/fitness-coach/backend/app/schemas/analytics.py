from pydantic import BaseModel


class SeriesPoint(BaseModel):
    date: str
    value: float


class WeightSeriesOut(BaseModel):
    points: list[SeriesPoint]


class NutritionSeriesOut(BaseModel):
    calories: list[SeriesPoint]
    protein: list[SeriesPoint]


class VolumePoint(BaseModel):
    date: str
    volume: float


class ExerciseVolumeOut(BaseModel):
    exercise_id: str
    exercise_name: str
    points: list[VolumePoint]


class StrengthPoint(BaseModel):
    date: str
    best_weight_kg: float


class ExerciseStrengthOut(BaseModel):
    exercise_id: str
    exercise_name: str
    points: list[StrengthPoint]
