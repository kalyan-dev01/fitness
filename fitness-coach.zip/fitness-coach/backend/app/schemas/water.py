import uuid
from datetime import date, datetime

from pydantic import BaseModel, Field


class WaterEntryCreate(BaseModel):
    date: date
    ml: int = Field(gt=0, le=5000)


class WaterEntryOut(BaseModel):
    id: uuid.UUID
    user_id: uuid.UUID
    date: date
    ml: int
    logged_at: datetime

    model_config = {"from_attributes": True}


class WaterDailyOut(BaseModel):
    date: date
    total_ml: int
    target_ml: int | None
    entries: list[WaterEntryOut]
