import uuid
from datetime import date, datetime

from pydantic import BaseModel


class DailyReviewOut(BaseModel):
    date: date
    calories: float
    protein_g: float
    carbs_g: float
    fat_g: float
    calorie_target: int | None
    protein_target_g: int | None
    water_ml: int
    workout_logged: bool
    weight_kg: float | None
    review_text: str
    ai_unavailable: bool = False


class WeeklyReportOut(BaseModel):
    id: uuid.UUID | None = None
    week_start: date
    week_end: date
    avg_calories: float
    avg_protein_g: float
    calorie_target: int | None
    protein_target_g: int | None
    workouts_logged: int
    avg_water_ml: float
    weight_change_kg: float | None
    latest_weight_kg: float | None
    goal_type: str | None
    conclusion: str
    next_week_targets: dict
    ai_unavailable: bool = False
    created_at: datetime | None = None
