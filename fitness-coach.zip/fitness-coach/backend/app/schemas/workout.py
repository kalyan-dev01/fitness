import uuid
from datetime import date

from pydantic import BaseModel, Field


class ExerciseSetCreate(BaseModel):
    weight_kg: float = Field(ge=0, lt=1000)
    reps: int = Field(gt=0, lt=200)
    rpe: float | None = Field(default=None, ge=0, le=10)
    rir: int | None = Field(default=None, ge=0, le=20)
    notes: str | None = None


class WorkoutExerciseCreate(BaseModel):
    exercise_id: uuid.UUID
    sets: list[ExerciseSetCreate] = Field(min_length=1)


class WorkoutSessionCreate(BaseModel):
    date: date
    notes: str | None = None
    exercises: list[WorkoutExerciseCreate] = Field(default_factory=list)


class ExerciseSetOut(BaseModel):
    id: uuid.UUID
    set_number: int
    weight_kg: float
    reps: int
    rpe: float | None
    rir: int | None
    notes: str | None
    is_pr: bool

    model_config = {"from_attributes": True}


class WorkoutExerciseOut(BaseModel):
    id: uuid.UUID
    exercise_id: uuid.UUID
    order_index: int
    sets: list[ExerciseSetOut]

    model_config = {"from_attributes": True}


class WorkoutSessionOut(BaseModel):
    id: uuid.UUID
    user_id: uuid.UUID
    date: date
    notes: str | None
    exercises: list[WorkoutExerciseOut]

    model_config = {"from_attributes": True}


class ExerciseHistoryOut(BaseModel):
    exercise_id: uuid.UUID
    exercise_name: str
    best_weight_kg: float | None
    best_reps_at_best_weight: int | None
    best_volume: float | None
    last_session_date: date | None
    last_session_sets: list[ExerciseSetOut]


class ProgressionOut(BaseModel):
    status: str
    suggested_next_weight_kg: float | None
    reasoning: str
