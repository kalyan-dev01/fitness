import uuid
from datetime import date

from pydantic import BaseModel

from app.db.models.progress_photo import PhotoAngle


class ProgressPhotoOut(BaseModel):
    id: uuid.UUID
    date: date
    angle: PhotoAngle
    notes: str | None
    content_type: str

    model_config = {"from_attributes": True}
