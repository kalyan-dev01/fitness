import uuid

from pydantic import BaseModel, Field

from app.db.models.food import FoodSource, RawCooked, Unit


class FoodServingOut(BaseModel):
    id: uuid.UUID
    unit: Unit
    raw_cooked: RawCooked
    calories: float
    protein_g: float
    carbs_g: float
    fat_g: float
    fiber_g: float | None
    sugar_g: float | None
    sodium_mg: float | None

    model_config = {"from_attributes": True}


class FoodOut(BaseModel):
    id: uuid.UUID
    name: str
    brand: str | None
    source: FoodSource
    is_verified: bool
    default_unit: Unit
    servings: list[FoodServingOut]

    model_config = {"from_attributes": True}


class CustomFoodCreate(BaseModel):
    name: str = Field(max_length=200)
    brand: str | None = Field(default=None, max_length=120)
    serving_size: float = Field(gt=0)
    unit: Unit
    calories: float = Field(ge=0)
    protein_g: float = Field(ge=0)
    carbs_g: float = Field(ge=0)
    fat_g: float = Field(ge=0)
    fiber_g: float | None = Field(default=None, ge=0)
    sugar_g: float | None = Field(default=None, ge=0)
    sodium_mg: float | None = Field(default=None, ge=0)
    raw_cooked: RawCooked = RawCooked.NA
    notes: str | None = None


class CustomFoodOut(CustomFoodCreate):
    id: uuid.UUID
    user_id: uuid.UUID

    model_config = {"from_attributes": True}
