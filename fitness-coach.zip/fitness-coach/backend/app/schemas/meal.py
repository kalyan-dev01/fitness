import uuid
from datetime import date

from pydantic import BaseModel, Field, model_validator

from app.db.models.food import RawCooked, Unit
from app.db.models.meal import MealType


class MealItemCreate(BaseModel):
    food_id: uuid.UUID | None = None
    custom_food_id: uuid.UUID | None = None
    recipe_id: uuid.UUID | None = None
    quantity: float = Field(gt=0)
    unit: Unit
    raw_cooked: RawCooked = RawCooked.NA

    @model_validator(mode="after")
    def exactly_one_source(self) -> "MealItemCreate":
        sources = [self.food_id, self.custom_food_id, self.recipe_id]
        if sum(1 for s in sources if s is not None) != 1:
            raise ValueError(
                "Exactly one of food_id, custom_food_id, or recipe_id must be set"
            )
        return self


class MealCreate(BaseModel):
    date: date
    meal_type: MealType
    items: list[MealItemCreate] = Field(default_factory=list)


class MealItemOut(BaseModel):
    id: uuid.UUID
    food_id: uuid.UUID | None
    custom_food_id: uuid.UUID | None
    recipe_id: uuid.UUID | None
    label_snapshot: str
    quantity: float
    unit: Unit
    raw_cooked: RawCooked
    calories_snapshot: float
    protein_snapshot: float
    carbs_snapshot: float
    fat_snapshot: float

    model_config = {"from_attributes": True}


class MealOut(BaseModel):
    id: uuid.UUID
    user_id: uuid.UUID
    date: date
    meal_type: MealType
    items: list[MealItemOut]

    model_config = {"from_attributes": True}


class DailyNutritionSummary(BaseModel):
    date: date
    calories: float
    protein_g: float
    carbs_g: float
    fat_g: float
    meals: list[MealOut]
