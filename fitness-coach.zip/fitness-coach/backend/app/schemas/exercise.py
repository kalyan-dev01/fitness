import uuid

from pydantic import BaseModel, Field

from app.db.models.workout import MuscleGroup


class ExerciseCreate(BaseModel):
    name: str = Field(max_length=150)
    muscle_group: MuscleGroup


class ExerciseOut(BaseModel):
    id: uuid.UUID
    name: str
    muscle_group: MuscleGroup
    is_custom: bool

    model_config = {"from_attributes": True}
