import uuid
from datetime import datetime

from pydantic import BaseModel, Field

from app.db.models.ai_provider import ProviderHealthStatus


class AIProviderCreate(BaseModel):
    name: str = Field(max_length=60)
    display_name: str | None = None
    api_key: str = Field(min_length=1)
    base_url: str | None = None
    model: str | None = None
    is_free_only: bool = True
    priority: int = 100
    auto_fallback_enabled: bool = False


class AIProviderUpdate(BaseModel):
    display_name: str | None = None
    base_url: str | None = None
    model: str | None = None
    is_enabled: bool | None = None
    is_free_only: bool | None = None
    priority: int | None = None
    auto_fallback_enabled: bool | None = None
    api_key: str | None = None


class AIProviderHealthOut(BaseModel):
    status: ProviderHealthStatus
    last_tested_at: datetime | None
    last_success_at: datetime | None
    last_failure_at: datetime | None
    last_latency_ms: int | None
    last_error_category: str | None
    cooldown_until: datetime | None

    model_config = {"from_attributes": True}


class AIProviderOut(BaseModel):
    id: uuid.UUID
    name: str
    display_name: str
    base_url: str | None
    model: str | None
    is_enabled: bool
    is_free_only: bool
    priority: int
    auto_fallback_enabled: bool
    key_hint: str | None
    health: AIProviderHealthOut | None

    model_config = {"from_attributes": True}


class TestConnectionOut(BaseModel):
    success: bool
    model: str | None = None
    latency_ms: int | None = None
    error_category: str | None = None
    error_message: str | None = None


class ProviderUsageDayOut(BaseModel):
    date: str
    requests: int
    successes: int
    failures: int
    input_tokens_approx: int
    output_tokens_approx: int
    avg_latency_ms: int | None


class ProviderUsageOut(BaseModel):
    provider_id: uuid.UUID
    provider_name: str
    days: list[ProviderUsageDayOut]
