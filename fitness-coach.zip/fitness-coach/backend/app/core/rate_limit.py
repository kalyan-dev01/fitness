"""
A deliberately simple in-memory sliding-window rate limiter. Good enough
for a single-instance, single-VPS deployment (spec section 55/69 — no
Redis/extra services unless a real requirement appears). If this app is
ever horizontally scaled across multiple backend instances, this stops
being correct (each instance has its own counters) and should be swapped
for a shared store — that's a real limitation, not an oversight.
"""
import time
from collections import defaultdict, deque

from fastapi import HTTPException, Request, status


class InMemoryRateLimiter:
    def __init__(self, *, max_requests: int, window_seconds: int):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._hits: dict[str, deque] = defaultdict(deque)

    def check(self, key: str) -> None:
        now = time.monotonic()
        window = self._hits[key]
        while window and now - window[0] > self.window_seconds:
            window.popleft()
        if len(window) >= self.max_requests:
            raise HTTPException(
                status.HTTP_429_TOO_MANY_REQUESTS,
                "Too many requests. Please wait before trying again.",
            )
        window.append(now)


# Auth endpoints get a stricter limit than the general API — brute-force
# protection matters more there than anywhere else in a single-user app.
auth_rate_limiter = InMemoryRateLimiter(max_requests=10, window_seconds=60)


def rate_limit_by_ip(limiter: InMemoryRateLimiter):
    def dependency(request: Request) -> None:
        client_ip = request.client.host if request.client else "unknown"
        limiter.check(client_ip)

    return dependency
