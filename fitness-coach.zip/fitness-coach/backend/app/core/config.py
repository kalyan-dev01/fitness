"""
Application configuration.

All secrets/config come from environment variables (see .env.example).
Nothing here should contain a real secret value.
"""
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # App
    APP_NAME: str = "Fitness Coach"
    ENV: str = "development"  # development | production
    DEBUG: bool = True

    # Database
    DATABASE_URL: str = (
        "postgresql+psycopg2://fitness:fitness@localhost:5432/fitness_coach"
    )

    # Auth
    JWT_SECRET: str = "change-me-in-.env"  # noqa: S105 - placeholder default only
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 14  # 14 days
    COOKIE_NAME: str = "fc_session"
    COOKIE_SECURE: bool = False  # set True in production (HTTPS)

    # Encryption for AI provider API keys stored at rest
    FIELD_ENCRYPTION_KEY: str = ""  # Fernet key, generate with cryptography.fernet.Fernet.generate_key()

    # CORS
    FRONTEND_ORIGIN: str = "http://localhost:3000"

    # Progress photo storage — a private directory, never served statically.
    # Mount this as a persistent Docker volume in production so photos
    # survive container restarts/redeploys.
    PROGRESS_PHOTO_STORAGE_DIR: str = "/app/storage/progress_photos"
    PROGRESS_PHOTO_MAX_BYTES: int = 10 * 1024 * 1024  # 10MB


@lru_cache
def get_settings() -> Settings:
    return Settings()
