"""
Provider abstraction. Every concrete provider (Gemini, Groq, OpenRouter,
Mistral, Ollama, Anthropic) implements this interface. Capabilities that a
provider doesn't support return an explicit "unavailable" result rather
than raising — callers should treat that as a normal state (spec section
33), not an application failure.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum


class ErrorCategory(str, Enum):
    INVALID_CREDENTIALS = "INVALID_CREDENTIALS"       # 401
    PERMISSION_DENIED = "PERMISSION_DENIED"           # 403
    RATE_LIMITED = "RATE_LIMITED"                     # 429
    INVALID_REQUEST = "INVALID_REQUEST"               # 400
    TIMEOUT = "TIMEOUT"                               # 408 / client timeout
    SERVER_ERROR = "SERVER_ERROR"                     # 5xx
    NETWORK_ERROR = "NETWORK_ERROR"                   # connection failure
    UNKNOWN = "UNKNOWN"


# Only these categories justify walking the automatic fallback chain
# (spec section 38) — a slow-but-successful response is NOT one of them.
HARD_FAILURE_CATEGORIES = {
    ErrorCategory.RATE_LIMITED,
    ErrorCategory.TIMEOUT,
    ErrorCategory.SERVER_ERROR,
    ErrorCategory.NETWORK_ERROR,
}


@dataclass
class GenerationResult:
    text: str
    model: str
    input_tokens: int | None = None
    output_tokens: int | None = None
    latency_ms: int | None = None


@dataclass
class ProviderError:
    category: ErrorCategory
    message: str
    retry_after_seconds: int | None = None
    status_code: int | None = None


@dataclass
class TestConnectionResult:
    success: bool
    model: str | None = None
    latency_ms: int | None = None
    error: ProviderError | None = None


@dataclass
class UsageInfo:
    """
    Provider-reported usage, when available. If a provider gives no
    authoritative quota headers, callers should show "Quota: Unknown" —
    never fabricate a number (spec section 41).
    """

    available: bool
    requests_remaining: int | None = None
    tokens_remaining: int | None = None
    resets_at: str | None = None


class AIProvider(ABC):
    """Concrete providers raise ProviderCallError (below) on failure."""

    name: str

    @abstractmethod
    async def generate_text(
        self, prompt: str, *, system_prompt: str | None = None, max_tokens: int | None = None
    ) -> GenerationResult:
        ...

    @abstractmethod
    async def generate_structured(
        self, prompt: str, *, json_schema: dict, system_prompt: str | None = None
    ) -> GenerationResult:
        """Providers without native structured output should prompt-engineer
        JSON mode and parse the result; raise ProviderCallError with
        INVALID_REQUEST if the response isn't valid JSON."""
        ...

    async def stream_response(self, prompt: str, *, system_prompt: str | None = None):
        """
        Default: not supported. Providers that support streaming override
        this as an async generator yielding text chunks.
        """
        raise NotImplementedError(f"{self.name} does not support streaming")

    @abstractmethod
    async def test_connection(self) -> TestConnectionResult:
        ...

    async def get_usage(self) -> UsageInfo:
        """Default: unknown. Override for providers with a real usage API."""
        return UsageInfo(available=False)


class ProviderCallError(Exception):
    def __init__(self, error: ProviderError):
        self.error = error
        super().__init__(error.message)
