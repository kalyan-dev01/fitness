"""
Shared implementation for any provider exposing an OpenAI-style
/chat/completions endpoint. Provider-specific quirks (headers, model
listing endpoints, usage reporting) are handled by thin subclasses.
"""
import time

import httpx

from app.ai.provider_base import (
    AIProvider,
    ErrorCategory,
    GenerationResult,
    ProviderCallError,
    ProviderError,
    TestConnectionResult,
)

_STATUS_TO_CATEGORY = {
    400: ErrorCategory.INVALID_REQUEST,
    401: ErrorCategory.INVALID_CREDENTIALS,
    403: ErrorCategory.PERMISSION_DENIED,
    408: ErrorCategory.TIMEOUT,
    429: ErrorCategory.RATE_LIMITED,
}


def _categorize_http_error(status_code: int) -> ErrorCategory:
    if status_code in _STATUS_TO_CATEGORY:
        return _STATUS_TO_CATEGORY[status_code]
    if 500 <= status_code < 600:
        return ErrorCategory.SERVER_ERROR
    return ErrorCategory.UNKNOWN


class OpenAICompatibleProvider(AIProvider):
    def __init__(
        self,
        *,
        name: str,
        base_url: str,
        api_key: str,
        model: str,
        timeout_seconds: float = 30.0,
        extra_headers: dict | None = None,
    ):
        self.name = name
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.timeout_seconds = timeout_seconds
        self.extra_headers = extra_headers or {}

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            **self.extra_headers,
        }

    async def _chat_completion(
        self, messages: list[dict], *, max_tokens: int | None = None
    ) -> tuple[dict, int]:
        start = time.monotonic()
        payload: dict = {"model": self.model, "messages": messages}
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        try:
            async with httpx.AsyncClient(timeout=self.timeout_seconds) as client:
                response = await client.post(
                    f"{self.base_url}/chat/completions",
                    headers=self._headers(),
                    json=payload,
                )
        except httpx.TimeoutException as exc:
            raise ProviderCallError(
                ProviderError(ErrorCategory.TIMEOUT, f"{self.name} request timed out")
            ) from exc
        except httpx.RequestError as exc:
            raise ProviderCallError(
                ProviderError(ErrorCategory.NETWORK_ERROR, f"{self.name} unreachable: {exc}")
            ) from exc

        latency_ms = int((time.monotonic() - start) * 1000)

        if response.status_code >= 400:
            retry_after = response.headers.get("Retry-After")
            raise ProviderCallError(
                ProviderError(
                    category=_categorize_http_error(response.status_code),
                    message=f"{self.name} returned {response.status_code}: {response.text[:300]}",
                    retry_after_seconds=int(retry_after) if retry_after and retry_after.isdigit() else None,
                    status_code=response.status_code,
                )
            )

        return response.json(), latency_ms

    async def generate_text(
        self, prompt: str, *, system_prompt: str | None = None, max_tokens: int | None = None
    ) -> GenerationResult:
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        data, latency_ms = await self._chat_completion(messages, max_tokens=max_tokens)
        text = data["choices"][0]["message"]["content"]
        usage = data.get("usage", {})
        return GenerationResult(
            text=text,
            model=data.get("model", self.model),
            input_tokens=usage.get("prompt_tokens"),
            output_tokens=usage.get("completion_tokens"),
            latency_ms=latency_ms,
        )

    async def generate_structured(
        self, prompt: str, *, json_schema: dict, system_prompt: str | None = None
    ) -> GenerationResult:
        # Prompt-engineered JSON mode — not every OpenAI-compatible provider
        # supports native structured output/function calling reliably, so
        # this is the safe common denominator. Callers must validate/parse
        # the returned text themselves.
        instruction = (
            "Respond with ONLY valid JSON matching this schema, no prose, "
            f"no markdown fences: {json_schema}"
        )
        combined_system = f"{system_prompt}\n\n{instruction}" if system_prompt else instruction
        return await self.generate_text(prompt, system_prompt=combined_system)

    async def test_connection(self) -> TestConnectionResult:
        # Small, cheap request per spec section 35 — never a full-size call
        # just to check connectivity.
        try:
            result = await self.generate_text("Hi", max_tokens=8)
            return TestConnectionResult(
                success=True, model=result.model, latency_ms=result.latency_ms
            )
        except ProviderCallError as exc:
            return TestConnectionResult(success=False, error=exc.error)
