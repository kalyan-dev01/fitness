"""
ProviderManager: the only thing in the app that decides which AI provider
actually handles a request. Nothing else should call a provider directly.

Cost safety (spec section 39) is enforced HERE, not left to configuration
discipline: only providers with is_free_only=True are ever selected during
automatic fallback. A paid provider is only used if it's the one the user
explicitly picked for this request (explicit_provider_id), never as a
silent fallback target.
"""
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai.provider_base import HARD_FAILURE_CATEGORIES, GenerationResult, ProviderCallError
from app.ai.registry import build_provider
from app.core.security import decrypt_secret
from app.db.models.ai_provider import (
    AIProvider as AIProviderRow,
    AIProviderEvent,
    AIProviderHealth,
    AIProviderUsage,
    ProviderHealthStatus,
)

# How long a provider sits out after a hard failure before being retried
# automatically — avoids hammering a rate-limited provider (spec 37).
COOLDOWN_SECONDS = {
    "RATE_LIMITED": 60,
    "TIMEOUT": 30,
    "SERVER_ERROR": 30,
    "NETWORK_ERROR": 30,
}


@dataclass
class CoachResponse:
    text: str
    provider_name: str
    model: str
    input_tokens: int | None
    output_tokens: int | None
    latency_ms: int | None


class NoAvailableProviderError(Exception):
    """
    Raised when every eligible provider failed or none are configured.
    Callers (the /coach/message endpoint) MUST catch this and degrade
    gracefully — spec section 68 — never let it surface as a raw 500.
    """


def _now() -> datetime:
    return datetime.now(timezone.utc)


class ProviderManager:
    def __init__(self, db: Session, user_id):
        self.db = db
        self.user_id = user_id

    def _eligible_providers(self, *, explicit_provider_id=None) -> list[AIProviderRow]:
        stmt = select(AIProviderRow).where(
            AIProviderRow.user_id == self.user_id, AIProviderRow.is_enabled.is_(True)
        )
        rows = list(self.db.scalars(stmt).all())

        if explicit_provider_id is not None:
            return [r for r in rows if r.id == explicit_provider_id]

        # Automatic selection: only free-flagged providers, in priority
        # order, excluding anything currently in cooldown.
        now = _now()
        eligible = [
            r
            for r in rows
            if r.is_free_only
            and (
                r.health is None
                or r.health.cooldown_until is None
                or r.health.cooldown_until < now
            )
        ]
        return sorted(eligible, key=lambda r: r.priority)

    def _record_event(self, provider_id, event_type: str, detail: str = "") -> None:
        self.db.add(AIProviderEvent(provider_id=provider_id, event_type=event_type, detail=detail))

    def _record_usage(
        self,
        provider_id,
        *,
        success: bool,
        input_tokens: int | None,
        output_tokens: int | None,
        latency_ms: int | None,
    ) -> None:
        today = _now().date()
        usage = self.db.scalar(
            select(AIProviderUsage).where(
                AIProviderUsage.provider_id == provider_id, AIProviderUsage.date == today
            )
        )
        if usage is None:
            usage = AIProviderUsage(provider_id=provider_id, date=today)
            self.db.add(usage)
        usage.requests += 1
        if success:
            usage.successes += 1
        else:
            usage.failures += 1
        usage.input_tokens_approx += input_tokens or 0
        usage.output_tokens_approx += output_tokens or 0
        usage.total_latency_ms += latency_ms or 0

    def update_health(
        self,
        provider_row: AIProviderRow,
        *,
        success: bool,
        error_category: str | None,
        latency_ms: int | None,
        retry_after_seconds: int | None,
    ) -> None:
        health = provider_row.health
        if health is None:
            health = AIProviderHealth(provider_id=provider_row.id)
            self.db.add(health)
            provider_row.health = health

        now = _now()
        health.last_tested_at = now
        health.last_latency_ms = latency_ms

        if success:
            health.status = ProviderHealthStatus.HEALTHY
            health.last_success_at = now
            health.cooldown_until = None
            health.last_error_category = None
        else:
            health.last_failure_at = now
            health.last_error_category = error_category
            status_map = {
                "INVALID_CREDENTIALS": ProviderHealthStatus.INVALID_KEY,
                "RATE_LIMITED": ProviderHealthStatus.RATE_LIMITED,
                "PERMISSION_DENIED": ProviderHealthStatus.INVALID_KEY,
            }
            health.status = status_map.get(error_category, ProviderHealthStatus.UNAVAILABLE)

            cooldown = retry_after_seconds or COOLDOWN_SECONDS.get(error_category or "", 0)
            if cooldown:
                health.cooldown_until = now + timedelta(seconds=cooldown)

    async def generate(
        self, prompt: str, *, system_prompt: str | None = None, explicit_provider_id=None
    ) -> CoachResponse:
        candidates = self._eligible_providers(explicit_provider_id=explicit_provider_id)
        if not candidates:
            raise NoAvailableProviderError("No enabled/eligible AI provider is configured")

        last_error: ProviderCallError | None = None

        for provider_row in candidates:
            if provider_row.credential is None:
                continue
            try:
                api_key = decrypt_secret(provider_row.credential.encrypted_api_key)
                provider = build_provider(
                    name=provider_row.name,
                    base_url=provider_row.base_url,
                    api_key=api_key,
                    model=provider_row.model,
                )
                result: GenerationResult = await provider.generate_text(
                    prompt, system_prompt=system_prompt
                )
            except ProviderCallError as exc:
                last_error = exc
                self.update_health(
                    provider_row,
                    success=False,
                    error_category=exc.error.category.value,
                    latency_ms=None,
                    retry_after_seconds=exc.error.retry_after_seconds,
                )
                self._record_usage(
                    provider_row.id,
                    success=False,
                    input_tokens=None,
                    output_tokens=None,
                    latency_ms=None,
                )
                self._record_event(provider_row.id, "call_failed", exc.error.message)
                self.db.commit()

                # Only hard failures justify trying the next provider —
                # spec section 38. Anything else (e.g. a malformed prompt)
                # is a real error we surface, not a reason to fall back.
                if exc.error.category in HARD_FAILURE_CATEGORIES:
                    self._record_event(
                        provider_row.id,
                        "fallback_triggered",
                        f"falling back after {exc.error.category.value}",
                    )
                    self.db.commit()
                    continue
                raise

            self.update_health(
                provider_row,
                success=True,
                error_category=None,
                latency_ms=result.latency_ms,
                retry_after_seconds=None,
            )
            self._record_usage(
                provider_row.id,
                success=True,
                input_tokens=result.input_tokens,
                output_tokens=result.output_tokens,
                latency_ms=result.latency_ms,
            )
            self.db.commit()

            return CoachResponse(
                text=result.text,
                provider_name=provider_row.name,
                model=result.model,
                input_tokens=result.input_tokens,
                output_tokens=result.output_tokens,
                latency_ms=result.latency_ms,
            )

        detail = last_error.error.message if last_error else "no credential configured"
        raise NoAvailableProviderError(f"All eligible providers failed. Last error: {detail}")
