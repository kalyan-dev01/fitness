def _register(client, email="reportsapi@example.com"):
    return client.post(
        "/api/auth/register", json={"email": email, "password": "correcthorse"}
    )


def test_daily_review_degrades_gracefully_without_provider(client):
    _register(client)
    resp = client.get("/api/reports/daily")
    assert resp.status_code == 200
    body = resp.json()
    assert body["ai_unavailable"] is True
    assert "unavailable" in body["review_text"].lower()


def test_weekly_report_degrades_gracefully_and_still_persists(client):
    _register(client, email="weeklyreport@example.com")
    resp = client.get("/api/reports/weekly")
    assert resp.status_code == 200
    body = resp.json()
    assert body["ai_unavailable"] is True

    history = client.get("/api/reports/weekly/history")
    assert len(history.json()) == 1


def test_weekly_report_with_ai_extracts_targets(client, monkeypatch):
    _register(client, email="weeklyai@example.com")

    async def fake_generate(self, prompt, *, system_prompt=None, explicit_provider_id=None):
        from app.ai.provider_manager import CoachResponse

        return CoachResponse(
            text=(
                'Solid week overall, stayed close to target.\n'
                '{"calorie_target": 2100, "protein_target_g": 140, '
                '"training_target": "4 sessions", "priority_habit": "hit protein daily"}'
            ),
            provider_name="groq", model="test-model",
            input_tokens=5, output_tokens=5, latency_ms=20,
        )

    monkeypatch.setattr("app.ai.provider_manager.ProviderManager.generate", fake_generate)

    resp = client.get("/api/reports/weekly")
    body = resp.json()
    assert body["ai_unavailable"] is False
    assert body["next_week_targets"]["calorie_target"] == 2100
    assert "Solid week" in body["conclusion"]


def test_analytics_weight_series_empty_when_no_entries(client):
    _register(client, email="analytics1@example.com")
    resp = client.get("/api/analytics/weight")
    assert resp.status_code == 200
    assert resp.json()["points"] == []


def test_analytics_weight_series_reflects_entries(client):
    _register(client, email="analytics2@example.com")
    client.post("/api/weight", json={"date": "2026-09-01", "weight_kg": 70.0})
    client.post("/api/weight", json={"date": "2026-09-05", "weight_kg": 69.5})

    resp = client.get("/api/analytics/weight")
    points = resp.json()["points"]
    assert len(points) == 2
    assert points[0]["value"] == 70.0
