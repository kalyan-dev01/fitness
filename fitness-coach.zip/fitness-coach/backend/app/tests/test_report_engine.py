from datetime import date

from app.db.models.food import RawCooked, Unit
from app.db.models.goals import Goal, GoalType
from app.db.models.meal import Meal, MealItem, MealType
from app.db.models.user import User
from app.db.models.water import WaterEntry
from app.db.models.weight import WeightEntry
from app.services.report_engine import gather_daily_summary, gather_weekly_summary


def _user(db_session, email="report@example.com") -> User:
    user = User(email=email, password_hash="x")
    db_session.add(user)
    db_session.commit()
    return user


def _add_meal(db_session, user, day, calories, protein):
    meal = Meal(user_id=user.id, date=day, meal_type=MealType.LUNCH)
    meal.items.append(
        MealItem(
            label_snapshot="Food", quantity=100, unit=Unit.G, raw_cooked=RawCooked.RAW,
            calories_snapshot=calories, protein_snapshot=protein, carbs_snapshot=0, fat_snapshot=0,
        )
    )
    db_session.add(meal)
    db_session.commit()


def test_daily_summary_reflects_logged_data(db_session):
    user = _user(db_session)
    day = date(2026, 9, 1)
    _add_meal(db_session, user, day, 500, 40)
    db_session.add(WaterEntry(user_id=user.id, date=day, ml=750))
    db_session.commit()

    summary = gather_daily_summary(db_session, user, day=day)
    assert summary.calories == 500
    assert summary.protein_g == 40
    assert summary.water_ml == 750
    assert summary.workout_logged is False


def test_daily_summary_includes_goal_targets(db_session):
    user = _user(db_session, email="report2@example.com")
    db_session.add(
        Goal(user_id=user.id, goal_type=GoalType.CUT, calorie_target=2000,
             protein_target_g=150, started_at=date(2026, 1, 1))
    )
    db_session.commit()

    summary = gather_daily_summary(db_session, user, day=date(2026, 9, 1))
    assert summary.calorie_target == 2000
    assert summary.protein_target_g == 150


def test_weekly_summary_averages_over_seven_days(db_session):
    user = _user(db_session, email="report3@example.com")
    for i in range(7):
        _add_meal(db_session, user, date(2026, 9, 1 + i), 700, 50)

    summary = gather_weekly_summary(db_session, user, week_end=date(2026, 9, 7))
    assert summary.avg_calories == 700
    assert summary.avg_protein_g == 50


def test_weekly_summary_weight_change_uses_entries_within_week(db_session):
    user = _user(db_session, email="report4@example.com")
    db_session.add(WeightEntry(user_id=user.id, date=date(2026, 9, 1), weight_kg=71.0))
    db_session.add(WeightEntry(user_id=user.id, date=date(2026, 9, 7), weight_kg=70.0))
    db_session.commit()

    summary = gather_weekly_summary(db_session, user, week_end=date(2026, 9, 7))
    assert summary.weight_change_kg == -1.0
    assert summary.latest_weight_kg == 70.0
