import uuid
from datetime import date, timedelta

from app.db.models.weight import WeightEntry
from app.services.trend_engine import calculate_weight_trend


def _entry(d: date, kg: float) -> WeightEntry:
    return WeightEntry(id=uuid.uuid4(), user_id=uuid.uuid4(), date=d, weight_kg=kg)


def test_no_entries_returns_all_none():
    trend = calculate_weight_trend([])
    assert trend.latest_kg is None
    assert trend.seven_day_avg_kg is None


def test_single_entry_has_no_change_or_averages_beyond_itself():
    today = date(2026, 9, 10)
    trend = calculate_weight_trend([_entry(today, 70.0)], as_of=today)
    assert trend.latest_kg == 70.0
    assert trend.change_from_previous_kg is None
    assert trend.seven_day_avg_kg == 70.0


def test_change_from_previous_measurement():
    d1, d2 = date(2026, 9, 1), date(2026, 9, 8)
    trend = calculate_weight_trend([_entry(d1, 70.0), _entry(d2, 69.5)], as_of=d2)
    assert trend.change_from_previous_kg == -0.5


def test_seven_day_average_excludes_older_entries():
    as_of = date(2026, 9, 10)
    entries = [
        _entry(as_of - timedelta(days=20), 75.0),  # outside 7-day window
        _entry(as_of - timedelta(days=3), 70.0),
        _entry(as_of, 70.0),
    ]
    trend = calculate_weight_trend(entries, as_of=as_of)
    assert trend.seven_day_avg_kg == 70.0


def test_thirty_day_change_uses_first_and_last_in_window():
    as_of = date(2026, 9, 10)
    entries = [
        _entry(as_of - timedelta(days=29), 72.0),
        _entry(as_of - timedelta(days=15), 71.0),
        _entry(as_of, 70.0),
    ]
    trend = calculate_weight_trend(entries, as_of=as_of)
    assert trend.thirty_day_change_kg == -2.0


def test_does_not_overreact_to_single_outlier():
    """
    A single low measurement shouldn't swing the reported trend on its own
    — the 7-day average should stay close to the surrounding data.
    """
    as_of = date(2026, 9, 10)
    entries = [
        _entry(as_of - timedelta(days=6), 70.0),
        _entry(as_of - timedelta(days=4), 70.2),
        _entry(as_of - timedelta(days=2), 69.9),
        _entry(as_of, 65.0),  # outlier — e.g. bad measurement
    ]
    trend = calculate_weight_trend(entries, as_of=as_of)
    # latest reflects the outlier, but the 7-day average dampens it
    assert trend.latest_kg == 65.0
    assert trend.seven_day_avg_kg > 67.0
