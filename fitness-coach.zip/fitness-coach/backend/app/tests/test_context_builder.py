from datetime import date

from app.db.models.goals import Goal, GoalType
from app.db.models.meal import Meal, MealItem
from app.db.models.food import Unit, RawCooked
from app.db.models.meal import MealType
from app.db.models.user import User
from app.db.models.weight import WeightEntry
from app.services.context_builder import QuestionType, build_context, classify_question


def test_classify_nutrition_question():
    assert classify_question("Can I eat oats after the gym?") == QuestionType.NUTRITION_STATUS


def test_classify_weight_question():
    assert classify_question("Why am I not losing weight?") == QuestionType.WEIGHT_ANALYSIS


def test_classify_workout_question():
    assert classify_question("Am I getting stronger?") == QuestionType.WORKOUT_STATUS


def test_classify_general_fallback():
    assert classify_question("What's the weather like today") == QuestionType.GENERAL


def test_context_includes_goal_when_present(db_session):
    user = User(email="ctx1@example.com", password_hash="x")
    db_session.add(user)
    db_session.commit()

    goal = Goal(
        user_id=user.id, goal_type=GoalType.CUT, calorie_target=2000,
        protein_target_g=150, started_at=date(2026, 1, 1),
    )
    db_session.add(goal)
    db_session.commit()

    ctx = build_context(db_session, user, "Can I eat this?", today=date(2026, 9, 1))
    assert ctx.goal_type == "CUT"
    assert ctx.calorie_target == 2000
    assert "Today's calories consumed" in ctx.fields


def test_nutrition_context_reflects_logged_meals(db_session):
    user = User(email="ctx2@example.com", password_hash="x")
    db_session.add(user)
    db_session.commit()

    meal = Meal(user_id=user.id, date=date(2026, 9, 1), meal_type=MealType.BREAKFAST)
    meal.items.append(
        MealItem(
            label_snapshot="Oats", quantity=50, unit=Unit.G, raw_cooked=RawCooked.RAW,
            calories_snapshot=195, protein_snapshot=8.5, carbs_snapshot=33, fat_snapshot=3.5,
        )
    )
    db_session.add(meal)
    db_session.commit()

    ctx = build_context(db_session, user, "What should I eat?", today=date(2026, 9, 1))
    assert "195" in ctx.fields["Today's calories consumed"]


def test_weight_analysis_context_includes_trend(db_session):
    user = User(email="ctx3@example.com", password_hash="x")
    db_session.add(user)
    db_session.commit()

    db_session.add(WeightEntry(user_id=user.id, date=date(2026, 8, 25), weight_kg=71.0))
    db_session.add(WeightEntry(user_id=user.id, date=date(2026, 9, 1), weight_kg=70.5))
    db_session.commit()

    ctx = build_context(db_session, user, "Why am I not losing weight?", today=date(2026, 9, 1))
    assert ctx.question_type == QuestionType.WEIGHT_ANALYSIS
    assert "70.5" in ctx.fields["Latest weight"]


def test_prompt_text_is_plain_labeled_lines(db_session):
    user = User(email="ctx4@example.com", password_hash="x")
    db_session.add(user)
    db_session.commit()

    ctx = build_context(db_session, user, "hello", today=date(2026, 9, 1))
    text = ctx.as_prompt_text()
    assert "Question category: GENERAL" in text
    assert "{" not in text  # not JSON
