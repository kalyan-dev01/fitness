import pytest

from app.ai.provider_base import ErrorCategory, GenerationResult, ProviderCallError, ProviderError
from app.ai.provider_manager import NoAvailableProviderError, ProviderManager
from app.core.security import encrypt_secret, mask_secret
from app.db.models.ai_provider import AIProvider, AIProviderCredential


def _make_provider(db_session, user_id, *, name, priority, is_free_only=True, api_key="sk-x"):
    provider = AIProvider(
        user_id=user_id, name=name, display_name=name, model="test-model",
        is_free_only=is_free_only, priority=priority, is_enabled=True,
    )
    db_session.add(provider)
    db_session.flush()
    db_session.add(
        AIProviderCredential(
            provider_id=provider.id,
            encrypted_api_key=encrypt_secret(api_key),
            key_hint=mask_secret(api_key),
        )
    )
    db_session.commit()
    db_session.refresh(provider)
    return provider


class FakeSucceedingProvider:
    name = "fake"

    async def generate_text(self, prompt, *, system_prompt=None, max_tokens=None):
        return GenerationResult(text="hello", model="test-model", input_tokens=5, output_tokens=5, latency_ms=100)


class FakeFailingProvider:
    def __init__(self, category: ErrorCategory):
        self.name = "fake"
        self.category = category

    async def generate_text(self, prompt, *, system_prompt=None, max_tokens=None):
        raise ProviderCallError(ProviderError(self.category, "simulated failure"))


@pytest.mark.asyncio
async def test_generate_succeeds_with_single_provider(db_session, monkeypatch):
    from app.db.models.user import User
    from app.core.security import hash_password

    user = User(email="pm1@example.com", password_hash=hash_password("x"))
    db_session.add(user)
    db_session.commit()

    _make_provider(db_session, user.id, name="groq", priority=1)

    monkeypatch.setattr(
        "app.ai.provider_manager.build_provider", lambda **kwargs: FakeSucceedingProvider()
    )

    manager = ProviderManager(db_session, user.id)
    result = await manager.generate("hi")
    assert result.text == "hello"
    assert result.provider_name == "groq"


@pytest.mark.asyncio
async def test_hard_failure_falls_back_to_next_provider(db_session, monkeypatch):
    from app.db.models.user import User
    from app.core.security import hash_password

    user = User(email="pm2@example.com", password_hash=hash_password("x"))
    db_session.add(user)
    db_session.commit()

    _make_provider(db_session, user.id, name="groq", priority=1)
    _make_provider(db_session, user.id, name="openrouter", priority=2)

    calls = {"count": 0}

    def fake_build(**kwargs):
        calls["count"] += 1
        if calls["count"] == 1:
            return FakeFailingProvider(ErrorCategory.RATE_LIMITED)
        return FakeSucceedingProvider()

    monkeypatch.setattr("app.ai.provider_manager.build_provider", fake_build)

    manager = ProviderManager(db_session, user.id)
    result = await manager.generate("hi")
    assert result.text == "hello"
    assert calls["count"] == 2


@pytest.mark.asyncio
async def test_non_hard_failure_does_not_fall_back(db_session, monkeypatch):
    from app.db.models.user import User
    from app.core.security import hash_password

    user = User(email="pm3@example.com", password_hash=hash_password("x"))
    db_session.add(user)
    db_session.commit()

    _make_provider(db_session, user.id, name="groq", priority=1)
    _make_provider(db_session, user.id, name="openrouter", priority=2)

    monkeypatch.setattr(
        "app.ai.provider_manager.build_provider",
        lambda **kwargs: FakeFailingProvider(ErrorCategory.INVALID_REQUEST),
    )

    manager = ProviderManager(db_session, user.id)
    with pytest.raises(ProviderCallError):
        await manager.generate("hi")


@pytest.mark.asyncio
async def test_paid_provider_never_used_automatically(db_session, monkeypatch):
    from app.db.models.user import User
    from app.core.security import hash_password

    user = User(email="pm4@example.com", password_hash=hash_password("x"))
    db_session.add(user)
    db_session.commit()

    # only a paid provider is configured — automatic selection must find nothing
    _make_provider(db_session, user.id, name="anthropic", priority=1, is_free_only=False)

    monkeypatch.setattr(
        "app.ai.provider_manager.build_provider", lambda **kwargs: FakeSucceedingProvider()
    )

    manager = ProviderManager(db_session, user.id)
    with pytest.raises(NoAvailableProviderError):
        await manager.generate("hi")


@pytest.mark.asyncio
async def test_explicit_provider_id_can_use_paid_provider(db_session, monkeypatch):
    from app.db.models.user import User
    from app.core.security import hash_password

    user = User(email="pm5@example.com", password_hash=hash_password("x"))
    db_session.add(user)
    db_session.commit()

    paid = _make_provider(db_session, user.id, name="anthropic", priority=1, is_free_only=False)

    monkeypatch.setattr(
        "app.ai.provider_manager.build_provider", lambda **kwargs: FakeSucceedingProvider()
    )

    manager = ProviderManager(db_session, user.id)
    result = await manager.generate("hi", explicit_provider_id=paid.id)
    assert result.text == "hello"


@pytest.mark.asyncio
async def test_no_providers_configured_raises_gracefully(db_session):
    from app.db.models.user import User
    from app.core.security import hash_password

    user = User(email="pm6@example.com", password_hash=hash_password("x"))
    db_session.add(user)
    db_session.commit()

    manager = ProviderManager(db_session, user.id)
    with pytest.raises(NoAvailableProviderError):
        await manager.generate("hi")
