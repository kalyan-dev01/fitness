from app.ai.provider_base import GenerationResult


def _register(client, email="coach@example.com"):
    return client.post(
        "/api/auth/register", json={"email": email, "password": "correcthorse"}
    )


def test_coach_message_degrades_gracefully_with_no_providers(client):
    """
    Spec section 68: with zero providers configured, the endpoint must
    still return 200 with a clear "unavailable" message, never a 500.
    """
    _register(client, email="nocoach@example.com")
    resp = client.post("/api/coach/message", json={"message": "Can I eat oats?"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["ai_unavailable"] is True
    assert "unavailable" in body["reply"].lower()


def test_coach_message_persists_conversation_history(client, monkeypatch):
    _register(client, email="coachhistory@example.com")

    client.post("/api/ai/providers", json={"name": "groq", "api_key": "sk-x"})

    async def fake_generate(self, prompt, *, system_prompt=None, explicit_provider_id=None):
        from app.ai.provider_manager import CoachResponse

        return CoachResponse(
            text="You have plenty of room for oats today.",
            provider_name="groq", model="test-model",
            input_tokens=10, output_tokens=10, latency_ms=50,
        )

    monkeypatch.setattr("app.ai.provider_manager.ProviderManager.generate", fake_generate)

    resp = client.post("/api/coach/message", json={"message": "Can I eat oats?"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["ai_unavailable"] is False
    assert "oats" in body["reply"].lower()

    conversation_id = body["conversation_id"]
    history = client.get(f"/api/coach/conversations/{conversation_id}")
    assert history.status_code == 200
    roles = [m["role"] for m in history.json()["messages"]]
    assert roles == ["USER", "ASSISTANT"]


def test_coach_message_continues_existing_conversation(client, monkeypatch):
    _register(client, email="coachcontinue@example.com")

    async def fake_generate(self, prompt, *, system_prompt=None, explicit_provider_id=None):
        from app.ai.provider_manager import CoachResponse

        return CoachResponse(
            text="Sure thing.", provider_name="groq", model="test-model",
            input_tokens=1, output_tokens=1, latency_ms=10,
        )

    monkeypatch.setattr("app.ai.provider_manager.ProviderManager.generate", fake_generate)

    first = client.post("/api/coach/message", json={"message": "Hello"})
    conversation_id = first.json()["conversation_id"]

    second = client.post(
        "/api/coach/message",
        json={"message": "Follow-up question", "conversation_id": conversation_id},
    )
    assert second.json()["conversation_id"] == conversation_id

    history = client.get(f"/api/coach/conversations/{conversation_id}")
    assert len(history.json()["messages"]) == 4  # 2 user + 2 assistant


def test_parse_food_returns_empty_with_no_provider(client):
    _register(client, email="parsefood@example.com")
    resp = client.post("/api/coach/parse-food", json={"text": "50g oats and 2 eggs"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["ai_unavailable"] is True
    assert body["items"] == []


def test_conversation_not_found_returns_404(client):
    _register(client, email="convnotfound@example.com")
    resp = client.get("/api/coach/conversations/00000000-0000-0000-0000-000000000000")
    assert resp.status_code == 404
