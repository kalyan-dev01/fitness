def _register(client, email="weight@example.com"):
    return client.post(
        "/api/auth/register", json={"email": email, "password": "correcthorse"}
    )


def test_log_weight_and_list(client):
    _register(client)
    resp = client.post(
        "/api/weight", json={"date": "2026-09-01", "weight_kg": 70.5, "source": "Gym"}
    )
    assert resp.status_code == 201

    listing = client.get("/api/weight")
    assert len(listing.json()) == 1
    assert listing.json()[0]["weight_kg"] == 70.5


def test_weight_trend_reflects_change(client):
    _register(client, email="trend@example.com")
    client.post("/api/weight", json={"date": "2026-09-01", "weight_kg": 71.0})
    client.post("/api/weight", json={"date": "2026-09-05", "weight_kg": 70.0})

    trend = client.get("/api/weight/trend")
    assert trend.status_code == 200
    body = trend.json()
    assert body["latest_kg"] == 70.0
    assert body["change_from_previous_kg"] == -1.0


def test_delete_weight_entry(client):
    _register(client, email="delweight@example.com")
    created = client.post("/api/weight", json={"date": "2026-09-01", "weight_kg": 70.0})
    entry_id = created.json()["id"]

    delete_resp = client.delete(f"/api/weight/{entry_id}")
    assert delete_resp.status_code == 204
    assert client.get("/api/weight").json() == []


def test_water_daily_total_sums_entries(client):
    _register(client, email="water@example.com")
    client.post("/api/water", json={"date": "2026-09-01", "ml": 250})
    client.post("/api/water", json={"date": "2026-09-01", "ml": 500})

    daily = client.get("/api/water/daily?date=2026-09-01")
    assert daily.status_code == 200
    assert daily.json()["total_ml"] == 750
    assert len(daily.json()["entries"]) == 2


def test_water_target_reflects_profile_setting(client):
    _register(client, email="watertarget@example.com")
    client.put("/api/profile", json={"water_target_ml": 3000})

    daily = client.get("/api/water/daily?date=2026-09-01")
    assert daily.json()["target_ml"] == 3000
