from app.core.security import (
    create_access_token,
    decode_access_token,
    hash_password,
    verify_password,
)


def test_password_hash_is_not_plaintext():
    hashed = hash_password("mypassword123")
    assert hashed != "mypassword123"


def test_password_hash_verifies_correct_password():
    hashed = hash_password("mypassword123")
    assert verify_password("mypassword123", hashed) is True


def test_password_hash_rejects_wrong_password():
    hashed = hash_password("mypassword123")
    assert verify_password("not-the-password", hashed) is False


def test_access_token_roundtrip():
    token = create_access_token(subject="some-user-id")
    assert decode_access_token(token) == "some-user-id"


def test_invalid_token_returns_none():
    assert decode_access_token("not-a-real-token") is None
