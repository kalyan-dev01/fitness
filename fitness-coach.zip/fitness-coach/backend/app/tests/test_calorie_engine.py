import pytest

from app.db.models.goals import GoalType
from app.db.models.profile import ActivityLevel, Sex
from app.services.calorie_engine import (
    InsufficientProfileDataError,
    calculate_bmr,
    calculate_targets,
    calculate_tdee,
)


def test_bmr_male_matches_mifflin_st_jeor():
    # 80kg, 180cm, 30yo male: 10*80 + 6.25*180 - 5*30 + 5 = 800+1125-150+5 = 1780
    bmr = calculate_bmr(weight_kg=80, height_cm=180, age=30, sex=Sex.MALE)
    assert bmr == pytest.approx(1780, abs=0.01)


def test_bmr_female_matches_mifflin_st_jeor():
    # 60kg, 165cm, 25yo female: 10*60 + 6.25*165 - 5*25 - 161 = 600+1031.25-125-161=1345.25
    bmr = calculate_bmr(weight_kg=60, height_cm=165, age=25, sex=Sex.FEMALE)
    assert bmr == pytest.approx(1345.25, abs=0.01)


def test_tdee_applies_activity_multiplier():
    tdee = calculate_tdee(2000, ActivityLevel.MODERATE)
    assert tdee == pytest.approx(3100, abs=0.01)


def test_cut_goal_reduces_calories_below_maintenance():
    targets = calculate_targets(
        weight_kg=80,
        height_cm=180,
        age=30,
        sex=Sex.MALE,
        activity_level=ActivityLevel.MODERATE,
        goal_type=GoalType.CUT,
    )
    maintenance = calculate_targets(
        weight_kg=80,
        height_cm=180,
        age=30,
        sex=Sex.MALE,
        activity_level=ActivityLevel.MODERATE,
        goal_type=GoalType.MAINTAIN,
    )
    assert targets.calorie_target < maintenance.calorie_target


def test_bulk_goal_increases_calories_above_maintenance():
    bulk = calculate_targets(
        weight_kg=80,
        height_cm=180,
        age=30,
        sex=Sex.MALE,
        activity_level=ActivityLevel.MODERATE,
        goal_type=GoalType.BULK,
    )
    maintenance = calculate_targets(
        weight_kg=80,
        height_cm=180,
        age=30,
        sex=Sex.MALE,
        activity_level=ActivityLevel.MODERATE,
        goal_type=GoalType.MAINTAIN,
    )
    assert bulk.calorie_target > maintenance.calorie_target


def test_macros_sum_approximately_to_calorie_target():
    targets = calculate_targets(
        weight_kg=70,
        height_cm=170,
        age=28,
        sex=Sex.FEMALE,
        activity_level=ActivityLevel.LIGHT,
        goal_type=GoalType.MAINTAIN,
    )
    computed_calories = (
        targets.protein_target_g * 4
        + targets.carb_target_g * 4
        + targets.fat_target_g * 9
    )
    # rounding each macro independently can drift the total by a few kcal
    assert computed_calories == pytest.approx(targets.calorie_target, abs=15)


def test_cut_sets_higher_protein_per_kg_than_bulk():
    cut = calculate_targets(
        weight_kg=80, height_cm=180, age=30, sex=Sex.MALE,
        activity_level=ActivityLevel.MODERATE, goal_type=GoalType.CUT,
    )
    bulk = calculate_targets(
        weight_kg=80, height_cm=180, age=30, sex=Sex.MALE,
        activity_level=ActivityLevel.MODERATE, goal_type=GoalType.BULK,
    )
    assert cut.protein_target_g > bulk.protein_target_g


def test_rejects_non_positive_inputs():
    with pytest.raises(InsufficientProfileDataError):
        calculate_targets(
            weight_kg=0, height_cm=180, age=30, sex=Sex.MALE,
            activity_level=ActivityLevel.MODERATE, goal_type=GoalType.MAINTAIN,
        )


def test_all_targets_marked_as_estimate():
    targets = calculate_targets(
        weight_kg=70, height_cm=170, age=28, sex=Sex.FEMALE,
        activity_level=ActivityLevel.LIGHT, goal_type=GoalType.MAINTAIN,
    )
    assert targets.is_estimate is True
