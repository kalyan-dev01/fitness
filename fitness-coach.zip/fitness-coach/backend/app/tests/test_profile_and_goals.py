def _register(client, email="profile@example.com"):
    return client.post(
        "/api/auth/register", json={"email": email, "password": "correcthorse"}
    )


def test_profile_defaults_to_empty_on_first_get(client):
    _register(client)
    resp = client.get("/api/profile")
    assert resp.status_code == 200
    assert resp.json()["name"] is None


def test_profile_update_persists(client):
    _register(client)
    resp = client.put(
        "/api/profile",
        json={"name": "Alex", "age": 29, "sex": "MALE", "height_cm": 178.0},
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["name"] == "Alex"
    assert body["age"] == 29

    # confirm it actually persisted, not just echoed
    resp2 = client.get("/api/profile")
    assert resp2.json()["name"] == "Alex"


def test_profile_requires_auth(client):
    resp = client.get("/api/profile")
    assert resp.status_code == 401


def test_no_active_goal_returns_404(client):
    _register(client, email="nogoal@example.com")
    resp = client.get("/api/goals/current")
    assert resp.status_code == 404


def test_setting_goal_ends_previous_goal(client):
    _register(client, email="goals@example.com")

    first = client.post("/api/goals", json={"goal_type": "CUT", "calorie_target": 2000})
    assert first.status_code == 201
    assert first.json()["ended_at"] is None

    second = client.post("/api/goals", json={"goal_type": "MAINTAIN", "calorie_target": 2400})
    assert second.status_code == 201

    current = client.get("/api/goals/current")
    assert current.json()["goal_type"] == "MAINTAIN"

    history = client.get("/api/goals/history")
    assert len(history.json()) == 2
    # the first goal should now have an ended_at timestamp
    ended = [g for g in history.json() if g["goal_type"] == "CUT"][0]
    assert ended["ended_at"] is not None
