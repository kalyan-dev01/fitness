def _register(client, email="phase9@example.com"):
    return client.post(
        "/api/auth/register", json={"email": email, "password": "correcthorse"}
    )


def test_login_rate_limited_after_threshold(client):
    _register(client, email="ratelimit@example.com")
    client.post("/api/auth/logout")

    # threshold is 10/60s in tests too (same limiter instance/config)
    responses = [
        client.post(
            "/api/auth/login",
            json={"email": "ratelimit@example.com", "password": "wrongpassword"},
        )
        for _ in range(11)
    ]
    statuses = [r.status_code for r in responses]
    assert 429 in statuses


def test_security_headers_present(client):
    resp = client.get("/api/health")
    assert resp.headers.get("x-content-type-options") == "nosniff"
    assert resp.headers.get("x-frame-options") == "DENY"


def test_notification_settings_defaults(client):
    _register(client, email="notifsettings@example.com")
    resp = client.get("/api/notification-settings")
    assert resp.status_code == 200
    body = resp.json()
    assert body["remind_log_weight"] is True
    assert body["remind_workout"] is False


def test_notification_settings_update_persists(client):
    _register(client, email="notifupdate@example.com")
    client.put("/api/notification-settings", json={"remind_workout": True})
    resp = client.get("/api/notification-settings")
    assert resp.json()["remind_workout"] is True


def test_export_data_includes_all_sections(client):
    _register(client, email="exportdata@example.com")
    client.post("/api/weight", json={"date": "2026-09-01", "weight_kg": 70.0})

    resp = client.get("/api/export/data")
    assert resp.status_code == 200
    body = resp.json()
    assert "nutrition" in body
    assert "weight" in body
    assert "workouts" in body
    assert "ai_conversations" in body
    assert body["weight"][0]["weight_kg"] == 70.0
