"""
These tests assume a reachable PostgreSQL instance (docker-compose provides
one). Set TEST_DATABASE_URL to point at a disposable test database — never
run tests against production data.
"""
import os

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

os.environ.setdefault(
    "DATABASE_URL",
    os.environ.get(
        "TEST_DATABASE_URL",
        "postgresql+psycopg2://fitness:fitness@localhost:5432/fitness_coach_test",
    ),
)
os.environ.setdefault("FIELD_ENCRYPTION_KEY", "zxJhq2wQe8sSU2hM3n8vN1v6mZ8yqf4qk3l5m7p9q0A=")
os.environ.setdefault("JWT_SECRET", "test-secret")

from app.db.base import Base  # noqa: E402
from app.db import models  # noqa: E402, F401
from app.db.session import get_db  # noqa: E402
from app.main import app  # noqa: E402

engine = create_engine(os.environ["DATABASE_URL"])
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture(scope="session", autouse=True)
def _create_schema():
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture(autouse=True)
def _reset_rate_limiter():
    from app.core.rate_limit import auth_rate_limiter

    auth_rate_limiter._hits.clear()
    yield
    auth_rate_limiter._hits.clear()


@pytest.fixture()
def db_session():
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.rollback()
        session.close()


@pytest.fixture()
def client(db_session):
    def _override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = _override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()
