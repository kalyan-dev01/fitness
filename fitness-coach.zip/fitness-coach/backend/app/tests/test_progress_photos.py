import io

from app.core.config import get_settings


def _register(client, email="photos@example.com"):
    return client.post(
        "/api/auth/register", json={"email": email, "password": "correcthorse"}
    )


def _tiny_png_bytes() -> bytes:
    # 1x1 transparent PNG
    return bytes.fromhex(
        "89504e470d0a1a0a0000000d494844520000000100000001080600000"
        "01f15c4890000000a49444154789c6360000002000100" "5c" "cd8a2b0000000049454e44ae426082"
    )


def test_upload_and_list_photo(client):
    _register(client)
    resp = client.post(
        "/api/progress-photos",
        data={"date": "2026-09-01", "angle": "FRONT"},
        files={"file": ("photo.png", io.BytesIO(_tiny_png_bytes()), "image/png")},
    )
    assert resp.status_code == 201
    photo_id = resp.json()["id"]

    listing = client.get("/api/progress-photos")
    assert len(listing.json()) == 1
    assert listing.json()[0]["id"] == photo_id


def test_rejects_unsupported_file_type(client):
    _register(client, email="badtype@example.com")
    resp = client.post(
        "/api/progress-photos",
        data={"date": "2026-09-01", "angle": "FRONT"},
        files={"file": ("doc.pdf", io.BytesIO(b"not an image"), "application/pdf")},
    )
    assert resp.status_code == 400


def test_get_image_returns_bytes_for_owner(client):
    _register(client, email="ownerimg@example.com")
    photo_bytes = _tiny_png_bytes()
    created = client.post(
        "/api/progress-photos",
        data={"date": "2026-09-01", "angle": "SIDE"},
        files={"file": ("photo.png", io.BytesIO(photo_bytes), "image/png")},
    )
    photo_id = created.json()["id"]

    image_resp = client.get(f"/api/progress-photos/{photo_id}/image")
    assert image_resp.status_code == 200
    assert image_resp.content == photo_bytes
    assert image_resp.headers["content-type"] == "image/png"


def test_other_user_cannot_access_photo(client):
    _register(client, email="owner2@example.com")
    created = client.post(
        "/api/progress-photos",
        data={"date": "2026-09-01", "angle": "BACK"},
        files={"file": ("photo.png", io.BytesIO(_tiny_png_bytes()), "image/png")},
    )
    photo_id = created.json()["id"]
    client.post("/api/auth/logout")

    _register(client, email="intruder@example.com")
    resp = client.get(f"/api/progress-photos/{photo_id}/image")
    assert resp.status_code == 404


def test_delete_photo_removes_file_and_row(client, tmp_path, monkeypatch):
    settings = get_settings()
    monkeypatch.setattr(settings, "PROGRESS_PHOTO_STORAGE_DIR", str(tmp_path))
    get_settings.cache_clear()

    _register(client, email="deletephoto@example.com")
    created = client.post(
        "/api/progress-photos",
        data={"date": "2026-09-01", "angle": "FRONT"},
        files={"file": ("photo.png", io.BytesIO(_tiny_png_bytes()), "image/png")},
    )
    photo_id = created.json()["id"]

    delete_resp = client.delete(f"/api/progress-photos/{photo_id}")
    assert delete_resp.status_code == 204
    assert client.get("/api/progress-photos").json() == []
