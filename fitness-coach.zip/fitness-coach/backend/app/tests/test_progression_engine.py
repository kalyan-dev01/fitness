import uuid

from app.db.models.workout import ExerciseSet
from app.services.progression_engine import (
    SetPerformance,
    detect_prs,
    suggest_progression,
)


def _set(weight: float, reps: int) -> ExerciseSet:
    return ExerciseSet(
        id=uuid.uuid4(), workout_exercise_id=uuid.uuid4(), set_number=1,
        weight_kg=weight, reps=reps,
    )


def test_detect_prs_finds_best_weight_and_volume():
    sets = [_set(60, 8), _set(60, 8), _set(62.5, 6)]
    result = detect_prs("Bench Press", sets)
    assert result["best_weight_kg"] == 62.5
    assert result["best_volume"] == 480  # 60*8


def test_detect_prs_empty_history():
    result = detect_prs("Bench Press", [])
    assert result["best_weight_kg"] is None


def test_progression_insufficient_data_on_first_session():
    result = suggest_progression(
        exercise_name="Bench Press", previous_sets=[], current_sets=[SetPerformance(60, 8)]
    )
    assert result.status == "insufficient_data"


def test_progression_suggests_increase_when_target_hit():
    previous = [SetPerformance(60, 8), SetPerformance(60, 8), SetPerformance(60, 7)]
    current = [SetPerformance(60, 10), SetPerformance(60, 10), SetPerformance(60, 10)]
    result = suggest_progression(
        exercise_name="Bench Press",
        previous_sets=previous,
        current_sets=current,
        target_rep_range_top=10,
    )
    assert result.status == "improved"
    assert result.suggested_next_weight_kg == 62.5


def test_progression_uses_larger_increment_for_lower_body():
    previous = [SetPerformance(100, 10)]
    current = [SetPerformance(100, 10)]
    result = suggest_progression(
        exercise_name="Barbell Squat",
        previous_sets=previous,
        current_sets=current,
        target_rep_range_top=10,
    )
    assert result.suggested_next_weight_kg == 105.0


def test_progression_maintained_without_hitting_target():
    previous = [SetPerformance(60, 8), SetPerformance(60, 8)]
    current = [SetPerformance(60, 8), SetPerformance(60, 8)]
    result = suggest_progression(
        exercise_name="Bench Press",
        previous_sets=previous,
        current_sets=current,
        target_rep_range_top=10,
    )
    assert result.status == "maintained"
    assert result.suggested_next_weight_kg is None


def test_progression_declined_on_lower_volume():
    previous = [SetPerformance(60, 8), SetPerformance(60, 8)]
    current = [SetPerformance(60, 6), SetPerformance(60, 6)]
    result = suggest_progression(
        exercise_name="Bench Press", previous_sets=previous, current_sets=current
    )
    assert result.status == "declined"


def test_progression_partial_improvement_without_full_target():
    previous = [SetPerformance(60, 6), SetPerformance(60, 6)]
    current = [SetPerformance(60, 8), SetPerformance(60, 8)]
    result = suggest_progression(
        exercise_name="Bench Press",
        previous_sets=previous,
        current_sets=current,
        target_rep_range_top=10,
    )
    assert result.status == "improved"
    assert result.suggested_next_weight_kg is None
