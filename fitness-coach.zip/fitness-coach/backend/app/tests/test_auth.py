def test_register_creates_user_and_sets_cookie(client):
    resp = client.post(
        "/api/auth/register",
        json={"email": "new@example.com", "password": "supersecret1"},
    )
    assert resp.status_code == 201
    assert resp.json()["email"] == "new@example.com"
    assert "fc_session" in resp.cookies


def test_register_duplicate_email_rejected(client):
    client.post(
        "/api/auth/register",
        json={"email": "dupe@example.com", "password": "supersecret1"},
    )
    resp = client.post(
        "/api/auth/register",
        json={"email": "dupe@example.com", "password": "anotherpassword"},
    )
    assert resp.status_code == 409


def test_login_success(client):
    client.post(
        "/api/auth/register",
        json={"email": "login@example.com", "password": "correcthorse"},
    )
    resp = client.post(
        "/api/auth/login",
        json={"email": "login@example.com", "password": "correcthorse"},
    )
    assert resp.status_code == 200
    assert "fc_session" in resp.cookies


def test_login_wrong_password_rejected(client):
    client.post(
        "/api/auth/register",
        json={"email": "wrongpw@example.com", "password": "correcthorse"},
    )
    resp = client.post(
        "/api/auth/login",
        json={"email": "wrongpw@example.com", "password": "wrongpassword"},
    )
    assert resp.status_code == 401


def test_me_requires_authentication(client):
    resp = client.get("/api/auth/me")
    assert resp.status_code == 401


def test_me_returns_current_user_when_authenticated(client):
    client.post(
        "/api/auth/register",
        json={"email": "me@example.com", "password": "correcthorse"},
    )
    resp = client.get("/api/auth/me")
    assert resp.status_code == 200
    assert resp.json()["email"] == "me@example.com"


def test_logout_clears_session(client):
    client.post(
        "/api/auth/register",
        json={"email": "logout@example.com", "password": "correcthorse"},
    )
    logout_resp = client.post("/api/auth/logout")
    assert logout_resp.status_code == 204

    me_resp = client.get("/api/auth/me")
    assert me_resp.status_code == 401
