from app.db.models.workout import Exercise, MuscleGroup


def _register(client, email="workout@example.com"):
    return client.post(
        "/api/auth/register", json={"email": email, "password": "correcthorse"}
    )


def _seed_exercise(db_session, name="Bench Press") -> str:
    exercise = Exercise(name=name, muscle_group=MuscleGroup.CHEST, is_custom=False)
    db_session.add(exercise)
    db_session.commit()
    db_session.refresh(exercise)
    return str(exercise.id)


def test_list_exercises_includes_predefined(client, db_session):
    _register(client)
    _seed_exercise(db_session)
    resp = client.get("/api/exercises")
    assert resp.status_code == 200
    assert any(e["name"] == "Bench Press" for e in resp.json())


def test_create_custom_exercise(client):
    _register(client, email="customex@example.com")
    resp = client.post(
        "/api/exercises", json={"name": "My Weird Machine", "muscle_group": "OTHER"}
    )
    assert resp.status_code == 201
    assert resp.json()["is_custom"] is True


def test_log_workout_creates_session_with_sets(client, db_session):
    _register(client, email="logworkout@example.com")
    exercise_id = _seed_exercise(db_session)

    resp = client.post(
        "/api/workouts",
        json={
            "date": "2026-09-01",
            "exercises": [
                {
                    "exercise_id": exercise_id,
                    "sets": [
                        {"weight_kg": 60, "reps": 8},
                        {"weight_kg": 60, "reps": 8},
                    ],
                }
            ],
        },
    )
    assert resp.status_code == 201
    body = resp.json()
    assert len(body["exercises"][0]["sets"]) == 2
    # first-ever set for this exercise should be marked a PR
    assert body["exercises"][0]["sets"][0]["is_pr"] is True


def test_second_lower_session_is_not_marked_pr(client, db_session):
    _register(client, email="notpr@example.com")
    exercise_id = _seed_exercise(db_session)

    client.post(
        "/api/workouts",
        json={
            "date": "2026-09-01",
            "exercises": [{"exercise_id": exercise_id, "sets": [{"weight_kg": 60, "reps": 8}]}],
        },
    )
    second = client.post(
        "/api/workouts",
        json={
            "date": "2026-09-08",
            "exercises": [{"exercise_id": exercise_id, "sets": [{"weight_kg": 55, "reps": 6}]}],
        },
    )
    assert second.json()["exercises"][0]["sets"][0]["is_pr"] is False


def test_progression_suggests_weight_increase_when_target_hit(client, db_session):
    _register(client, email="progression@example.com")
    exercise_id = _seed_exercise(db_session)

    client.post(
        "/api/workouts",
        json={
            "date": "2026-09-01",
            "exercises": [
                {"exercise_id": exercise_id, "sets": [{"weight_kg": 60, "reps": 8}] * 3}
            ],
        },
    )
    client.post(
        "/api/workouts",
        json={
            "date": "2026-09-08",
            "exercises": [
                {"exercise_id": exercise_id, "sets": [{"weight_kg": 60, "reps": 10}] * 3}
            ],
        },
    )

    resp = client.get(f"/api/progression/exercises/{exercise_id}/suggestion")
    assert resp.status_code == 200
    body = resp.json()
    assert body["status"] == "improved"
    assert body["suggested_next_weight_kg"] == 62.5


def test_exercise_history_reports_best_stats(client, db_session):
    _register(client, email="history@example.com")
    exercise_id = _seed_exercise(db_session)

    client.post(
        "/api/workouts",
        json={
            "date": "2026-09-01",
            "exercises": [{"exercise_id": exercise_id, "sets": [{"weight_kg": 60, "reps": 8}]}],
        },
    )
    resp = client.get(f"/api/progression/exercises/{exercise_id}/history")
    assert resp.status_code == 200
    assert resp.json()["best_weight_kg"] == 60
