from app.core.security import decrypt_secret


def _register(client, email="aiprovider@example.com"):
    return client.post(
        "/api/auth/register", json={"email": email, "password": "correcthorse"}
    )


def test_create_provider_stores_encrypted_key_not_plaintext(client, db_session):
    _register(client)
    resp = client.post(
        "/api/ai/providers",
        json={"name": "groq", "api_key": "sk-real-secret-value-123"},
    )
    assert resp.status_code == 201
    body = resp.json()
    assert body["key_hint"].endswith("-123")
    assert "sk-real-secret-value-123" not in resp.text

    from app.db.models.ai_provider import AIProviderCredential

    cred = db_session.query(AIProviderCredential).first()
    assert cred is not None
    assert cred.encrypted_api_key != "sk-real-secret-value-123"
    assert decrypt_secret(cred.encrypted_api_key) == "sk-real-secret-value-123"


def test_known_provider_gets_registry_defaults(client):
    _register(client, email="defaults@example.com")
    resp = client.post("/api/ai/providers", json={"name": "gemini", "api_key": "abc123"})
    body = resp.json()
    assert body["display_name"] == "Google Gemini"
    assert body["model"] == "gemini-2.5-flash"
    assert body["is_free_only"] is True


def test_paid_provider_cannot_have_auto_fallback_enabled(client):
    """Anthropic is is_free_only=False by registry default — cost safety
    (spec section 39) must force auto_fallback off no matter what's sent."""
    _register(client, email="paidsafety@example.com")
    resp = client.post(
        "/api/ai/providers",
        json={"name": "anthropic", "api_key": "sk-ant-x", "auto_fallback_enabled": True},
    )
    body = resp.json()
    assert body["is_free_only"] is False
    assert body["auto_fallback_enabled"] is False


def test_update_cannot_force_auto_fallback_on_paid_provider(client):
    _register(client, email="paidupdate@example.com")
    created = client.post(
        "/api/ai/providers", json={"name": "anthropic", "api_key": "sk-ant-x"}
    )
    provider_id = created.json()["id"]

    updated = client.put(
        f"/api/ai/providers/{provider_id}",
        json={"auto_fallback_enabled": True},
    )
    assert updated.json()["auto_fallback_enabled"] is False


def test_list_providers_never_exposes_raw_key(client):
    _register(client, email="listsafety@example.com")
    client.post("/api/ai/providers", json={"name": "groq", "api_key": "sk-super-secret"})
    resp = client.get("/api/ai/providers")
    assert "sk-super-secret" not in resp.text


def test_delete_provider(client):
    _register(client, email="delprovider@example.com")
    created = client.post("/api/ai/providers", json={"name": "groq", "api_key": "sk-x"})
    provider_id = created.json()["id"]

    delete_resp = client.delete(f"/api/ai/providers/{provider_id}")
    assert delete_resp.status_code == 204
    assert client.get("/api/ai/providers").json() == []


def test_provider_usage_starts_empty(client):
    _register(client, email="usage@example.com")
    created = client.post("/api/ai/providers", json={"name": "groq", "api_key": "sk-x"})
    provider_id = created.json()["id"]

    usage = client.get(f"/api/ai/providers/{provider_id}/usage")
    assert usage.status_code == 200
    assert usage.json()["days"] == []
