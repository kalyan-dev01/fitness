import uuid

import pytest

from app.db.models.food import FoodServing, RawCooked, Unit
from app.services.nutrition_engine import (
    NutritionValues,
    RawCookedMismatchError,
    find_serving,
    nutrition_per_recipe_serving,
    scale_serving,
    sum_nutrition,
)


def _serving(unit: Unit, raw_cooked: RawCooked, **kwargs) -> FoodServing:
    defaults = dict(calories=165, protein_g=31, carbs_g=0, fat_g=3.6)
    defaults.update(kwargs)
    return FoodServing(
        id=uuid.uuid4(), food_id=uuid.uuid4(), unit=unit, raw_cooked=raw_cooked, **defaults
    )


def test_find_serving_returns_matching_raw_cooked_state():
    raw = _serving(Unit.G, RawCooked.RAW)
    cooked = _serving(Unit.G, RawCooked.COOKED, calories=239)
    found = find_serving([raw, cooked], unit=Unit.G, raw_cooked=RawCooked.COOKED)
    assert found is cooked


def test_find_serving_raises_when_state_missing():
    raw_only = [_serving(Unit.G, RawCooked.RAW)]
    with pytest.raises(RawCookedMismatchError):
        find_serving(raw_only, unit=Unit.G, raw_cooked=RawCooked.COOKED)


def test_scale_serving_per_100g_scales_linearly():
    serving = _serving(Unit.G, RawCooked.RAW, calories=165, protein_g=31, carbs_g=0, fat_g=3.6)
    result = scale_serving(serving, 200)  # 200g chicken
    assert result.calories == pytest.approx(330)
    assert result.protein_g == pytest.approx(62)


def test_scale_serving_per_piece_scales_by_count():
    egg = _serving(Unit.PIECE, RawCooked.NA, calories=72, protein_g=6.3, carbs_g=0.4, fat_g=4.8)
    result = scale_serving(egg, 3)  # 3 eggs
    assert result.calories == pytest.approx(216)


def test_raw_and_cooked_never_silently_mixed():
    """
    100g raw chicken and 100g cooked chicken must yield different calories —
    this is the core requirement from spec section 9.
    """
    raw = _serving(Unit.G, RawCooked.RAW, calories=165)
    cooked = _serving(Unit.G, RawCooked.COOKED, calories=239)
    raw_result = scale_serving(raw, 100)
    cooked_result = scale_serving(cooked, 100)
    assert raw_result.calories != cooked_result.calories


def test_sum_nutrition_adds_multiple_items():
    a = NutritionValues(calories=100, protein_g=10, carbs_g=5, fat_g=2)
    b = NutritionValues(calories=200, protein_g=20, carbs_g=10, fat_g=4)
    total = sum_nutrition([a, b])
    assert total.calories == 300
    assert total.protein_g == 30


def test_recipe_per_serving_divides_totals():
    total = NutritionValues(calories=2000, protein_g=160, carbs_g=100, fat_g=60)
    per_serving = nutrition_per_recipe_serving(total, servings=4)
    assert per_serving.calories == 500
    assert per_serving.protein_g == 40


def test_recipe_rejects_zero_servings():
    total = NutritionValues(calories=2000, protein_g=160, carbs_g=100, fat_g=60)
    with pytest.raises(ValueError):
        nutrition_per_recipe_serving(total, servings=0)
