"""
Daily and weekly review data gathering. Every number here is computed by
application code — the AI is only ever asked to turn an already-computed
summary into "what went well / what could improve / tomorrow's priority"
style narrative text (spec sections 48-49). Calorie targets are never
changed automatically — the weekly report only *suggests* next week's
targets for the user to review and apply manually via the goals endpoint.
"""
from dataclasses import asdict, dataclass
from datetime import date, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models.goals import Goal
from app.db.models.meal import Meal
from app.db.models.user import User
from app.db.models.water import WaterEntry
from app.db.models.weight import WeightEntry
from app.db.models.workout import WorkoutSession
from app.services.nutrition_engine import NutritionValues, sum_nutrition
from app.services.trend_engine import calculate_weight_trend


@dataclass
class DailySummary:
    date: str
    calories: float
    protein_g: float
    carbs_g: float
    fat_g: float
    calorie_target: int | None
    protein_target_g: int | None
    water_ml: int
    workout_logged: bool
    weight_kg: float | None


@dataclass
class WeeklySummary:
    week_start: str
    week_end: str
    avg_calories: float
    avg_protein_g: float
    calorie_target: int | None
    protein_target_g: int | None
    workouts_logged: int
    avg_water_ml: float
    weight_change_kg: float | None
    latest_weight_kg: float | None
    goal_type: str | None


def _day_nutrition(db: Session, user_id, day: date) -> NutritionValues:
    meals = db.scalars(select(Meal).where(Meal.user_id == user_id, Meal.date == day)).all()
    items = [
        NutritionValues(
            calories=i.calories_snapshot, protein_g=i.protein_snapshot,
            carbs_g=i.carbs_snapshot, fat_g=i.fat_snapshot,
        )
        for m in meals
        for i in m.items
    ]
    return sum_nutrition(items)


def gather_daily_summary(db: Session, user: User, *, day: date | None = None) -> DailySummary:
    day = day or date.today()
    totals = _day_nutrition(db, user.id, day)

    goal = db.scalar(select(Goal).where(Goal.user_id == user.id, Goal.ended_at.is_(None)))
    water = db.scalars(
        select(WaterEntry).where(WaterEntry.user_id == user.id, WaterEntry.date == day)
    ).all()
    workout = db.scalar(
        select(WorkoutSession).where(WorkoutSession.user_id == user.id, WorkoutSession.date == day)
    )
    weight_entry = db.scalar(
        select(WeightEntry).where(WeightEntry.user_id == user.id, WeightEntry.date == day)
    )

    return DailySummary(
        date=str(day),
        calories=totals.calories,
        protein_g=totals.protein_g,
        carbs_g=totals.carbs_g,
        fat_g=totals.fat_g,
        calorie_target=goal.calorie_target if goal else None,
        protein_target_g=goal.protein_target_g if goal else None,
        water_ml=sum(w.ml for w in water),
        workout_logged=workout is not None,
        weight_kg=weight_entry.weight_kg if weight_entry else None,
    )


def gather_weekly_summary(
    db: Session, user: User, *, week_end: date | None = None
) -> WeeklySummary:
    week_end = week_end or date.today()
    week_start = week_end - timedelta(days=6)

    meals = db.scalars(
        select(Meal).where(Meal.user_id == user.id, Meal.date >= week_start, Meal.date <= week_end)
    ).all()
    items = [
        NutritionValues(
            calories=i.calories_snapshot, protein_g=i.protein_snapshot,
            carbs_g=i.carbs_snapshot, fat_g=i.fat_snapshot,
        )
        for m in meals
        for i in m.items
    ]
    totals = sum_nutrition(items)
    n_days = 7

    goal = db.scalar(select(Goal).where(Goal.user_id == user.id, Goal.ended_at.is_(None)))

    workouts = db.scalars(
        select(WorkoutSession).where(
            WorkoutSession.user_id == user.id,
            WorkoutSession.date >= week_start,
            WorkoutSession.date <= week_end,
        )
    ).all()

    water_entries = db.scalars(
        select(WaterEntry).where(
            WaterEntry.user_id == user.id, WaterEntry.date >= week_start, WaterEntry.date <= week_end
        )
    ).all()

    weight_entries = db.scalars(select(WeightEntry).where(WeightEntry.user_id == user.id)).all()
    trend = calculate_weight_trend(list(weight_entries), as_of=week_end)

    week_entries_only = [e for e in weight_entries if week_start <= e.date <= week_end]
    weight_change = None
    if len(week_entries_only) >= 2:
        sorted_entries = sorted(week_entries_only, key=lambda e: e.date)
        weight_change = round(sorted_entries[-1].weight_kg - sorted_entries[0].weight_kg, 2)

    return WeeklySummary(
        week_start=str(week_start),
        week_end=str(week_end),
        avg_calories=round(totals.calories / n_days, 1),
        avg_protein_g=round(totals.protein_g / n_days, 1),
        calorie_target=goal.calorie_target if goal else None,
        protein_target_g=goal.protein_target_g if goal else None,
        workouts_logged=len(workouts),
        avg_water_ml=round(sum(w.ml for w in water_entries) / n_days, 0),
        weight_change_kg=weight_change,
        latest_weight_kg=trend.latest_kg,
        goal_type=goal.goal_type.value if goal else None,
    )


def summary_as_prompt_text(summary) -> str:
    return "\n".join(f"{k}: {v}" for k, v in asdict(summary).items())
