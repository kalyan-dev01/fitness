"""
Deterministic strength progression logic (spec section 23). The AI coach
may later explain *why* a recommendation was made, but never generates the
recommendation itself.

Progression rule (explicit, so it's not left implicit — see the
architecture doc's risk list):
  If every set in the current session met or exceeded the top of the
  target rep range at the same or higher weight than the previous
  session's corresponding sets, suggest a weight increase for next time.
  The increase is a fixed small increment (2.5kg for upper body movements,
  5kg for lower body / compound leg movements) — deliberately conservative.
"""
from dataclasses import dataclass

from app.db.models.workout import ExerciseSet

LOWER_BODY_KEYWORDS = ("squat", "deadlift", "leg press", "hip thrust", "lunge")


@dataclass
class SetPerformance:
    weight_kg: float
    reps: int


@dataclass
class ProgressionResult:
    status: str  # "improved" | "maintained" | "declined" | "insufficient_data"
    suggested_next_weight_kg: float | None
    reasoning: str


def _total_volume(sets: list[SetPerformance]) -> float:
    return sum(s.weight_kg * s.reps for s in sets)


def detect_prs(exercise_name: str, all_sets: list[ExerciseSet]) -> dict:
    """
    Given every logged set for one exercise (across all sessions, any
    order), return best weight, best reps at that weight, and total volume
    PR. Used both to mark is_pr on new sets and to show exercise history.
    """
    if not all_sets:
        return {"best_weight_kg": None, "best_reps_at_best_weight": None, "best_volume": None}

    best_weight = max(s.weight_kg for s in all_sets)
    best_reps_at_best_weight = max(
        (s.reps for s in all_sets if s.weight_kg == best_weight), default=None
    )
    best_volume = max(s.weight_kg * s.reps for s in all_sets)

    return {
        "best_weight_kg": best_weight,
        "best_reps_at_best_weight": best_reps_at_best_weight,
        "best_volume": best_volume,
    }


def suggest_progression(
    *,
    exercise_name: str,
    previous_sets: list[SetPerformance],
    current_sets: list[SetPerformance],
    target_rep_range_top: int = 10,
) -> ProgressionResult:
    if not previous_sets or not current_sets:
        return ProgressionResult(
            status="insufficient_data",
            suggested_next_weight_kg=None,
            reasoning="Not enough session history for this exercise yet.",
        )

    current_volume = _total_volume(current_sets)
    previous_volume = _total_volume(previous_sets)

    current_weight = max(s.weight_kg for s in current_sets)
    previous_weight = max(s.weight_kg for s in previous_sets)

    all_sets_hit_target = all(
        s.weight_kg >= previous_weight and s.reps >= target_rep_range_top
        for s in current_sets
    )

    if all_sets_hit_target:
        increment = (
            5.0
            if any(k in exercise_name.lower() for k in LOWER_BODY_KEYWORDS)
            else 2.5
        )
        return ProgressionResult(
            status="improved",
            suggested_next_weight_kg=round(current_weight + increment, 1),
            reasoning=(
                f"Every set hit {target_rep_range_top}+ reps at {current_weight}kg "
                f"or more — ready to add weight next session."
            ),
        )

    if current_volume > previous_volume:
        return ProgressionResult(
            status="improved",
            suggested_next_weight_kg=None,
            reasoning="Total volume increased versus last session, but not every "
            "set hit the top of the rep range yet — keep the same weight and "
            "aim to hit it before increasing.",
        )

    if current_volume < previous_volume:
        return ProgressionResult(
            status="declined",
            suggested_next_weight_kg=None,
            reasoning="Volume dropped versus last session. Could be normal "
            "fatigue — no action needed from a single session alone.",
        )

    return ProgressionResult(
        status="maintained",
        suggested_next_weight_kg=None,
        reasoning="Performance matched last session.",
    )
