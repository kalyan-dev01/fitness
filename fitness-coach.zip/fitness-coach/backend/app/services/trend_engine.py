"""
Deterministic weight-trend math. The point of this module is specifically
to avoid overreacting to any single measurement — spec section 17 — by
always surfacing averages and multi-point trends alongside the latest value.
"""
from dataclasses import dataclass
from datetime import date, timedelta

from app.db.models.weight import WeightEntry


@dataclass
class WeightTrend:
    latest_kg: float | None
    latest_date: date | None
    change_from_previous_kg: float | None
    seven_day_avg_kg: float | None
    thirty_day_avg_kg: float | None
    thirty_day_change_kg: float | None


def _average(entries: list[WeightEntry]) -> float | None:
    if not entries:
        return None
    return round(sum(e.weight_kg for e in entries) / len(entries), 2)


def calculate_weight_trend(
    entries: list[WeightEntry], *, as_of: date | None = None
) -> WeightTrend:
    """
    `entries` should be all of a user's weight entries (any order) — this
    function does the date filtering. Returns None fields when there isn't
    enough data yet rather than guessing.
    """
    if not entries:
        return WeightTrend(None, None, None, None, None, None)

    as_of = as_of or max(e.date for e in entries)
    sorted_entries = sorted(entries, key=lambda e: e.date)

    latest = sorted_entries[-1]
    previous = sorted_entries[-2] if len(sorted_entries) >= 2 else None

    seven_day_cutoff = as_of - timedelta(days=7)
    thirty_day_cutoff = as_of - timedelta(days=30)

    last_7 = [e for e in sorted_entries if seven_day_cutoff <= e.date <= as_of]
    last_30 = [e for e in sorted_entries if thirty_day_cutoff <= e.date <= as_of]

    thirty_day_change = None
    if last_30 and len(last_30) >= 2:
        thirty_day_change = round(last_30[-1].weight_kg - last_30[0].weight_kg, 2)

    return WeightTrend(
        latest_kg=latest.weight_kg,
        latest_date=latest.date,
        change_from_previous_kg=(
            round(latest.weight_kg - previous.weight_kg, 2) if previous else None
        ),
        seven_day_avg_kg=_average(last_7),
        thirty_day_avg_kg=_average(last_30),
        thirty_day_change_kg=thirty_day_change,
    )
