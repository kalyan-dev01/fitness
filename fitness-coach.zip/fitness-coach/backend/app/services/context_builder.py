"""
Context Builder: decides what data a coach question actually needs and
retrieves only that. Keeps prompts small and avoids ever sending the whole
database to an AI provider (spec section 28).

Classification is deliberately simple keyword matching, not an AI call —
it's fast, free, deterministic, and auditable. It can be wrong on edge
cases; when uncertain it falls back to a general snapshot rather than
guessing at something narrower and missing data the question actually
needed.
"""
import enum
from dataclasses import dataclass, field
from datetime import date, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db.models.goals import Goal
from app.db.models.meal import Meal
from app.db.models.user import User
from app.db.models.water import WaterEntry
from app.db.models.weight import WeightEntry
from app.db.models.workout import WorkoutSession
from app.services.nutrition_engine import NutritionValues, sum_nutrition
from app.services.trend_engine import calculate_weight_trend


class QuestionType(str, enum.Enum):
    NUTRITION_STATUS = "NUTRITION_STATUS"
    WEIGHT_ANALYSIS = "WEIGHT_ANALYSIS"
    WORKOUT_STATUS = "WORKOUT_STATUS"
    GENERAL = "GENERAL"


_WEIGHT_KEYWORDS = (
    "losing weight", "gain weight", "weight increase", "weight loss",
    "cut going", "scale", "gaining weight",
)
_NUTRITION_KEYWORDS = (
    "eat", "food", "calorie", "protein", "carb", "fat", "meal", "hungry",
    "snack", "diet", "macro",
)
_WORKOUT_KEYWORDS = (
    "train", "workout", "stronger", "progress", "lift", "gym", "reps",
    "sets", "exercise",
)


def classify_question(text: str) -> QuestionType:
    lowered = text.lower()
    if any(k in lowered for k in _WEIGHT_KEYWORDS):
        return QuestionType.WEIGHT_ANALYSIS
    if any(k in lowered for k in _NUTRITION_KEYWORDS):
        return QuestionType.NUTRITION_STATUS
    if any(k in lowered for k in _WORKOUT_KEYWORDS):
        return QuestionType.WORKOUT_STATUS
    return QuestionType.GENERAL


@dataclass
class CoachContext:
    question_type: QuestionType
    goal_type: str | None = None
    calorie_target: int | None = None
    protein_target_g: int | None = None
    fields: dict = field(default_factory=dict)

    def as_prompt_text(self) -> str:
        lines = [f"Question category: {self.question_type.value}"]
        if self.goal_type:
            lines.append(f"Current goal: {self.goal_type}")
        if self.calorie_target:
            lines.append(f"Calorie target: {self.calorie_target} kcal (estimate)")
        if self.protein_target_g:
            lines.append(f"Protein target: {self.protein_target_g}g (estimate)")
        for label, value in self.fields.items():
            lines.append(f"{label}: {value}")
        return "\n".join(lines)


def _get_current_goal(db: Session, user_id) -> Goal | None:
    return db.scalar(select(Goal).where(Goal.user_id == user_id, Goal.ended_at.is_(None)))


def _nutrition_totals(db: Session, user_id, start: date, end: date) -> NutritionValues:
    meals = db.scalars(
        select(Meal).where(Meal.user_id == user_id, Meal.date >= start, Meal.date <= end)
    ).all()
    items = [
        NutritionValues(
            calories=i.calories_snapshot, protein_g=i.protein_snapshot,
            carbs_g=i.carbs_snapshot, fat_g=i.fat_snapshot,
        )
        for m in meals
        for i in m.items
    ]
    return sum_nutrition(items)


def build_context(
    db: Session, user: User, question: str, *, today: date | None = None
) -> CoachContext:
    today = today or date.today()
    question_type = classify_question(question)
    goal = _get_current_goal(db, user.id)

    ctx = CoachContext(
        question_type=question_type,
        goal_type=goal.goal_type.value if goal else None,
        calorie_target=goal.calorie_target if goal else None,
        protein_target_g=goal.protein_target_g if goal else None,
    )

    if question_type == QuestionType.NUTRITION_STATUS:
        totals = _nutrition_totals(db, user.id, today, today)
        ctx.fields["Today's calories consumed"] = f"{totals.calories} kcal"
        ctx.fields["Today's protein consumed"] = f"{totals.protein_g}g"
        if goal and goal.calorie_target:
            ctx.fields["Calories remaining"] = f"{round(goal.calorie_target - totals.calories)} kcal"
        if goal and goal.protein_target_g:
            ctx.fields["Protein remaining"] = f"{round(goal.protein_target_g - totals.protein_g, 1)}g"
        water = db.scalars(
            select(WaterEntry).where(WaterEntry.user_id == user.id, WaterEntry.date == today)
        ).all()
        ctx.fields["Water today"] = f"{sum(w.ml for w in water)}ml"
        todays_workout = db.scalar(
            select(WorkoutSession).where(
                WorkoutSession.user_id == user.id, WorkoutSession.date == today
            )
        )
        ctx.fields["Workout today"] = "Yes" if todays_workout else "No"

    elif question_type == QuestionType.WEIGHT_ANALYSIS:
        entries = db.scalars(select(WeightEntry).where(WeightEntry.user_id == user.id)).all()
        trend = calculate_weight_trend(list(entries), as_of=today)
        ctx.fields["Latest weight"] = f"{trend.latest_kg}kg" if trend.latest_kg else "no entries yet"
        ctx.fields["7-day average weight"] = (
            f"{trend.seven_day_avg_kg}kg" if trend.seven_day_avg_kg else "insufficient data"
        )
        ctx.fields["30-day weight change"] = (
            f"{trend.thirty_day_change_kg}kg"
            if trend.thirty_day_change_kg is not None
            else "insufficient data"
        )

        cutoff = today - timedelta(days=14)
        n_days = max((today - cutoff).days, 1)
        recent_totals = _nutrition_totals(db, user.id, cutoff, today)
        ctx.fields["Average daily calories (last 14 days)"] = round(recent_totals.calories / n_days)
        ctx.fields["Average daily protein (last 14 days)"] = round(recent_totals.protein_g / n_days, 1)

        recent_workouts = db.scalars(
            select(WorkoutSession).where(
                WorkoutSession.user_id == user.id, WorkoutSession.date >= cutoff
            )
        ).all()
        ctx.fields["Workouts in last 14 days"] = len(recent_workouts)

    elif question_type == QuestionType.WORKOUT_STATUS:
        cutoff = today - timedelta(days=30)
        sessions = db.scalars(
            select(WorkoutSession)
            .where(WorkoutSession.user_id == user.id, WorkoutSession.date >= cutoff)
            .order_by(WorkoutSession.date.desc())
        ).all()
        ctx.fields["Workouts in last 30 days"] = len(sessions)
        if sessions:
            latest = sessions[0]
            ctx.fields["Most recent workout date"] = str(latest.date)
            prs = sum(1 for we in latest.exercises for s in we.sets if s.is_pr)
            ctx.fields["PRs set in most recent workout"] = prs

    return ctx
