from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.db.models.custom_food import CustomFood
from app.db.models.food import Food, RawCooked
from app.db.models.recipe import Recipe
from app.services.nutrition_engine import (
    NutritionValues,
    find_serving,
    nutrition_per_recipe_serving,
    scale_serving,
    sum_nutrition,
)


def calculate_recipe_nutrition(
    db: Session, recipe: Recipe
) -> tuple[NutritionValues, NutritionValues]:
    """
    Returns (total, per_serving). Raises RawCookedMismatchError (bubbled up
    from find_serving) if an ingredient's food is missing RAW serving data
    for its logged unit — callers should surface this as a 422, not guess.

    Convention: shared-database food ingredients are treated as RAW
    (a recipe describes what goes in before cooking). Custom-food
    ingredients keep whatever raw/cooked state they were entered as.
    """
    line_items: list[NutritionValues] = []
    for ing in recipe.ingredients:
        if ing.food_id:
            food = db.scalar(
                select(Food)
                .options(selectinload(Food.servings))
                .where(Food.id == ing.food_id)
            )
            serving = find_serving(food.servings, unit=ing.unit, raw_cooked=RawCooked.RAW)
            line_items.append(scale_serving(serving, ing.quantity))
        else:
            cf = db.get(CustomFood, ing.custom_food_id)
            factor = ing.quantity / cf.serving_size
            line_items.append(
                NutritionValues(
                    calories=round(cf.calories * factor, 2),
                    protein_g=round(cf.protein_g * factor, 2),
                    carbs_g=round(cf.carbs_g * factor, 2),
                    fat_g=round(cf.fat_g * factor, 2),
                    fiber_g=round((cf.fiber_g or 0) * factor, 2),
                    sugar_g=round((cf.sugar_g or 0) * factor, 2),
                    sodium_mg=round((cf.sodium_mg or 0) * factor, 2),
                )
            )

    total = sum_nutrition(line_items)
    per_serving = nutrition_per_recipe_serving(total, recipe.servings)
    return total, per_serving
