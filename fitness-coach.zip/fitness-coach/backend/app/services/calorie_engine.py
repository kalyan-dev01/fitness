"""
Deterministic calorie & macro calculation engine.

This is the ONLY place BMR/TDEE/macro targets are computed. The AI coach
(Phase 6) may explain these numbers in plain language, but it never
calculates them — this module is the source of truth, and every value it
returns is explicitly labeled as an estimate where that's what it is.

Formulas:
  BMR  — Mifflin-St Jeor (most accurate general-purpose equation for both
         sexes; more reliable than Harris-Benedict for most adults).
  TDEE — BMR × activity multiplier.
  Macros — protein and fat set first from body-weight-based targets (more
         physiologically meaningful than a flat % split), carbs fill the
         remaining calories.
"""
from dataclasses import dataclass

from app.db.models.goals import GoalType
from app.db.models.profile import ActivityLevel, Sex

ACTIVITY_MULTIPLIERS: dict[ActivityLevel, float] = {
    ActivityLevel.SEDENTARY: 1.2,
    ActivityLevel.LIGHT: 1.375,
    ActivityLevel.MODERATE: 1.55,
    ActivityLevel.ACTIVE: 1.725,
    ActivityLevel.VERY_ACTIVE: 1.9,
}

# Calorie adjustment relative to maintenance, by goal. Deliberately modest —
# large deficits/surpluses are a decision for the user to make explicitly,
# not something this engine defaults to.
GOAL_CALORIE_ADJUSTMENT: dict[GoalType, float] = {
    GoalType.CUT: -0.20,
    GoalType.MAINTAIN: 0.0,
    GoalType.LEAN_BULK: 0.10,
    GoalType.BULK: 0.20,
}

# Protein target in g per kg bodyweight, by goal — cutting needs relatively
# more protein per calorie to preserve muscle.
PROTEIN_G_PER_KG: dict[GoalType, float] = {
    GoalType.CUT: 2.2,
    GoalType.MAINTAIN: 1.8,
    GoalType.LEAN_BULK: 1.8,
    GoalType.BULK: 1.6,
}

FAT_G_PER_KG = 0.8  # baseline fat floor, independent of goal
CALORIES_PER_G_PROTEIN = 4
CALORIES_PER_G_CARB = 4
CALORIES_PER_G_FAT = 9


class InsufficientProfileDataError(ValueError):
    """Raised when required profile fields are missing for a calculation."""


@dataclass
class MacroTargets:
    bmr: int
    tdee: int
    calorie_target: int
    protein_target_g: int
    carb_target_g: int
    fat_target_g: int
    is_estimate: bool = True


def calculate_bmr(*, weight_kg: float, height_cm: float, age: int, sex: Sex) -> float:
    """Mifflin-St Jeor equation."""
    base = (10 * weight_kg) + (6.25 * height_cm) - (5 * age)
    if sex == Sex.MALE:
        return base + 5
    if sex == Sex.FEMALE:
        return base - 161
    # No validated sex-specific constant for "OTHER" — use the midpoint
    # rather than silently picking one, and this is surfaced as an estimate.
    return base - 78


def calculate_tdee(bmr: float, activity_level: ActivityLevel) -> float:
    return bmr * ACTIVITY_MULTIPLIERS[activity_level]


def calculate_targets(
    *,
    weight_kg: float,
    height_cm: float,
    age: int,
    sex: Sex,
    activity_level: ActivityLevel,
    goal_type: GoalType,
) -> MacroTargets:
    """
    Compute BMR, TDEE, and calorie/macro targets for a goal.
    Raises InsufficientProfileDataError if required inputs are missing —
    callers should catch this and prompt for profile completion rather than
    guessing values.
    """
    if weight_kg <= 0 or height_cm <= 0 or age <= 0:
        raise InsufficientProfileDataError(
            "weight_kg, height_cm, and age must all be positive"
        )

    bmr = calculate_bmr(weight_kg=weight_kg, height_cm=height_cm, age=age, sex=sex)
    tdee = calculate_tdee(bmr, activity_level)

    adjustment = GOAL_CALORIE_ADJUSTMENT[goal_type]
    calorie_target = tdee * (1 + adjustment)

    protein_g = PROTEIN_G_PER_KG[goal_type] * weight_kg
    fat_g = FAT_G_PER_KG * weight_kg

    protein_cals = protein_g * CALORIES_PER_G_PROTEIN
    fat_cals = fat_g * CALORIES_PER_G_FAT
    remaining_cals = max(calorie_target - protein_cals - fat_cals, 0)
    carb_g = remaining_cals / CALORIES_PER_G_CARB

    return MacroTargets(
        bmr=round(bmr),
        tdee=round(tdee),
        calorie_target=round(calorie_target),
        protein_target_g=round(protein_g),
        carb_target_g=round(carb_g),
        fat_target_g=round(fat_g),
        is_estimate=True,
    )
