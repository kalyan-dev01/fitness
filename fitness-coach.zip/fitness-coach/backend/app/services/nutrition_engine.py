"""
Deterministic nutrition math: converting a logged quantity into calories
and macros, and aggregating a day's meals into totals. The AI never
computes these numbers — it only reads them via the Context Builder
(Phase 6) and explains them.
"""
from dataclasses import dataclass

from app.db.models.food import FoodServing, RawCooked, Unit


class RawCookedMismatchError(ValueError):
    """
    Raised when a food is logged in a raw/cooked state that doesn't have a
    matching FoodServing row. Per spec section 9, we never silently guess
    or mix raw/cooked values — the caller must pick a state the food
    actually has data for.
    """


@dataclass
class NutritionValues:
    calories: float
    protein_g: float
    carbs_g: float
    fat_g: float
    fiber_g: float | None = None
    sugar_g: float | None = None
    sodium_mg: float | None = None


def find_serving(
    servings: list[FoodServing], *, unit: Unit, raw_cooked: RawCooked
) -> FoodServing:
    for serving in servings:
        if serving.unit == unit and serving.raw_cooked == raw_cooked:
            return serving
    available = sorted({s.raw_cooked.value for s in servings})
    raise RawCookedMismatchError(
        f"No {raw_cooked.value} serving data for unit '{unit.value}'. "
        f"Available states: {available or 'none'}."
    )


def scale_serving(serving: FoodServing, quantity: float) -> NutritionValues:
    """
    FoodServing values are stored per 100 base-units (100g/100ml) or per 1
    piece/serving — see FoodServing docstring. Scale linearly by quantity.
    """
    is_per_100 = serving.unit in (Unit.G, Unit.ML)
    factor = (quantity / 100.0) if is_per_100 else quantity

    def scale(value: float | None) -> float | None:
        return None if value is None else round(value * factor, 2)

    return NutritionValues(
        calories=scale(serving.calories) or 0.0,
        protein_g=scale(serving.protein_g) or 0.0,
        carbs_g=scale(serving.carbs_g) or 0.0,
        fat_g=scale(serving.fat_g) or 0.0,
        fiber_g=scale(serving.fiber_g),
        sugar_g=scale(serving.sugar_g),
        sodium_mg=scale(serving.sodium_mg),
    )


def sum_nutrition(items: list[NutritionValues]) -> NutritionValues:
    total = NutritionValues(0, 0, 0, 0, 0, 0, 0)
    for item in items:
        total.calories += item.calories
        total.protein_g += item.protein_g
        total.carbs_g += item.carbs_g
        total.fat_g += item.fat_g
        total.fiber_g = (total.fiber_g or 0) + (item.fiber_g or 0)
        total.sugar_g = (total.sugar_g or 0) + (item.sugar_g or 0)
        total.sodium_mg = (total.sodium_mg or 0) + (item.sodium_mg or 0)
    return NutritionValues(
        calories=round(total.calories, 1),
        protein_g=round(total.protein_g, 1),
        carbs_g=round(total.carbs_g, 1),
        fat_g=round(total.fat_g, 1),
        fiber_g=round(total.fiber_g or 0, 1),
        sugar_g=round(total.sugar_g or 0, 1),
        sodium_mg=round(total.sodium_mg or 0, 1),
    )


def nutrition_per_recipe_serving(
    total: NutritionValues, servings: int
) -> NutritionValues:
    if servings <= 0:
        raise ValueError("Recipe servings must be a positive integer")
    return NutritionValues(
        calories=round(total.calories / servings, 1),
        protein_g=round(total.protein_g / servings, 1),
        carbs_g=round(total.carbs_g / servings, 1),
        fat_g=round(total.fat_g / servings, 1),
        fiber_g=round((total.fiber_g or 0) / servings, 1),
        sugar_g=round((total.sugar_g or 0) / servings, 1),
        sodium_mg=round((total.sodium_mg or 0) / servings, 1),
    )
