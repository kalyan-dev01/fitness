import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.models.custom_food import CustomFood
from app.db.models.user import User
from app.db.session import get_db
from app.schemas.food import CustomFoodCreate, CustomFoodOut

router = APIRouter(prefix="/custom-foods", tags=["custom-foods"])


@router.get("", response_model=list[CustomFoodOut])
def list_custom_foods(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    return list(
        db.scalars(
            select(CustomFood)
            .where(CustomFood.user_id == current_user.id)
            .order_by(CustomFood.name)
        ).all()
    )


@router.post("", response_model=CustomFoodOut, status_code=status.HTTP_201_CREATED)
def create_custom_food(
    payload: CustomFoodCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    food = CustomFood(user_id=current_user.id, **payload.model_dump())
    db.add(food)
    db.commit()
    db.refresh(food)
    return food


def _get_owned(db: Session, user_id: uuid.UUID, custom_food_id: str) -> CustomFood:
    food = db.scalar(
        select(CustomFood).where(
            CustomFood.id == custom_food_id, CustomFood.user_id == user_id
        )
    )
    if food is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Custom food not found")
    return food


@router.put("/{custom_food_id}", response_model=CustomFoodOut)
def update_custom_food(
    custom_food_id: str,
    payload: CustomFoodCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    food = _get_owned(db, current_user.id, custom_food_id)
    for field, value in payload.model_dump().items():
        setattr(food, field, value)
    db.commit()
    db.refresh(food)
    return food


@router.delete("/{custom_food_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_custom_food(
    custom_food_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    food = _get_owned(db, current_user.id, custom_food_id)
    db.delete(food)
    db.commit()
