from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.models.notification_settings import NotificationSettings
from app.db.models.user import User
from app.db.session import get_db
from app.schemas.notification_settings import (
    NotificationSettingsOut,
    NotificationSettingsUpdate,
)

router = APIRouter(prefix="/notification-settings", tags=["notification-settings"])


def _get_or_create(db: Session, user_id) -> NotificationSettings:
    settings = db.scalar(
        select(NotificationSettings).where(NotificationSettings.user_id == user_id)
    )
    if settings is None:
        settings = NotificationSettings(user_id=user_id)
        db.add(settings)
        db.commit()
        db.refresh(settings)
    return settings


@router.get("", response_model=NotificationSettingsOut)
def get_notification_settings(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    return _get_or_create(db, current_user.id)


@router.put("", response_model=NotificationSettingsOut)
def update_notification_settings(
    payload: NotificationSettingsUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    settings = _get_or_create(db, current_user.id)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(settings, field, value)
    db.commit()
    db.refresh(settings)
    return settings
