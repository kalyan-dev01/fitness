import json
from datetime import date

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai.provider_base import ProviderCallError
from app.ai.provider_manager import NoAvailableProviderError, ProviderManager
from app.api.deps import get_current_user
from app.db.models.user import User
from app.db.models.weekly_report import WeeklyReport
from app.db.session import get_db
from app.schemas.reports import DailyReviewOut, WeeklyReportOut
from app.services.report_engine import (
    gather_daily_summary,
    gather_weekly_summary,
    summary_as_prompt_text,
)

router = APIRouter(prefix="/reports", tags=["reports"])

_DAILY_REVIEW_PROMPT = """\
Based on the day's numbers below, write a short review with three labeled \
parts: "What went well", "What could improve", and "Tomorrow's priority". \
Keep each part to one sentence. Do not invent numbers not given below.
"""

_WEEKLY_REPORT_PROMPT = """\
Based on the week's numbers below, write a short "Coach's Conclusion" \
(2-3 sentences) about how the week went relative to the goal. Then suggest \
next week's targets as JSON on a final line in EXACTLY this format (no \
other text on that line): \
{"calorie_target": number, "protein_target_g": number, "training_target": \
"string", "priority_habit": "string"}. Do not change targets drastically — \
small, sustainable adjustments only. Do not invent numbers not given below.
"""

UNAVAILABLE_REVIEW = (
    "AI Coach is temporarily unavailable, so I can't generate a written "
    "review right now — but your numbers above are accurate and up to date."
)


def _extract_trailing_json(text: str) -> dict:
    last_line = text.strip().splitlines()[-1] if text.strip() else "{}"
    try:
        return json.loads(last_line)
    except json.JSONDecodeError:
        return {}


@router.get("/daily", response_model=DailyReviewOut)
async def get_daily_review(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    summary = gather_daily_summary(db, current_user)
    manager = ProviderManager(db, current_user.id)

    try:
        result = await manager.generate(
            summary_as_prompt_text(summary), system_prompt=_DAILY_REVIEW_PROMPT
        )
        review_text = result.text
        ai_unavailable = False
    except (NoAvailableProviderError, ProviderCallError):
        review_text = UNAVAILABLE_REVIEW
        ai_unavailable = True

    return DailyReviewOut(
        date=date.fromisoformat(summary.date),
        calories=summary.calories,
        protein_g=summary.protein_g,
        carbs_g=summary.carbs_g,
        fat_g=summary.fat_g,
        calorie_target=summary.calorie_target,
        protein_target_g=summary.protein_target_g,
        water_ml=summary.water_ml,
        workout_logged=summary.workout_logged,
        weight_kg=summary.weight_kg,
        review_text=review_text,
        ai_unavailable=ai_unavailable,
    )


@router.get("/weekly", response_model=WeeklyReportOut)
async def get_weekly_report(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    summary = gather_weekly_summary(db, current_user)
    manager = ProviderManager(db, current_user.id)

    default_targets = {
        "calorie_target": summary.calorie_target,
        "protein_target_g": summary.protein_target_g,
        "training_target": "Keep the same schedule as this week",
        "priority_habit": "Stay consistent with logging",
    }

    try:
        result = await manager.generate(
            summary_as_prompt_text(summary), system_prompt=_WEEKLY_REPORT_PROMPT
        )
        conclusion = result.text.strip().rsplit("\n", 1)[0].strip()
        targets = _extract_trailing_json(result.text) or default_targets
        ai_unavailable = False
    except (NoAvailableProviderError, ProviderCallError):
        conclusion = (
            "AI Coach is temporarily unavailable, so I can't generate a "
            "written conclusion — but the numbers above are accurate."
        )
        targets = default_targets
        ai_unavailable = True

    report = WeeklyReport(
        user_id=current_user.id,
        week_start=date.fromisoformat(summary.week_start),
        week_end=date.fromisoformat(summary.week_end),
        summary_json=json.dumps(summary.__dict__),
        conclusion=conclusion,
        next_week_targets_json=json.dumps(targets),
    )
    db.add(report)
    db.commit()
    db.refresh(report)

    return WeeklyReportOut(
        id=report.id,
        week_start=report.week_start,
        week_end=report.week_end,
        avg_calories=summary.avg_calories,
        avg_protein_g=summary.avg_protein_g,
        calorie_target=summary.calorie_target,
        protein_target_g=summary.protein_target_g,
        workouts_logged=summary.workouts_logged,
        avg_water_ml=summary.avg_water_ml,
        weight_change_kg=summary.weight_change_kg,
        latest_weight_kg=summary.latest_weight_kg,
        goal_type=summary.goal_type,
        conclusion=conclusion,
        next_week_targets=targets,
        ai_unavailable=ai_unavailable,
        created_at=report.created_at,
    )


@router.get("/weekly/history", response_model=list[WeeklyReportOut])
def get_weekly_report_history(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    reports = db.scalars(
        select(WeeklyReport)
        .where(WeeklyReport.user_id == current_user.id)
        .order_by(WeeklyReport.week_end.desc())
    ).all()
    out = []
    for r in reports:
        summary = json.loads(r.summary_json)
        targets = json.loads(r.next_week_targets_json)
        out.append(
            WeeklyReportOut(
                id=r.id, week_start=r.week_start, week_end=r.week_end,
                avg_calories=summary.get("avg_calories", 0),
                avg_protein_g=summary.get("avg_protein_g", 0),
                calorie_target=summary.get("calorie_target"),
                protein_target_g=summary.get("protein_target_g"),
                workouts_logged=summary.get("workouts_logged", 0),
                avg_water_ml=summary.get("avg_water_ml", 0),
                weight_change_kg=summary.get("weight_change_kg"),
                latest_weight_kg=summary.get("latest_weight_kg"),
                goal_type=summary.get("goal_type"),
                conclusion=r.conclusion, next_week_targets=targets,
                created_at=r.created_at,
            )
        )
    return out
