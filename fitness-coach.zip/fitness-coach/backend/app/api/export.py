from datetime import datetime, timezone

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.api.deps import get_current_user
from app.db.models.ai_conversation import AIConversation
from app.db.models.meal import Meal
from app.db.models.user import User
from app.db.models.weight import WeightEntry
from app.db.models.workout import WorkoutSession
from app.db.session import get_db

router = APIRouter(prefix="/export", tags=["export"])


@router.get("/data")
def export_data(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """
    Spec section 60: at minimum, nutrition, weight, workout, and AI
    conversation history. JSON is sufficient for v1 — this is a full
    personal-data export, not a paginated API response, so it isn't
    wrapped in a Pydantic response_model (the shape is deliberately a
    flat dump, not a typed API contract meant to be depended on).
    """
    meals = db.scalars(
        select(Meal)
        .options(selectinload(Meal.items))
        .where(Meal.user_id == current_user.id)
        .order_by(Meal.date)
    ).all()
    weight_entries = db.scalars(
        select(WeightEntry).where(WeightEntry.user_id == current_user.id).order_by(WeightEntry.date)
    ).all()
    workouts = db.scalars(
        select(WorkoutSession)
        .options(selectinload(WorkoutSession.exercises))
        .where(WorkoutSession.user_id == current_user.id)
        .order_by(WorkoutSession.date)
    ).all()
    conversations = db.scalars(
        select(AIConversation)
        .options(selectinload(AIConversation.messages))
        .where(AIConversation.user_id == current_user.id)
    ).all()

    return {
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "user_email": current_user.email,
        "nutrition": [
            {
                "date": str(m.date),
                "meal_type": m.meal_type.value,
                "items": [
                    {
                        "label": i.label_snapshot,
                        "quantity": i.quantity,
                        "unit": i.unit.value,
                        "raw_cooked": i.raw_cooked.value,
                        "calories": i.calories_snapshot,
                        "protein_g": i.protein_snapshot,
                        "carbs_g": i.carbs_snapshot,
                        "fat_g": i.fat_snapshot,
                    }
                    for i in m.items
                ],
            }
            for m in meals
        ],
        "weight": [
            {"date": str(w.date), "weight_kg": w.weight_kg, "source": w.source, "note": w.note}
            for w in weight_entries
        ],
        "workouts": [
            {
                "date": str(w.date),
                "notes": w.notes,
                "exercise_count": len(w.exercises),
            }
            for w in workouts
        ],
        "ai_conversations": [
            {
                "id": str(c.id),
                "title": c.title,
                "messages": [
                    {
                        "role": m.role.value,
                        "content": m.content,
                        "provider": m.provider_name,
                        "created_at": m.created_at.isoformat(),
                    }
                    for m in c.messages
                ],
            }
            for c in conversations
        ],
    }
