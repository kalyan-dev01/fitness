from datetime import date as date_type

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.models.profile import UserProfile
from app.db.models.user import User
from app.db.models.water import WaterEntry
from app.db.session import get_db
from app.schemas.water import WaterDailyOut, WaterEntryCreate, WaterEntryOut

router = APIRouter(prefix="/water", tags=["water"])


@router.post("", response_model=WaterEntryOut, status_code=status.HTTP_201_CREATED)
def log_water(
    payload: WaterEntryCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    entry = WaterEntry(user_id=current_user.id, date=payload.date, ml=payload.ml)
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


@router.delete("/{entry_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_water_entry(
    entry_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    entry = db.scalar(
        select(WaterEntry).where(WaterEntry.id == entry_id, WaterEntry.user_id == current_user.id)
    )
    if entry is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Water entry not found")
    db.delete(entry)
    db.commit()


@router.get("/daily", response_model=WaterDailyOut)
def get_daily_water(
    date: date_type,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    entries = list(
        db.scalars(
            select(WaterEntry)
            .where(WaterEntry.user_id == current_user.id, WaterEntry.date == date)
            .order_by(WaterEntry.logged_at)
        ).all()
    )
    profile = db.scalar(
        select(UserProfile).where(UserProfile.user_id == current_user.id)
    )
    return WaterDailyOut(
        date=date,
        total_ml=sum(e.ml for e in entries),
        target_ml=profile.water_target_ml if profile else None,
        entries=entries,
    )
