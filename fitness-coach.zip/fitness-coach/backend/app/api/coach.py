import json

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.ai.provider_manager import NoAvailableProviderError, ProviderManager
from app.ai.provider_base import ProviderCallError
from app.ai.system_prompts.coach_v1 import get_current_system_prompt
from app.api.deps import get_current_user
from app.db.models.ai_conversation import AIConversation, AIMessage, MessageRole
from app.db.models.user import User
from app.db.session import get_db
from app.schemas.coach import (
    AIConversationOut,
    CoachMessageCreate,
    CoachMessageOut,
    ParseFoodRequest,
    ParseFoodResponse,
)
from app.services.context_builder import build_context
from app.services.food_parser import parse_food_text

router = APIRouter(prefix="/coach", tags=["coach"])

UNAVAILABLE_MESSAGE = (
    "AI Coach is temporarily unavailable right now. Your food, workout, "
    "weight, and water logging all still work as normal — try asking me "
    "again in a bit."
)


def _get_or_create_conversation(db: Session, user_id, conversation_id) -> AIConversation:
    if conversation_id:
        conversation = db.scalar(
            select(AIConversation).where(
                AIConversation.id == conversation_id, AIConversation.user_id == user_id
            )
        )
        if conversation is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Conversation not found")
        return conversation

    conversation = AIConversation(user_id=user_id)
    db.add(conversation)
    db.flush()
    return conversation


@router.post("/message", response_model=CoachMessageOut)
async def send_message(
    payload: CoachMessageCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    conversation = _get_or_create_conversation(db, current_user.id, payload.conversation_id)

    db.add(
        AIMessage(
            conversation_id=conversation.id, user_id=current_user.id,
            role=MessageRole.USER, content=payload.message,
        )
    )
    db.commit()

    context = build_context(db, current_user, payload.message)
    system_prompt = f"{get_current_system_prompt()}\n\nContext:\n{context.as_prompt_text()}"

    manager = ProviderManager(db, current_user.id)
    try:
        result = await manager.generate(
            payload.message,
            system_prompt=system_prompt,
            explicit_provider_id=payload.provider_id,
        )
    except NoAvailableProviderError:
        db.add(
            AIMessage(
                conversation_id=conversation.id, user_id=current_user.id,
                role=MessageRole.ASSISTANT, content=UNAVAILABLE_MESSAGE,
                error_detail="No available AI provider",
            )
        )
        db.commit()
        return CoachMessageOut(
            conversation_id=conversation.id, reply=UNAVAILABLE_MESSAGE,
            provider_name=None, model=None, ai_unavailable=True,
        )
    except ProviderCallError as exc:
        # A real, non-fallback-eligible error (e.g. malformed request) —
        # surface it plainly rather than pretending it's a generic outage.
        db.add(
            AIMessage(
                conversation_id=conversation.id, user_id=current_user.id,
                role=MessageRole.ASSISTANT, content=UNAVAILABLE_MESSAGE,
                error_detail=exc.error.message,
            )
        )
        db.commit()
        return CoachMessageOut(
            conversation_id=conversation.id, reply=UNAVAILABLE_MESSAGE,
            provider_name=None, model=None, ai_unavailable=True,
        )

    token_usage = json.dumps(
        {"input_tokens": result.input_tokens, "output_tokens": result.output_tokens}
    )
    db.add(
        AIMessage(
            conversation_id=conversation.id, user_id=current_user.id,
            role=MessageRole.ASSISTANT, content=result.text,
            provider_name=result.provider_name, model=result.model,
            token_usage_json=token_usage, latency_ms=result.latency_ms,
        )
    )
    db.commit()

    return CoachMessageOut(
        conversation_id=conversation.id, reply=result.text,
        provider_name=result.provider_name, model=result.model,
    )


@router.get("/conversations", response_model=list[AIConversationOut])
def list_conversations(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    conversations = db.scalars(
        select(AIConversation)
        .options(selectinload(AIConversation.messages))
        .where(AIConversation.user_id == current_user.id)
        .order_by(AIConversation.created_at.desc())
    ).all()
    return list(conversations)


@router.get("/conversations/{conversation_id}", response_model=AIConversationOut)
def get_conversation(
    conversation_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    conversation = db.scalar(
        select(AIConversation)
        .options(selectinload(AIConversation.messages))
        .where(AIConversation.id == conversation_id, AIConversation.user_id == current_user.id)
    )
    if conversation is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Conversation not found")
    return conversation


@router.post("/parse-food", response_model=ParseFoodResponse)
async def parse_food(
    payload: ParseFoodRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    try:
        items = await parse_food_text(db, current_user.id, payload.text)
    except NoAvailableProviderError:
        return ParseFoodResponse(items=[], ai_unavailable=True)
    except ProviderCallError:
        return ParseFoodResponse(items=[], ai_unavailable=True)
    return ParseFoodResponse(items=items)
