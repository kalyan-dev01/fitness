import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.models.goals import Goal
from app.db.models.user import User
from app.db.models.weight import WeightEntry
from app.db.session import get_db
from app.schemas.weight import WeightEntryCreate, WeightEntryOut, WeightTrendOut
from app.services.trend_engine import calculate_weight_trend

router = APIRouter(prefix="/weight", tags=["weight"])


@router.get("", response_model=list[WeightEntryOut])
def list_weight_entries(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    return list(
        db.scalars(
            select(WeightEntry)
            .where(WeightEntry.user_id == current_user.id)
            .order_by(WeightEntry.date.desc())
        ).all()
    )


@router.post("", response_model=WeightEntryOut, status_code=status.HTTP_201_CREATED)
def log_weight(
    payload: WeightEntryCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    entry = WeightEntry(user_id=current_user.id, **payload.model_dump())
    db.add(entry)
    db.commit()
    db.refresh(entry)
    return entry


@router.delete("/{entry_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_weight_entry(
    entry_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    entry = db.scalar(
        select(WeightEntry).where(
            WeightEntry.id == entry_id, WeightEntry.user_id == current_user.id
        )
    )
    if entry is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Weight entry not found")
    db.delete(entry)
    db.commit()


@router.get("/trend", response_model=WeightTrendOut)
def get_weight_trend(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    entries = list(
        db.scalars(select(WeightEntry).where(WeightEntry.user_id == current_user.id)).all()
    )
    trend = calculate_weight_trend(entries)

    current_goal = db.scalar(
        select(Goal).where(Goal.user_id == current_user.id, Goal.ended_at.is_(None))
    )

    return WeightTrendOut(
        latest_kg=trend.latest_kg,
        latest_date=trend.latest_date,
        change_from_previous_kg=trend.change_from_previous_kg,
        seven_day_avg_kg=trend.seven_day_avg_kg,
        thirty_day_avg_kg=trend.thirty_day_avg_kg,
        thirty_day_change_kg=trend.thirty_day_change_kg,
        goal_weight_kg=current_goal.goal_weight_kg if current_goal else None,
    )
