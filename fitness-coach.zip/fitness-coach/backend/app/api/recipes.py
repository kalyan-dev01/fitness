import uuid
from dataclasses import asdict

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.api.deps import get_current_user
from app.db.models.custom_food import CustomFood
from app.db.models.food import Food
from app.db.models.recipe import Recipe, RecipeIngredient
from app.db.models.user import User
from app.db.session import get_db
from app.schemas.recipe import RecipeCreate, RecipeNutritionOut, RecipeOut
from app.services.nutrition_engine import RawCookedMismatchError
from app.services.recipe_engine import calculate_recipe_nutrition

router = APIRouter(prefix="/recipes", tags=["recipes"])


@router.get("", response_model=list[RecipeOut])
def list_recipes(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    return list(
        db.scalars(
            select(Recipe)
            .options(selectinload(Recipe.ingredients))
            .where(Recipe.user_id == current_user.id)
            .order_by(Recipe.name)
        ).all()
    )


@router.post("", response_model=RecipeOut, status_code=status.HTTP_201_CREATED)
def create_recipe(
    payload: RecipeCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    for ing in payload.ingredients:
        if ing.food_id and db.get(Food, ing.food_id) is None:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Unknown food_id: {ing.food_id}",
            )
        if ing.custom_food_id:
            cf = db.scalar(
                select(CustomFood).where(
                    CustomFood.id == ing.custom_food_id,
                    CustomFood.user_id == current_user.id,
                )
            )
            if cf is None:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Unknown custom_food_id: {ing.custom_food_id}",
                )

    recipe = Recipe(
        user_id=current_user.id,
        name=payload.name,
        servings=payload.servings,
        notes=payload.notes,
        ingredients=[
            RecipeIngredient(
                food_id=ing.food_id,
                custom_food_id=ing.custom_food_id,
                quantity=ing.quantity,
                unit=ing.unit,
            )
            for ing in payload.ingredients
        ],
    )
    db.add(recipe)
    db.commit()
    db.refresh(recipe)
    return recipe


def _get_owned_recipe(db: Session, user_id: uuid.UUID, recipe_id: str) -> Recipe:
    recipe = db.scalar(
        select(Recipe)
        .options(selectinload(Recipe.ingredients))
        .where(Recipe.id == recipe_id, Recipe.user_id == user_id)
    )
    if recipe is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Recipe not found")
    return recipe


@router.get("/{recipe_id}", response_model=RecipeOut)
def get_recipe(
    recipe_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    return _get_owned_recipe(db, current_user.id, recipe_id)


@router.delete("/{recipe_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_recipe(
    recipe_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    recipe = _get_owned_recipe(db, current_user.id, recipe_id)
    db.delete(recipe)
    db.commit()


@router.get("/{recipe_id}/nutrition", response_model=RecipeNutritionOut)
def get_recipe_nutrition(
    recipe_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    Computed on the fly from current food data (not cached) so edits to
    ingredient nutrition are reflected immediately — only meal_items
    (actual diary entries) get frozen snapshots.
    """
    recipe = _get_owned_recipe(db, current_user.id, recipe_id)
    try:
        total, per_serving = calculate_recipe_nutrition(db, recipe)
    except RawCookedMismatchError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)
        ) from exc
    return RecipeNutritionOut(total=asdict(total), per_serving=asdict(per_serving))
