from datetime import date as date_type

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.api.deps import get_current_user
from app.db.models.custom_food import CustomFood
from app.db.models.food import Food
from app.db.models.meal import Meal, MealItem
from app.db.models.recipe import Recipe
from app.db.models.user import User
from app.db.session import get_db
from app.schemas.meal import DailyNutritionSummary, MealCreate, MealOut
from app.services.nutrition_engine import (
    NutritionValues,
    RawCookedMismatchError,
    find_serving,
    scale_serving,
    sum_nutrition,
)
from app.services.recipe_engine import calculate_recipe_nutrition

router = APIRouter(tags=["meals"])


def _resolve_item_nutrition(
    db: Session, user_id, item
) -> tuple[str, NutritionValues]:
    """Returns (label, nutrition) for a single meal item being logged."""
    if item.food_id:
        food = db.scalar(
            select(Food).options(selectinload(Food.servings)).where(Food.id == item.food_id)
        )
        if food is None:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, f"Unknown food_id: {item.food_id}")
        try:
            serving = find_serving(food.servings, unit=item.unit, raw_cooked=item.raw_cooked)
        except RawCookedMismatchError as exc:
            raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, f"'{food.name}': {exc}") from exc
        return food.name, scale_serving(serving, item.quantity)

    if item.custom_food_id:
        cf = db.scalar(
            select(CustomFood).where(
                CustomFood.id == item.custom_food_id, CustomFood.user_id == user_id
            )
        )
        if cf is None:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "Unknown custom_food_id")
        factor = item.quantity / cf.serving_size
        return cf.name, NutritionValues(
            calories=round(cf.calories * factor, 2),
            protein_g=round(cf.protein_g * factor, 2),
            carbs_g=round(cf.carbs_g * factor, 2),
            fat_g=round(cf.fat_g * factor, 2),
        )

    # recipe_id: quantity = number of recipe servings eaten
    recipe = db.scalar(
        select(Recipe)
        .options(selectinload(Recipe.ingredients))
        .where(Recipe.id == item.recipe_id, Recipe.user_id == user_id)
    )
    if recipe is None:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "Unknown recipe_id")
    try:
        _, per_serving = calculate_recipe_nutrition(db, recipe)
    except RawCookedMismatchError as exc:
        raise HTTPException(status.HTTP_422_UNPROCESSABLE_ENTITY, str(exc)) from exc
    return recipe.name, NutritionValues(
        calories=round(per_serving.calories * item.quantity, 2),
        protein_g=round(per_serving.protein_g * item.quantity, 2),
        carbs_g=round(per_serving.carbs_g * item.quantity, 2),
        fat_g=round(per_serving.fat_g * item.quantity, 2),
    )


@router.post("/meals", response_model=MealOut, status_code=status.HTTP_201_CREATED)
def create_meal(
    payload: MealCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    meal = Meal(user_id=current_user.id, date=payload.date, meal_type=payload.meal_type)
    for item in payload.items:
        label, nutrition = _resolve_item_nutrition(db, current_user.id, item)
        meal.items.append(
            MealItem(
                food_id=item.food_id,
                custom_food_id=item.custom_food_id,
                recipe_id=item.recipe_id,
                label_snapshot=label,
                quantity=item.quantity,
                unit=item.unit,
                raw_cooked=item.raw_cooked,
                calories_snapshot=nutrition.calories,
                protein_snapshot=nutrition.protein_g,
                carbs_snapshot=nutrition.carbs_g,
                fat_snapshot=nutrition.fat_g,
            )
        )
    db.add(meal)
    db.commit()
    db.refresh(meal)
    return meal


@router.get("/meals/{meal_id}", response_model=MealOut)
def get_meal(
    meal_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    meal = db.scalar(
        select(Meal)
        .options(selectinload(Meal.items))
        .where(Meal.id == meal_id, Meal.user_id == current_user.id)
    )
    if meal is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Meal not found")
    return meal


@router.delete("/meals/{meal_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_meal(
    meal_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    meal = db.scalar(select(Meal).where(Meal.id == meal_id, Meal.user_id == current_user.id))
    if meal is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Meal not found")
    db.delete(meal)
    db.commit()


@router.get("/nutrition/daily", response_model=DailyNutritionSummary)
def get_daily_summary(
    date: date_type,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    meals = list(
        db.scalars(
            select(Meal)
            .options(selectinload(Meal.items))
            .where(Meal.user_id == current_user.id, Meal.date == date)
        ).all()
    )
    all_items = [
        NutritionValues(
            calories=i.calories_snapshot,
            protein_g=i.protein_snapshot,
            carbs_g=i.carbs_snapshot,
            fat_g=i.fat_snapshot,
        )
        for m in meals
        for i in m.items
    ]
    total = sum_nutrition(all_items)
    return DailyNutritionSummary(
        date=date,
        calories=total.calories,
        protein_g=total.protein_g,
        carbs_g=total.carbs_g,
        fat_g=total.fat_g,
        meals=meals,
    )
