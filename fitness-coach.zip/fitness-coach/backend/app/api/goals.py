from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.models.goals import Goal
from app.db.models.user import User
from app.db.session import get_db
from app.schemas.goals import GoalCreate, GoalOut

router = APIRouter(prefix="/goals", tags=["goals"])


@router.get("/current", response_model=GoalOut)
def get_current_goal(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    goal = db.scalar(
        select(Goal)
        .where(Goal.user_id == current_user.id, Goal.ended_at.is_(None))
        .order_by(Goal.started_at.desc())
    )
    if goal is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No active goal set")
    return goal


@router.get("/history", response_model=list[GoalOut])
def get_goal_history(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    goals = db.scalars(
        select(Goal).where(Goal.user_id == current_user.id).order_by(Goal.started_at.desc())
    ).all()
    return list(goals)


@router.post("", response_model=GoalOut, status_code=status.HTTP_201_CREATED)
def set_goal(
    payload: GoalCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    now = datetime.now(timezone.utc)

    # End whichever goal is currently active — goal history is preserved,
    # never overwritten, so later reports can see what changed and when.
    current = db.scalar(
        select(Goal).where(Goal.user_id == current_user.id, Goal.ended_at.is_(None))
    )
    if current is not None:
        current.ended_at = now

    new_goal = Goal(user_id=current_user.id, started_at=now, **payload.model_dump())
    db.add(new_goal)
    db.commit()
    db.refresh(new_goal)
    return new_goal
