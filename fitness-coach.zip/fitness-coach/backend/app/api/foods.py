from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.api.deps import get_current_user
from app.db.models.food import Food
from app.db.models.user import User
from app.db.session import get_db
from app.schemas.food import FoodOut

router = APIRouter(prefix="/foods", tags=["foods"])


@router.get("", response_model=list[FoodOut])
def search_foods(
    q: str | None = None,
    limit: int = 25,
    _: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    stmt = select(Food).options(selectinload(Food.servings)).limit(min(limit, 100))
    if q:
        stmt = stmt.where(Food.name.ilike(f"%{q}%"))
    return list(db.scalars(stmt).all())


@router.get("/{food_id}", response_model=FoodOut)
def get_food(
    food_id: str, _: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    food = db.scalar(
        select(Food).options(selectinload(Food.servings)).where(Food.id == food_id)
    )
    if food is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Food not found")
    return food
