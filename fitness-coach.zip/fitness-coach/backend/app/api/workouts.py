import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from app.api.deps import get_current_user
from app.db.models.user import User
from app.db.models.workout import (
    Exercise,
    ExerciseSet,
    WorkoutExercise,
    WorkoutSession,
)
from app.db.session import get_db
from app.schemas.workout import WorkoutSessionCreate, WorkoutSessionOut
from app.services.progression_engine import detect_prs

router = APIRouter(prefix="/workouts", tags=["workouts"])


def _load_session(db: Session, session_id, user_id) -> WorkoutSession | None:
    return db.scalar(
        select(WorkoutSession)
        .options(joinedload(WorkoutSession.exercises).joinedload(WorkoutExercise.sets))
        .where(WorkoutSession.id == session_id, WorkoutSession.user_id == user_id)
    )


@router.get("", response_model=list[WorkoutSessionOut])
def list_workouts(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    sessions = db.scalars(
        select(WorkoutSession)
        .options(joinedload(WorkoutSession.exercises).joinedload(WorkoutExercise.sets))
        .where(WorkoutSession.user_id == current_user.id)
        .order_by(WorkoutSession.date.desc())
    ).unique().all()
    return list(sessions)


@router.post("", response_model=WorkoutSessionOut, status_code=status.HTTP_201_CREATED)
def log_workout(
    payload: WorkoutSessionCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    session = WorkoutSession(user_id=current_user.id, date=payload.date, notes=payload.notes)

    for order_index, ex_payload in enumerate(payload.exercises):
        exercise = db.get(Exercise, ex_payload.exercise_id)
        if exercise is None:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "Unknown exercise_id")

        # prior bests, computed BEFORE this session's sets are added
        prior_sets = list(
            db.scalars(
                select(ExerciseSet)
                .join(WorkoutExercise)
                .join(WorkoutSession)
                .where(
                    WorkoutSession.user_id == current_user.id,
                    WorkoutExercise.exercise_id == ex_payload.exercise_id,
                )
            ).all()
        )
        prior_best = detect_prs(exercise.name, prior_sets)

        workout_exercise = WorkoutExercise(exercise_id=exercise.id, order_index=order_index)
        for set_number, set_payload in enumerate(ex_payload.sets, start=1):
            is_pr = (
                prior_best["best_weight_kg"] is None
                or set_payload.weight_kg > prior_best["best_weight_kg"]
                or (
                    prior_best["best_volume"] is not None
                    and set_payload.weight_kg * set_payload.reps > prior_best["best_volume"]
                )
            )
            workout_exercise.sets.append(
                ExerciseSet(
                    set_number=set_number,
                    weight_kg=set_payload.weight_kg,
                    reps=set_payload.reps,
                    rpe=set_payload.rpe,
                    rir=set_payload.rir,
                    notes=set_payload.notes,
                    is_pr=is_pr,
                )
            )
        session.exercises.append(workout_exercise)

    db.add(session)
    db.commit()
    return _load_session(db, session.id, current_user.id)


@router.get("/{session_id}", response_model=WorkoutSessionOut)
def get_workout(
    session_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    session = _load_session(db, session_id, current_user.id)
    if session is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Workout session not found")
    return session


@router.delete("/{session_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_workout(
    session_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    session = db.scalar(
        select(WorkoutSession).where(
            WorkoutSession.id == session_id, WorkoutSession.user_id == current_user.id
        )
    )
    if session is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Workout session not found")
    db.delete(session)
    db.commit()
