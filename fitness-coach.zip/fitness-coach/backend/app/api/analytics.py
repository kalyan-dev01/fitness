from collections import defaultdict
from datetime import date, timedelta

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from app.api.deps import get_current_user
from app.db.models.meal import Meal
from app.db.models.user import User
from app.db.models.weight import WeightEntry
from app.db.models.workout import Exercise, WorkoutExercise, WorkoutSession
from app.db.session import get_db
from app.schemas.analytics import (
    ExerciseStrengthOut,
    ExerciseVolumeOut,
    NutritionSeriesOut,
    SeriesPoint,
    StrengthPoint,
    VolumePoint,
    WeightSeriesOut,
)

router = APIRouter(prefix="/analytics", tags=["analytics"])


@router.get("/weight", response_model=WeightSeriesOut)
def weight_series(
    days: int = 90,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    cutoff = date.today() - timedelta(days=days)
    entries = db.scalars(
        select(WeightEntry)
        .where(WeightEntry.user_id == current_user.id, WeightEntry.date >= cutoff)
        .order_by(WeightEntry.date)
    ).all()
    return WeightSeriesOut(
        points=[SeriesPoint(date=str(e.date), value=e.weight_kg) for e in entries]
    )


@router.get("/nutrition", response_model=NutritionSeriesOut)
def nutrition_series(
    days: int = 30,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    cutoff = date.today() - timedelta(days=days)
    meals = db.scalars(
        select(Meal)
        .options(joinedload(Meal.items))
        .where(Meal.user_id == current_user.id, Meal.date >= cutoff)
    ).unique().all()

    by_day_calories: dict[date, float] = defaultdict(float)
    by_day_protein: dict[date, float] = defaultdict(float)
    for meal in meals:
        for item in meal.items:
            by_day_calories[meal.date] += item.calories_snapshot
            by_day_protein[meal.date] += item.protein_snapshot

    days_sorted = sorted(by_day_calories.keys())
    return NutritionSeriesOut(
        calories=[SeriesPoint(date=str(d), value=round(by_day_calories[d], 1)) for d in days_sorted],
        protein=[SeriesPoint(date=str(d), value=round(by_day_protein[d], 1)) for d in days_sorted],
    )


@router.get("/workout-volume/{exercise_id}", response_model=ExerciseVolumeOut)
def workout_volume(
    exercise_id: str,
    days: int = 90,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    exercise = db.get(Exercise, exercise_id)
    cutoff = date.today() - timedelta(days=days)

    sessions = db.scalars(
        select(WorkoutSession)
        .join(WorkoutExercise)
        .options(joinedload(WorkoutSession.exercises).joinedload(WorkoutExercise.sets))
        .where(
            WorkoutSession.user_id == current_user.id,
            WorkoutSession.date >= cutoff,
            WorkoutExercise.exercise_id == exercise_id,
        )
        .order_by(WorkoutSession.date)
    ).unique().all()

    points = []
    for session in sessions:
        volume = sum(
            s.weight_kg * s.reps
            for we in session.exercises
            if we.exercise_id == exercise_id
            for s in we.sets
        )
        points.append(VolumePoint(date=str(session.date), volume=round(volume, 1)))

    return ExerciseVolumeOut(
        exercise_id=exercise_id,
        exercise_name=exercise.name if exercise else "Unknown",
        points=points,
    )


@router.get("/strength/{exercise_id}", response_model=ExerciseStrengthOut)
def strength_progression(
    exercise_id: str,
    days: int = 180,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    exercise = db.get(Exercise, exercise_id)
    cutoff = date.today() - timedelta(days=days)

    sessions = db.scalars(
        select(WorkoutSession)
        .join(WorkoutExercise)
        .options(joinedload(WorkoutSession.exercises).joinedload(WorkoutExercise.sets))
        .where(
            WorkoutSession.user_id == current_user.id,
            WorkoutSession.date >= cutoff,
            WorkoutExercise.exercise_id == exercise_id,
        )
        .order_by(WorkoutSession.date)
    ).unique().all()

    points = []
    for session in sessions:
        weights = [
            s.weight_kg
            for we in session.exercises
            if we.exercise_id == exercise_id
            for s in we.sets
        ]
        if weights:
            points.append(StrengthPoint(date=str(session.date), best_weight_kg=max(weights)))

    return ExerciseStrengthOut(
        exercise_id=exercise_id,
        exercise_name=exercise.name if exercise else "Unknown",
        points=points,
    )
