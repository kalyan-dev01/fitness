from fastapi import APIRouter, Depends, status
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.models.user import User
from app.db.models.workout import Exercise
from app.db.session import get_db
from app.schemas.exercise import ExerciseCreate, ExerciseOut

router = APIRouter(prefix="/exercises", tags=["exercises"])


@router.get("", response_model=list[ExerciseOut])
def list_exercises(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    # predefined (user_id is null) + this user's own custom exercises
    return list(
        db.scalars(
            select(Exercise)
            .where(or_(Exercise.user_id.is_(None), Exercise.user_id == current_user.id))
            .order_by(Exercise.muscle_group, Exercise.name)
        ).all()
    )


@router.post("", response_model=ExerciseOut, status_code=status.HTTP_201_CREATED)
def create_custom_exercise(
    payload: ExerciseCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    exercise = Exercise(
        name=payload.name,
        muscle_group=payload.muscle_group,
        is_custom=True,
        user_id=current_user.id,
    )
    db.add(exercise)
    db.commit()
    db.refresh(exercise)
    return exercise
