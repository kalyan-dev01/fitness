from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from app.api.deps import get_current_user
from app.db.models.user import User
from app.db.models.workout import Exercise, ExerciseSet, WorkoutExercise, WorkoutSession
from app.db.session import get_db
from app.schemas.workout import ExerciseHistoryOut, ExerciseSetOut, ProgressionOut
from app.services.progression_engine import SetPerformance, detect_prs, suggest_progression

router = APIRouter(prefix="/progression", tags=["progression"])


def _sessions_for_exercise(db: Session, user_id, exercise_id) -> list[WorkoutSession]:
    return list(
        db.scalars(
            select(WorkoutSession)
            .join(WorkoutExercise)
            .options(joinedload(WorkoutSession.exercises).joinedload(WorkoutExercise.sets))
            .where(
                WorkoutSession.user_id == user_id,
                WorkoutExercise.exercise_id == exercise_id,
            )
            .order_by(WorkoutSession.date.desc())
        ).unique().all()
    )


@router.get("/exercises/{exercise_id}/history", response_model=ExerciseHistoryOut)
def get_exercise_history(
    exercise_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    exercise = db.get(Exercise, exercise_id)
    if exercise is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Exercise not found")

    sessions = _sessions_for_exercise(db, current_user.id, exercise_id)
    all_sets: list[ExerciseSet] = [
        s
        for sess in sessions
        for we in sess.exercises
        if we.exercise_id == exercise.id
        for s in we.sets
    ]
    best = detect_prs(exercise.name, all_sets)

    last_session_sets: list[ExerciseSetOut] = []
    last_session_date = None
    if sessions:
        last_session_date = sessions[0].date
        for we in sessions[0].exercises:
            if we.exercise_id == exercise.id:
                last_session_sets = [ExerciseSetOut.model_validate(s) for s in we.sets]

    return ExerciseHistoryOut(
        exercise_id=exercise.id,
        exercise_name=exercise.name,
        best_weight_kg=best["best_weight_kg"],
        best_reps_at_best_weight=best["best_reps_at_best_weight"],
        best_volume=best["best_volume"],
        last_session_date=last_session_date,
        last_session_sets=last_session_sets,
    )


@router.get("/exercises/{exercise_id}/suggestion", response_model=ProgressionOut)
def get_progression_suggestion(
    exercise_id: str,
    target_rep_range_top: int = 10,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    exercise = db.get(Exercise, exercise_id)
    if exercise is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Exercise not found")

    sessions = _sessions_for_exercise(db, current_user.id, exercise_id)
    if len(sessions) < 2:
        result = suggest_progression(
            exercise_name=exercise.name, previous_sets=[], current_sets=[]
        )
        return ProgressionOut(**result.__dict__)

    def sets_for(session: WorkoutSession) -> list[SetPerformance]:
        return [
            SetPerformance(s.weight_kg, s.reps)
            for we in session.exercises
            if we.exercise_id == exercise.id
            for s in we.sets
        ]

    current_sets = sets_for(sessions[0])
    previous_sets = sets_for(sessions[1])

    result = suggest_progression(
        exercise_name=exercise.name,
        previous_sets=previous_sets,
        current_sets=current_sets,
        target_rep_range_top=target_rep_range_top,
    )
    return ProgressionOut(**result.__dict__)
