import uuid
from datetime import date as date_type
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from fastapi.responses import Response
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.core.config import get_settings
from app.db.models.progress_photo import PhotoAngle, ProgressPhoto
from app.db.models.user import User
from app.db.session import get_db
from app.schemas.progress_photo import ProgressPhotoOut

router = APIRouter(prefix="/progress-photos", tags=["progress-photos"])
settings = get_settings()

ALLOWED_CONTENT_TYPES = {"image/jpeg", "image/png", "image/webp"}


def _storage_root() -> Path:
    root = Path(settings.PROGRESS_PHOTO_STORAGE_DIR)
    root.mkdir(parents=True, exist_ok=True)
    return root


def _user_dir(user_id: uuid.UUID) -> Path:
    d = _storage_root() / str(user_id)
    d.mkdir(parents=True, exist_ok=True)
    return d


@router.get("", response_model=list[ProgressPhotoOut])
def list_photos(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    photos = db.scalars(
        select(ProgressPhoto)
        .where(ProgressPhoto.user_id == current_user.id)
        .order_by(ProgressPhoto.date.desc())
    ).all()
    return list(photos)


@router.post("", response_model=ProgressPhotoOut, status_code=status.HTTP_201_CREATED)
async def upload_photo(
    date: date_type = Form(...),
    angle: PhotoAngle = Form(...),
    notes: str | None = Form(default=None),
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if file.content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"Unsupported file type: {file.content_type}. Use JPEG, PNG, or WebP.",
        )

    contents = await file.read()
    if len(contents) > settings.PROGRESS_PHOTO_MAX_BYTES:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "File too large (max 10MB)")

    extension = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}[file.content_type]
    filename = f"{uuid.uuid4()}{extension}"
    file_path = _user_dir(current_user.id) / filename
    file_path.write_bytes(contents)

    photo = ProgressPhoto(
        user_id=current_user.id,
        date=date,
        angle=angle,
        storage_key=f"{current_user.id}/{filename}",
        content_type=file.content_type,
        notes=notes,
    )
    db.add(photo)
    db.commit()
    db.refresh(photo)
    return photo


def _get_owned(db: Session, user_id: uuid.UUID, photo_id: str) -> ProgressPhoto:
    photo = db.scalar(
        select(ProgressPhoto).where(
            ProgressPhoto.id == photo_id, ProgressPhoto.user_id == user_id
        )
    )
    if photo is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Photo not found")
    return photo


@router.get("/{photo_id}/image")
def get_photo_image(
    photo_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    The only route that ever returns image bytes. Ownership is checked
    before touching the filesystem — there is no public URL for any
    progress photo, by design (spec sections 19 and 56).
    """
    photo = _get_owned(db, current_user.id, photo_id)
    file_path = _storage_root() / photo.storage_key
    if not file_path.is_file():
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Photo file missing on disk")

    return Response(content=file_path.read_bytes(), media_type=photo.content_type)


@router.delete("/{photo_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_photo(
    photo_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    photo = _get_owned(db, current_user.id, photo_id)
    file_path = _storage_root() / photo.storage_key
    file_path.unlink(missing_ok=True)
    db.delete(photo)
    db.commit()
