import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import (
    ai_providers,
    analytics,
    auth,
    coach,
    custom_foods,
    exercises,
    export,
    foods,
    goals,
    meals,
    notification_settings,
    profile,
    progress_photos,
    progression,
    recipes,
    reports,
    water,
    weight,
    workouts,
)
from app.core.config import get_settings
from app.core.logging import configure_logging
from app.core.security_headers import SecurityHeadersMiddleware

settings = get_settings()
configure_logging(debug=settings.DEBUG)
logger = logging.getLogger(__name__)

app = FastAPI(title=settings.APP_NAME, debug=settings.DEBUG)

app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.FRONTEND_ORIGIN],
    allow_credentials=True,  # required: session lives in an HTTP-only cookie
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix="/api")
app.include_router(profile.router, prefix="/api")
app.include_router(goals.router, prefix="/api")
app.include_router(foods.router, prefix="/api")
app.include_router(custom_foods.router, prefix="/api")
app.include_router(recipes.router, prefix="/api")
app.include_router(meals.router, prefix="/api")
app.include_router(weight.router, prefix="/api")
app.include_router(water.router, prefix="/api")
app.include_router(exercises.router, prefix="/api")
app.include_router(workouts.router, prefix="/api")
app.include_router(progression.router, prefix="/api")
app.include_router(ai_providers.router, prefix="/api")
app.include_router(coach.router, prefix="/api")
app.include_router(reports.router, prefix="/api")
app.include_router(analytics.router, prefix="/api")
app.include_router(progress_photos.router, prefix="/api")
app.include_router(notification_settings.router, prefix="/api")
app.include_router(export.router, prefix="/api")


@app.get("/api/health")
def health():
    return {"status": "ok", "app": settings.APP_NAME, "env": settings.ENV}


@app.on_event("startup")
def on_startup():
    logger.info("Starting %s (env=%s)", settings.APP_NAME, settings.ENV)
