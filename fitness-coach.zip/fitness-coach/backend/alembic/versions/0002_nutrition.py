"""nutrition: foods, custom_foods, recipes, meals

Revision ID: 0002_nutrition
Revises: 0001_initial
Create Date: 2026-09-17

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0002_nutrition"
down_revision: Union[str, None] = "0001_initial"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

UNIT_VALUES = ("g", "ml", "piece", "tsp", "tbsp", "cup", "serving")
RAW_COOKED_VALUES = ("RAW", "COOKED", "NA")


def upgrade() -> None:
    bind = op.get_bind()

    unit_enum = postgresql.ENUM(*UNIT_VALUES, name="unit_enum")
    raw_cooked_enum = postgresql.ENUM(*RAW_COOKED_VALUES, name="raw_cooked_enum")
    food_source_enum = postgresql.ENUM("IFCT", "USDA", "MANUAL", name="food_source_enum")
    meal_type_enum = postgresql.ENUM(
        "BREAKFAST", "LUNCH", "DINNER", "SNACK", "PRE_WORKOUT", "POST_WORKOUT",
        name="meal_type_enum",
    )
    unit_enum.create(bind, checkfirst=True)
    raw_cooked_enum.create(bind, checkfirst=True)
    food_source_enum.create(bind, checkfirst=True)
    meal_type_enum.create(bind, checkfirst=True)

    op.create_table(
        "foods",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("brand", sa.String(120), nullable=True),
        sa.Column("source", food_source_enum, nullable=False),
        sa.Column("is_verified", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("default_unit", unit_enum, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_foods_name", "foods", ["name"])

    op.create_table(
        "food_servings",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "food_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("foods.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column("unit", unit_enum, nullable=False),
        sa.Column("raw_cooked", raw_cooked_enum, nullable=False),
        sa.Column("grams_per_unit", sa.Float(), nullable=True),
        sa.Column("calories", sa.Float(), nullable=False),
        sa.Column("protein_g", sa.Float(), nullable=False),
        sa.Column("carbs_g", sa.Float(), nullable=False),
        sa.Column("fat_g", sa.Float(), nullable=False),
        sa.Column("fiber_g", sa.Float(), nullable=True),
        sa.Column("sugar_g", sa.Float(), nullable=True),
        sa.Column("sodium_mg", sa.Float(), nullable=True),
    )
    op.create_index("ix_food_servings_food_id", "food_servings", ["food_id"])

    op.create_table(
        "custom_foods",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("brand", sa.String(120), nullable=True),
        sa.Column("serving_size", sa.Float(), nullable=False),
        sa.Column("unit", unit_enum, nullable=False),
        sa.Column("calories", sa.Float(), nullable=False),
        sa.Column("protein_g", sa.Float(), nullable=False),
        sa.Column("carbs_g", sa.Float(), nullable=False),
        sa.Column("fat_g", sa.Float(), nullable=False),
        sa.Column("fiber_g", sa.Float(), nullable=True),
        sa.Column("sugar_g", sa.Float(), nullable=True),
        sa.Column("sodium_mg", sa.Float(), nullable=True),
        sa.Column("raw_cooked", raw_cooked_enum, nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_custom_foods_user_id", "custom_foods", ["user_id"])

    op.create_table(
        "recipes",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column("name", sa.String(200), nullable=False),
        sa.Column("servings", sa.Integer(), nullable=False, server_default="1"),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_recipes_user_id", "recipes", ["user_id"])

    op.create_table(
        "recipe_ingredients",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "recipe_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("recipes.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column(
            "food_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("foods.id", ondelete="RESTRICT"), nullable=True,
        ),
        sa.Column(
            "custom_food_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("custom_foods.id", ondelete="RESTRICT"), nullable=True,
        ),
        sa.Column("quantity", sa.Float(), nullable=False),
        sa.Column("unit", unit_enum, nullable=False),
        sa.CheckConstraint(
            "(food_id IS NOT NULL)::int + (custom_food_id IS NOT NULL)::int = 1",
            name="ck_recipe_ingredient_exactly_one_source",
        ),
    )
    op.create_index("ix_recipe_ingredients_recipe_id", "recipe_ingredients", ["recipe_id"])

    op.create_table(
        "meals",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column("date", sa.Date(), nullable=False),
        sa.Column("meal_type", meal_type_enum, nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_meals_user_id", "meals", ["user_id"])
    op.create_index("ix_meals_date", "meals", ["date"])

    op.create_table(
        "meal_items",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "meal_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("meals.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column(
            "food_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("foods.id", ondelete="SET NULL"), nullable=True,
        ),
        sa.Column(
            "custom_food_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("custom_foods.id", ondelete="SET NULL"), nullable=True,
        ),
        sa.Column(
            "recipe_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("recipes.id", ondelete="SET NULL"), nullable=True,
        ),
        sa.Column("label_snapshot", sa.String(), nullable=False, server_default=""),
        sa.Column("quantity", sa.Float(), nullable=False),
        sa.Column("unit", unit_enum, nullable=False),
        sa.Column("raw_cooked", raw_cooked_enum, nullable=False),
        sa.Column("calories_snapshot", sa.Float(), nullable=False),
        sa.Column("protein_snapshot", sa.Float(), nullable=False),
        sa.Column("carbs_snapshot", sa.Float(), nullable=False),
        sa.Column("fat_snapshot", sa.Float(), nullable=False),
    )
    op.create_index("ix_meal_items_meal_id", "meal_items", ["meal_id"])


def downgrade() -> None:
    op.drop_table("meal_items")
    op.drop_index("ix_meals_date", table_name="meals")
    op.drop_index("ix_meals_user_id", table_name="meals")
    op.drop_table("meals")
    op.drop_table("recipe_ingredients")
    op.drop_table("recipes")
    op.drop_table("custom_foods")
    op.drop_table("food_servings")
    op.drop_table("foods")

    op.execute("DROP TYPE IF EXISTS meal_type_enum")
    op.execute("DROP TYPE IF EXISTS food_source_enum")
    op.execute("DROP TYPE IF EXISTS raw_cooked_enum")
    op.execute("DROP TYPE IF EXISTS unit_enum")
