"""progress photos

Revision ID: 0008_progress_photos
Revises: 0007_reports
Create Date: 2026-10-29

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0008_progress_photos"
down_revision: Union[str, None] = "0007_reports"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    bind = op.get_bind()
    angle_enum = postgresql.ENUM("FRONT", "SIDE", "BACK", name="photo_angle_enum")
    angle_enum.create(bind, checkfirst=True)

    op.create_table(
        "progress_photos",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column("date", sa.Date(), nullable=False),
        sa.Column("angle", angle_enum, nullable=False),
        sa.Column("storage_key", sa.String(300), nullable=False),
        sa.Column("content_type", sa.String(50), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_progress_photos_user_id", "progress_photos", ["user_id"])
    op.create_index("ix_progress_photos_date", "progress_photos", ["date"])


def downgrade() -> None:
    op.drop_table("progress_photos")
    op.execute("DROP TYPE IF EXISTS photo_angle_enum")
