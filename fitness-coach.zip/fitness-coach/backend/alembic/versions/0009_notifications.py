"""notification settings

Revision ID: 0009_notifications
Revises: 0008_progress_photos
Create Date: 2026-11-05

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0009_notifications"
down_revision: Union[str, None] = "0008_progress_photos"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "notification_settings",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True,
        ),
        sa.Column("remind_log_weight", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("remind_drink_water", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("remind_workout", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("remind_log_meals", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("remind_weekly_report", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )


def downgrade() -> None:
    op.drop_table("notification_settings")
