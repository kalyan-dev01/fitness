"""initial: users, user_profiles, goals

Revision ID: 0001_initial
Revises:
Create Date: 2026-09-10

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0001_initial"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute('CREATE EXTENSION IF NOT EXISTS "uuid-ossp"')

    op.create_table(
        "users",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("email", sa.String(320), nullable=False),
        sa.Column("password_hash", sa.String(255), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_users_email", "users", ["email"], unique=True)

    sex_enum = postgresql.ENUM("MALE", "FEMALE", "OTHER", name="sex_enum")
    activity_enum = postgresql.ENUM(
        "SEDENTARY", "LIGHT", "MODERATE", "ACTIVE", "VERY_ACTIVE",
        name="activity_level_enum",
    )
    sex_enum.create(op.get_bind(), checkfirst=True)
    activity_enum.create(op.get_bind(), checkfirst=True)

    op.create_table(
        "user_profiles",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "user_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
            unique=True,
        ),
        sa.Column("name", sa.String(120), nullable=True),
        sa.Column("age", sa.Integer(), nullable=True),
        sa.Column("sex", sex_enum, nullable=True),
        sa.Column("height_cm", sa.Float(), nullable=True),
        sa.Column("activity_level", activity_enum, nullable=True),
        sa.Column("training_frequency", sa.Integer(), nullable=True),
        sa.Column("dietary_preferences", postgresql.ARRAY(sa.String()), nullable=True),
        sa.Column("foods_to_avoid", postgresql.ARRAY(sa.String()), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )

    goal_type_enum = postgresql.ENUM(
        "CUT", "MAINTAIN", "LEAN_BULK", "BULK", name="goal_type_enum"
    )
    goal_type_enum.create(op.get_bind(), checkfirst=True)

    op.create_table(
        "goals",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "user_id",
            postgresql.UUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column("goal_type", goal_type_enum, nullable=False),
        sa.Column("weight_kg", sa.Float(), nullable=True),
        sa.Column("goal_weight_kg", sa.Float(), nullable=True),
        sa.Column("calorie_target", sa.Integer(), nullable=True),
        sa.Column("protein_target_g", sa.Integer(), nullable=True),
        sa.Column("carb_target_g", sa.Integer(), nullable=True),
        sa.Column("fat_target_g", sa.Integer(), nullable=True),
        sa.Column(
            "is_auto_calculated", sa.Boolean(), nullable=False, server_default=sa.true()
        ),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("ended_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_goals_user_id", "goals", ["user_id"])


def downgrade() -> None:
    op.drop_index("ix_goals_user_id", table_name="goals")
    op.drop_table("goals")
    op.execute("DROP TYPE IF EXISTS goal_type_enum")

    op.drop_table("user_profiles")
    op.execute("DROP TYPE IF EXISTS activity_level_enum")
    op.execute("DROP TYPE IF EXISTS sex_enum")

    op.drop_index("ix_users_email", table_name="users")
    op.drop_table("users")
