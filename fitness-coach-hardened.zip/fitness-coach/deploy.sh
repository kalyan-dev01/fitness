#!/usr/bin/env bash
# One-command production deployment for a fresh (or existing) Ubuntu VPS:
#
#   git clone <REPO_URL> && cd fitness-coach && sudo bash deploy.sh
#
# Safe to run again for updates -- it never deletes the pgdata or
# photo_storage volumes, never overwrites secrets already set in .env,
# and re-running it on an already-deployed host just rebuilds images,
# re-runs migrations, and restarts services with the new code.

set -Eeuo pipefail

COMPOSE_FILE="docker-compose.prod.yml"
ENV_FILE=".env"
LOG_TAIL_LINES=80

log()  { echo -e "\033[1;34m[deploy]\033[0m $*"; }
ok()   { echo -e "\033[1;32m[deploy]\033[0m $*"; }
warn() { echo -e "\033[1;33m[deploy]\033[0m $*"; }
fail() { echo -e "\033[1;31m[deploy] ERROR:\033[0m $*" >&2; exit 1; }

on_error() {
  local exit_code=$?
  echo
  warn "Deployment failed (exit code $exit_code). Recent logs from each service:"
  for svc in postgres backend frontend caddy; do
    echo "----- $svc (last $LOG_TAIL_LINES lines) -----"
    docker compose -f "$COMPOSE_FILE" logs --tail "$LOG_TAIL_LINES" "$svc" 2>/dev/null || echo "  (no logs -- container may not have started)"
  done
  warn "No persistent volumes (pgdata, photo_storage) were deleted by this run."
  exit "$exit_code"
}
trap on_error ERR

# ── 0. Must run as root (installs system packages) ─────────────────────
if [ "$(id -u)" -ne 0 ]; then
  fail "This script must be run as root: sudo bash deploy.sh"
fi

# ── 1. Detect Ubuntu ─────────────────────────────────────────────────
if [ ! -f /etc/os-release ] || ! grep -qi ubuntu /etc/os-release; then
  fail "This script is written for Ubuntu. Detected: $(cat /etc/os-release 2>/dev/null | head -1 || echo unknown)"
fi
. /etc/os-release
log "Detected Ubuntu $VERSION_ID"

# ── 2. Install Docker + Compose plugin if missing ───────────────────────
if ! command -v docker >/dev/null 2>&1; then
  log "Docker not found -- installing..."
  apt-get update -qq
  apt-get install -y -qq ca-certificates curl gnupg
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
  chmod a+r /etc/apt/keyrings/docker.asc
  ARCH="$(dpkg --print-architecture)"
  echo "deb [arch=${ARCH} signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu ${VERSION_CODENAME} stable" \
    > /etc/apt/sources.list.d/docker.list
  apt-get update -qq
  apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
  systemctl enable --now docker
  ok "Docker installed."
else
  ok "Docker already installed ($(docker --version))."
fi

if ! docker compose version >/dev/null 2>&1; then
  fail "Docker Compose plugin is not available even after install attempt. Install docker-compose-plugin manually and re-run."
fi

# ── 3. Validate required commands ───────────────────────────────────────
for cmd in curl openssl python3 sha256sum; do
  command -v "$cmd" >/dev/null 2>&1 || { apt-get install -y -qq "$cmd" || fail "Required command '$cmd' is missing and could not be installed."; }
done

# ── 4. Required directories ─────────────────────────────────────────────
mkdir -p backups
ok "Ensured ./backups directory exists."

# ── 5. Create/validate .env, generating strong secrets when missing ────
if [ ! -f "$ENV_FILE" ]; then
  [ -f .env.example ] || fail ".env.example not found -- cannot bootstrap $ENV_FILE."
  cp .env.example "$ENV_FILE"
  log "Created $ENV_FILE from .env.example -- generating secrets and production defaults..."
else
  log "$ENV_FILE already exists -- will fill in ONLY missing/placeholder values, never overwrite real secrets."
fi

# Helper: set a key in .env only if it's currently unset or still equal to
# a known placeholder value. Never touches a key that already holds
# anything else -- this is what makes re-running deploy.sh safe and what
# guarantees an existing production secret is never clobbered.
set_env_if_placeholder() {
  local key="$1" new_value="$2"; shift 2
  local placeholders=("$@")
  local current
  current="$(grep -E "^${key}=" "$ENV_FILE" | head -1 | cut -d= -f2- || true)"
  if [ -z "$current" ]; then
    echo "${key}=${new_value}" >> "$ENV_FILE"
    log "Set ${key} (was missing)."
    return
  fi
  for placeholder in "${placeholders[@]}"; do
    if [ "$current" = "$placeholder" ]; then
      sed -i "s#^${key}=.*#${key}=${new_value}#" "$ENV_FILE"
      log "Generated a new value for ${key} (was placeholder)."
      return
    fi
  done
  # Already has a real value -- leave it untouched.
}

set_env_if_placeholder JWT_SECRET "$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')" \
  "" "replace-with-a-long-random-value" "change-me-in-.env"
set_env_if_placeholder FIELD_ENCRYPTION_KEY "$(python3 -c 'from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())' 2>/dev/null || openssl rand -base64 32)" \
  "" "replace-with-a-generated-fernet-key"
set_env_if_placeholder POSTGRES_PASSWORD "$(openssl rand -hex 24)" \
  "" "change-me"

# Force production-safe values regardless of what's in .env.example --
# these aren't secrets, they're required-correct settings for prod.
for kv in "ENV=production" "DEBUG=false" "COOKIE_SECURE=true"; do
  key="${kv%%=*}"
  if grep -qE "^${key}=" "$ENV_FILE"; then
    sed -i "s#^${key}=.*#${kv}#" "$ENV_FILE"
  else
    echo "$kv" >> "$ENV_FILE"
  fi
done

# ── 6. Prompt for / validate DOMAIN ─────────────────────────────────────
CURRENT_DOMAIN="$(grep -E '^DOMAIN=' "$ENV_FILE" | head -1 | cut -d= -f2- || true)"
if [ -z "$CURRENT_DOMAIN" ] || [ "$CURRENT_DOMAIN" = "fitness.example.com" ]; then
  if [ -t 0 ]; then
    read -r -p "Enter the domain this will be served from (must already point at this server's IP): " CURRENT_DOMAIN
  fi
  [ -n "$CURRENT_DOMAIN" ] || fail "DOMAIN is not set in $ENV_FILE and none was provided interactively. Set DOMAIN=yourdomain.com in $ENV_FILE and re-run."
  sed -i "s#^DOMAIN=.*#DOMAIN=${CURRENT_DOMAIN}#" "$ENV_FILE"
fi
DOMAIN="$CURRENT_DOMAIN"
sed -i "s#^FRONTEND_ORIGIN=.*#FRONTEND_ORIGIN=https://${DOMAIN}#" "$ENV_FILE"
sed -i "s#^NEXT_PUBLIC_API_BASE_URL=.*#NEXT_PUBLIC_API_BASE_URL=https://${DOMAIN}/api#" "$ENV_FILE"
ok "Using domain: $DOMAIN"

# ── 7. Validate required environment variables ──────────────────────────
set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

REQUIRED_VARS=(POSTGRES_USER POSTGRES_PASSWORD POSTGRES_DB JWT_SECRET FIELD_ENCRYPTION_KEY DOMAIN)
for var in "${REQUIRED_VARS[@]}"; do
  [ -n "${!var:-}" ] || fail "$var is required but not set in $ENV_FILE."
done
[ "${#JWT_SECRET}" -ge 32 ] || fail "JWT_SECRET is too short (need >= 32 chars). Delete the line from $ENV_FILE and re-run to auto-generate a new one."
ok "Environment variables validated."

# ── 8. Validate Docker Compose configuration before starting anything ──
log "Validating Docker Compose configuration..."
docker compose -f "$COMPOSE_FILE" config > /dev/null || fail "docker-compose.prod.yml failed validation."
ok "Compose configuration is valid."

# ── 9. Validate Caddyfile ───────────────────────────────────────────────
log "Validating Caddyfile..."
docker run --rm -v "$(pwd)/infra/nginx/Caddyfile:/etc/caddy/Caddyfile" -e "DOMAIN=${DOMAIN}" \
  caddy:2-alpine caddy validate --config /etc/caddy/Caddyfile --envfile <(echo "DOMAIN=${DOMAIN}") \
  || fail "Caddyfile failed validation."
ok "Caddyfile is valid."

# ── 10. Build images ─────────────────────────────────────────────────────
log "Building images (this can take a few minutes on first run)..."
docker compose -f "$COMPOSE_FILE" build

# ── 11. Start PostgreSQL first and wait until it's actually ready ──────
log "Starting PostgreSQL..."
docker compose -f "$COMPOSE_FILE" up -d postgres

log "Waiting for PostgreSQL to become ready..."
READY=0
for i in $(seq 1 60); do
  if docker compose -f "$COMPOSE_FILE" exec -T postgres pg_isready -U "$POSTGRES_USER" > /dev/null 2>&1; then
    READY=1
    break
  fi
  sleep 2
done
[ "$READY" -eq 1 ] || fail "PostgreSQL did not become ready within 120s."
ok "PostgreSQL is ready."

# ── 12. Run Alembic migrations exactly once, as an explicit step ───────
# NOT part of any container's startup command -- see backend/Dockerfile
# and docker-compose.prod.yml's `migrate` service for why. `docker compose
# run` here creates a single one-off container, runs migrations to
# completion, and exits -- it cannot race with itself or with a backend
# replica because nothing else starts until this step succeeds.
log "Running database migrations..."
docker compose -f "$COMPOSE_FILE" run --rm migrate
ok "Migrations complete."

# ── 13. Start backend, frontend, Caddy ──────────────────────────────────
log "Starting backend, frontend, and Caddy..."
docker compose -f "$COMPOSE_FILE" up -d --remove-orphans backend frontend caddy

# ── 14. Wait for backend readiness (real DB-connectivity check) ────────
log "Waiting for backend readiness..."
READY=0
for i in $(seq 1 60); do
  if docker compose -f "$COMPOSE_FILE" exec -T backend curl -sf http://localhost:8000/health/ready > /dev/null 2>&1; then
    READY=1
    break
  fi
  sleep 2
done
[ "$READY" -eq 1 ] || fail "Backend did not become ready within 120s."
ok "Backend is ready."

# ── 15. Verify frontend availability ────────────────────────────────────
log "Verifying frontend..."
READY=0
for i in $(seq 1 30); do
  if docker compose -f "$COMPOSE_FILE" exec -T frontend curl -sf http://localhost:3000/ > /dev/null 2>&1; then
    READY=1
    break
  fi
  sleep 2
done
[ "$READY" -eq 1 ] || fail "Frontend did not respond within 60s."
ok "Frontend is responding."

# ── 16. Verify Caddy is up and (best-effort) serving HTTPS ─────────────
log "Verifying Caddy..."
sleep 3
if ! docker compose -f "$COMPOSE_FILE" ps caddy | grep -qi "running\|up"; then
  fail "Caddy container is not running."
fi
ok "Caddy is running. (Let's Encrypt certificate issuance can take up to a minute after this -- check with: docker compose -f $COMPOSE_FILE logs caddy)"

chmod +x backup.sh restore.sh deploy.sh 2>/dev/null || true

# ── 17. Status summary ──────────────────────────────────────────────────
echo
ok "=================================================================="
ok " Deployment complete: https://${DOMAIN}"
ok "=================================================================="
echo
docker compose -f "$COMPOSE_FILE" ps
echo
echo "Useful commands:"
echo "  Logs:            docker compose -f $COMPOSE_FILE logs -f [service]"
echo "  Health:          curl -s https://${DOMAIN}/health/ready"
echo "  Backup:          ./backup.sh"
echo "  Restore:         ./restore.sh --list"
echo "  Redeploy update: git pull && sudo bash deploy.sh"
echo
