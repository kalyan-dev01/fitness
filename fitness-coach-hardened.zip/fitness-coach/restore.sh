#!/usr/bin/env bash
# Restores PostgreSQL and progress photos from a backup set produced by
# backup.sh. Always restore both from the SAME timestamp -- database rows
# reference photos by storage_key, so restoring the database from one
# point in time and photos from another can leave the DB pointing at
# photos that don't exist (or vice versa: orphaned photos on disk that no
# DB row references). The manifest file this script requires is exactly
# what enforces that: it's written once, atomically, listing both file
# names and their checksums together.
#
# Usage:
#   ./restore.sh <timestamp>              # e.g. ./restore.sh 20260914-030000
#   ./restore.sh --list                   # show available backup timestamps
#
# This intentionally stops the backend before touching anything and only
# restarts it once both restores have succeeded, so nothing can read or
# write through a half-restored state.

set -Eeuo pipefail

BACKUP_DIR="${BACKUP_DIR:-./backups}"
COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.prod.yml}"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"; }
fail() { log "ERROR: $*"; exit 1; }

if [ -f .env ]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

if [ "${1:-}" = "--list" ] || [ -z "${1:-}" ]; then
  echo "Available backups in $BACKUP_DIR:"
  ls -1 "$BACKUP_DIR"/manifest-*.txt 2>/dev/null | sed -E 's/.*manifest-(.*)\.txt/  \1/' \
    || echo "  (none found)"
  echo
  echo "Usage: ./restore.sh <timestamp>"
  exit 0
fi

TIMESTAMP="$1"
MANIFEST_PATH="$BACKUP_DIR/manifest-$TIMESTAMP.txt"
[ -f "$MANIFEST_PATH" ] || fail "No manifest found at $MANIFEST_PATH. Run './restore.sh --list' to see available backups."

# shellcheck disable=SC1090
source "$MANIFEST_PATH"
DB_BACKUP_PATH="$BACKUP_DIR/$db_file"
PHOTOS_BACKUP_PATH="$BACKUP_DIR/$photos_file"

[ -f "$DB_BACKUP_PATH" ] || fail "Database backup file missing: $DB_BACKUP_PATH"
[ -f "$PHOTOS_BACKUP_PATH" ] || fail "Photo backup file missing: $PHOTOS_BACKUP_PATH"

log "Verifying backup integrity against manifest checksums..."
echo "${db_sha256}  ${DB_BACKUP_PATH}" | sha256sum -c - || fail "Database backup checksum mismatch -- refusing to restore a possibly-corrupt file."
echo "${photos_sha256}  ${PHOTOS_BACKUP_PATH}" | sha256sum -c - || fail "Photo backup checksum mismatch -- refusing to restore a possibly-corrupt file."
log "Checksums verified OK."

find_compose_volume() {
  local logical_name="$1" vol wd
  for vol in $(docker volume ls --filter "label=com.docker.compose.volume=${logical_name}" --format '{{.Name}}'); do
    wd=$(docker volume inspect "$vol" --format '{{ index .Labels "com.docker.compose.project.working_dir" }}' 2>/dev/null || true)
    [ "$wd" = "$(pwd)" ] && echo "$vol" && return 0
  done
  return 1
}
PHOTO_VOLUME="$(find_compose_volume photo_storage)" || fail "Could not find the photo_storage Docker volume for this project."

echo
echo "About to restore from backup timestamp: $TIMESTAMP"
echo "  Database  <- $DB_BACKUP_PATH"
echo "  Photos    <- $PHOTOS_BACKUP_PATH (volume: $PHOTO_VOLUME)"
echo
echo "THIS WILL OVERWRITE the current database and all progress photos."
read -r -p "Type 'restore' to continue: " confirmation
[ "$confirmation" = "restore" ] || fail "Restore cancelled."

log "Stopping backend so nothing reads/writes during restore..."
docker compose -f "$COMPOSE_FILE" stop backend

log "Restoring database..."
# Drop and recreate the schema first so the restore starts from a clean
# slate -- otherwise leftover rows/sequences from the current DB that
# aren't in the dump can survive the restore and cause subtle corruption.
docker compose -f "$COMPOSE_FILE" exec -T postgres \
  psql -U "${POSTGRES_USER:-fitness}" -d "${POSTGRES_DB:-fitness_coach}" \
  -c "DROP SCHEMA public CASCADE; CREATE SCHEMA public;"
gunzip -c "$DB_BACKUP_PATH" | docker compose -f "$COMPOSE_FILE" exec -T postgres \
  psql -U "${POSTGRES_USER:-fitness}" -d "${POSTGRES_DB:-fitness_coach}"
log "Database restored."

log "Restoring progress photos..."
docker run --rm \
  -v "${PHOTO_VOLUME}:/data" \
  -v "$(cd "$BACKUP_DIR" && pwd):/backup:ro" \
  alpine sh -c "rm -rf /data/* /data/.[!.]* 2>/dev/null; tar xzf /backup/$(basename "$PHOTOS_BACKUP_PATH") -C /data"
log "Photo storage restored."

log "Restarting backend..."
docker compose -f "$COMPOSE_FILE" start backend

log "Waiting for backend to report ready..."
for _ in $(seq 1 30); do
  if docker compose -f "$COMPOSE_FILE" exec -T backend curl -sf http://localhost:8000/health/ready > /dev/null 2>&1; then
    log "Restore complete -- backend is healthy."
    exit 0
  fi
  sleep 2
done
fail "Backend did not become ready after restore. Check logs: docker compose -f $COMPOSE_FILE logs backend"
