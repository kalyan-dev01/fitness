# Fitness Coach

Personal AI fitness & nutrition coach — Next.js + FastAPI + PostgreSQL.

## Status

- **Phase 1 (Foundation):** done — auth, user profile, goals, Docker dev
  environment, migrations, tests.
- **Phase 2 (Nutrition):** done — deterministic calorie/macro engine,
  food database (raw/cooked aware), custom foods, recipes, meal diary,
  daily nutrition summary, starter Indian food seed data, nutrition page
  + home dashboard wired to real data.
- **Phase 3 (Weight & Hydration):** done — weight logging with 7/30-day
  trend math (deliberately dampens single-outlier overreaction), water
  logging with quick-add buttons and a customizable daily target, both
  wired into the Home dashboard and a real Progress page.
- **Phase 4 (Workout):** done — predefined exercise database, workout
  logging with sets/reps/optional RPE-RIR, deterministic PR detection on
  every save, and a progressive-overload suggestion engine (explicit rule:
  hit the top of the rep range on every set → suggest +2.5kg upper body /
  +5kg lower body next time).
- **Phase 5 (AI Provider Manager):** done — provider abstraction
  (`AIProvider` interface), an `OpenAICompatibleProvider` shared by
  Gemini/Groq/OpenRouter/Mistral/Ollama, encrypted-at-rest API keys,
  `ProviderManager` with priority-ordered automatic fallback restricted to
  `is_free_only` providers, cooldowns after hard failures (429/timeout/5xx/
  network — never on a merely slow success), usage/health/event tracking,
  and a Settings page to add/test/enable/disable providers. Anthropic is
  registered as paid (`is_free_only=False`) and the cost-safety guardrail
  is enforced server-side, not just in the UI: the API refuses to let a
  paid provider have automatic fallback turned on, regardless of what's
  sent in the request.
- **Phase 6 (AI Coach):** done — Context Builder (keyword-based question
  classification → minimal targeted DB queries, never a full-DB dump),
  versioned system prompt, `/coach/message` with full conversation
  persistence and graceful degradation (returns 200 + a clear "unavailable"
  message when no provider is configured or all fail — never a 500),
  natural-language Quick Add food parsing (`/coach/parse-food` — AI extracts
  structure only, deterministic matching + nutrition calc, nothing is ever
  auto-saved), quick-action buttons, and a Coach Insight card on the Home
  dashboard.
- **Phase 7 (Reports & Analytics):** done — deterministic daily/weekly data
  gathering (`report_engine.py`; the AI only ever writes narrative text
  around numbers the app already computed, never recalculates them),
  `/reports/daily` (Today's Review) and `/reports/weekly` (Weekly Coach
  Report, persisted to `weekly_reports` with suggested — never
  auto-applied — next-week targets), analytics endpoints for weight/
  nutrition/workout-volume/strength series, a weight trend chart
  (recharts) on the Progress page, and both review types wired into the UI
  there. Both report endpoints degrade gracefully with the same
  `ai_unavailable` pattern as Phase 6 when no provider is configured.
- **Phase 8 (Progress Photos):** done — private per-user file storage
  outside any public web root, a single authenticated streaming endpoint
  (`GET /progress-photos/{id}/image`) that checks ownership before ever
  touching disk, upload with content-type/size validation, and delete that
  removes both the file and the DB row (no soft-delete grace period for
  these — sensitive photos get properly deleted). Wired into the Progress
  page with a private photo grid.
- **Phase 9 (PWA & Deployment):** done — basic offline app-shell service
  worker (static shell only; API calls are never cached, so data always
  reflects the network or fails honestly), in-app notification preferences
  (banners while the app is open — see the honest limitation note below),
  full JSON data export, dark/light theme toggle, security headers
  middleware, a lightweight in-memory rate limiter on login/register,
  production Docker Compose (`docker-compose.prod.yml`) with Caddy as the
  reverse proxy for automatic HTTPS behind Cloudflare, and a backup script
  with restore instructions.

This completes all 9 phases from the original spec.

⚠️ **Known gaps and simplifications, called out honestly rather than
faking completeness:**
- **Notifications are not real push notifications.** They're in-app
  banners shown only while the app is open. True background push (working
  when the app/browser is closed) needs a push service — VAPID keys, a
  service worker `push` event handler, and a backend endpoint to manage
  push subscriptions — none of which is implemented. The Settings page
  toggles are real and persist, but they don't yet drive any actual
  reminder delivery mechanism beyond what a future "check reminders on
  load" client feature could add.
- **Rate limiting is in-memory, single-instance only.** Fine for one VPS;
  would need a shared store (Redis) the moment this runs on more than one
  backend instance.
- **Dark mode styling is not exhaustive.** The toggle and persistence work
  correctly and the app shell (sidebar/nav) is dark-mode aware, but
  individual page cards still use light-mode-only Tailwind classes
  (`bg-white`, etc.) — a full pass adding `dark:` variants across every
  page wasn't done in this session.
- **PWA icons are still placeholders** — see
  `frontend/public/icons/README.md`, unchanged since Phase 1.
- **`backup.sh` executable bit** may not survive the zip download —
  run `chmod +x backup.sh` after extracting if `./backup.sh` fails to run.

## Frontend completeness pass (post-Phase-9)

A few backend features from earlier phases didn't have frontend UI yet —
closed the gaps:
- **Quick Add** (natural-language food logging) is now live on the
  Nutrition page — parses text via the AI, shows matched items with an
  "estimated" badge where relevant, flags unmatched items instead of
  guessing, and only logs to the diary after you confirm.
- **Coach conversation history** — a "History" button on the Coach page
  lists past conversations and lets you reopen one instead of always
  starting fresh.
- **Analytics charts** — a calorie trend on the Nutrition page, and
  strength/volume charts per exercise on the Workout page, both backed by
  the Phase 7 analytics endpoints that had no UI before now.

## Deploying to a VPS

Primary, supported deployment path — one command on a fresh Ubuntu VPS:

```bash
git clone <REPO_URL> && cd fitness-coach && sudo bash deploy.sh
```

You do **not** need to hand-edit `docker-compose.prod.yml` or the Caddyfile
after this — the domain, secrets, and production flags are all wired
through `.env`, which `deploy.sh` creates/fills in for you.

### Prerequisites

- A fresh (or existing) Ubuntu 22.04/24.04 VPS, run as root or with sudo.
- A domain name you control.

### DNS setup

1. Point your domain's DNS `A`/`AAAA` record at the VPS's public IP.
   - If using Cloudflare: proxied (orange-cloud) is fine, with SSL/TLS mode
     set to **Full (strict)** — Caddy provisions a real cert on the origin,
     which is what "Full (strict)" requires.
2. Make sure it resolves *before* running `deploy.sh` — Caddy requests a
   Let's Encrypt certificate for the domain on first startup and that
   requires DNS to already be live.

### What `deploy.sh` does

1. Verifies it's running as root, on Ubuntu.
2. Installs Docker + the Compose plugin if not already present.
3. Creates `.env` from `.env.example` on first run. On every run, fills in
   `JWT_SECRET`, `FIELD_ENCRYPTION_KEY`, and `POSTGRES_PASSWORD`
   automatically **only if they're still unset or at their placeholder
   value** — an existing production secret is never touched or
   regenerated.
4. Prompts for your domain (or reads `DOMAIN` from `.env` if already set)
   and updates `FRONTEND_ORIGIN` / `NEXT_PUBLIC_API_BASE_URL` to match.
5. Validates all required environment variables and the Compose/Caddyfile
   configuration before starting anything.
6. Builds images, starts PostgreSQL, and waits for it to actually report
   ready (`pg_isready`) — not just "the container started."
7. Runs `alembic upgrade head` as a single one-off step (the `migrate`
   service in `docker-compose.prod.yml`) — not from every backend
   container's startup command, so it can never run concurrently or race.
8. Starts backend, frontend, and Caddy; waits for the backend's real
   readiness check (`/health/ready`, which verifies Postgres connectivity)
   and the frontend to respond before declaring success.
9. On any failure, prints the last 80 lines of logs from every service
   and exits non-zero. **No persistent volume (`pgdata`, `photo_storage`)
   is ever deleted, including on failure.**

### Firewall

Open only ports 80 and 443. PostgreSQL has no published port in
`docker-compose.prod.yml` — it's reachable only on the internal Docker
network.

### Updates / redeploying

```bash
git pull
sudo bash deploy.sh
```

Safe to run repeatedly: it rebuilds images with the new code, re-runs any
new migrations, and restarts services — without touching existing data or
already-set secrets.

### Logs

```bash
docker compose -f docker-compose.prod.yml logs -f            # all services
docker compose -f docker-compose.prod.yml logs -f backend    # one service
```

### Health checks

```bash
curl -s https://yourdomain.com/health/live    # process is up
curl -s https://yourdomain.com/health/ready   # process is up AND Postgres is reachable
```

### Backup

```bash
./backup.sh                    # run manually
crontab -e                     # or schedule it, e.g.:
# 0 3 * * * cd /path/to/fitness-coach && ./backup.sh >> /var/log/fitness-backup.log 2>&1
```

Writes a timestamped, checksum-verified database dump + progress-photos
archive to `./backups/`, plus a manifest tying the two together (so a
restore never mixes a DB snapshot with photos from a different point in
time). Optionally uploads encrypted copies to S3-compatible storage if
`BACKUP_S3_BUCKET` is set in `.env`. Keeps the last `BACKUP_RETENTION_DAYS`
(default 14) locally.

### Restore

```bash
./restore.sh --list            # see available backup timestamps
./restore.sh 20260914-030000   # restore database + photos from that backup
```

Verifies checksums against the manifest before touching anything, stops
the backend during the restore, and only restarts it once both the
database and photo volume are fully restored.

### Rollback

To roll back to a previous release after a bad deploy:

```bash
git checkout <previous-tag-or-commit>
sudo bash deploy.sh
```

If the bad release included a database migration you need to undo too:

```bash
docker compose -f docker-compose.prod.yml run --rm migrate alembic downgrade -1
```

Then check out the previous code and run `deploy.sh` as above. If in doubt
about data safety, restore from the most recent backup taken before the
bad deploy instead (see Restore above).

### Troubleshooting

- **A service won't start / deploy.sh failed** — the script prints the
  last 80 log lines from every service on failure. Re-run
  `docker compose -f docker-compose.prod.yml logs -f <service>` for more.
- **Caddy isn't getting a certificate** — check DNS has propagated
  (`dig yourdomain.com`) and that ports 80/443 are actually reachable from
  the internet (not blocked by a cloud provider security group in
  addition to the VPS's own firewall). `docker compose -f
  docker-compose.prod.yml logs caddy` shows ACME errors directly.
- **Backend reports not ready** — almost always Postgres connectivity;
  check `docker compose -f docker-compose.prod.yml logs postgres` and
  confirm `DATABASE_URL` in `.env` matches `POSTGRES_USER`/`PASSWORD`/`DB`.
- **Need to reset a forgotten `JWT_SECRET`/`FIELD_ENCRYPTION_KEY`** —
  delete that line from `.env` and re-run `deploy.sh`; it only
  auto-generates values that are missing or still at the placeholder, so
  this is the intended way to rotate one deliberately (note: rotating
  `JWT_SECRET` invalidates every existing session; rotating
  `FIELD_ENCRYPTION_KEY` makes previously-encrypted AI provider keys
  unreadable — re-add them via Settings afterward).

⚠️ **Known gap, called out honestly:** spec section 19 mentions the AI may
give general visual observations on progress photos. I did not implement
this — the provider abstraction built in Phase 5 only sends text to
providers, not images, and adding real vision support (provider-specific
multipart/base64 image APIs, safe prompting to avoid body-fat-percentage
claims, etc.) is a meaningfully sized feature on its own. Storage/security/
timeline (the parts of section 19 that matter most) are fully implemented;
AI photo analysis is not, rather than faking it with a canned response.

⚠️ **Known simplification:** question classification in
`context_builder.py` is keyword-based, not AI-based — deliberately, since
it's free, fast, deterministic, and auditable, but it can misclassify
phrasing it doesn't recognize (falls back to a general context in that
case rather than guessing narrower and missing data). The Home page's
Coach Insight card also starts a new conversation on every page load
rather than reusing a daily one — fine for now, worth tightening in a
later pass if conversation clutter becomes annoying.

⚠️ **Verify before real use:** `backend/app/ai/registry.py` has base
URLs/default models for each provider — these are reasonable-as-of-training
starting points, not live-verified. Check each provider's docs before
trusting the defaults, especially free-tier limits and model availability.

⚠️ **Testing note:** the environment this production-hardening pass was
written in has no network access and no Postgres/Docker available to
actually run the test suite, build the images, or boot the stack. Every
file was syntax-checked (`python -m py_compile`, `docker compose config`,
`bash -n`), and reviewed carefully, but **none of it has been executed
end-to-end**. Before trusting this in production: run `sudo bash deploy.sh`
on a real VPS, run the backend test suite (see below), and watch it fail
loudly if something's wrong rather than assuming it's correct because it
compiled.

See `docs/` (added as phases land) for what each phase actually implements.

## Run it locally

```bash
cp .env.example .env
# edit .env: set JWT_SECRET and FIELD_ENCRYPTION_KEY (commands are in the file's comments)

docker compose up --build -d postgres
docker compose run --rm migrate
docker compose up --build -d
```

- Frontend: http://localhost:3000
- Backend: http://localhost:8000/api/health
- Postgres: localhost:5432 (dev only — not exposed in production)

Migrations are a separate explicit step (`docker compose run --rm
migrate`), not run automatically by the backend container — see
`docker-compose.yml`'s `migrate` service. Re-run that command any time a
new migration is added.

## Run backend tests

Tests need a real Postgres database (UUID/ARRAY/Enum columns aren't
SQLite-compatible). With `docker compose up` already running:

```bash
docker compose exec postgres psql -U fitness -c "CREATE DATABASE fitness_coach_test;"
docker compose exec backend pytest
```

## Seed the Indian food starter database (Phase 2)

```bash
docker compose exec backend python -m app.db.seed_foods
```

Every seeded food is inserted with `is_verified=False` — the frontend shows
an "estimated" badge for these. Cross-check your most-logged staples
against IFCT/USDA before trusting the numbers for real tracking; see the
docstring in `backend/app/db/seed_foods.py` for details.

## Seed the exercise database (Phase 4)

```bash
docker compose exec backend python -m app.db.seed_exercises
```

## Project layout

```
backend/    FastAPI app, SQLAlchemy models, Alembic migrations, tests
frontend/   Next.js PWA
infra/      reverse proxy + postgres init (filled in during Phase 9)
```

## Generating secrets

```bash
# JWT_SECRET
python -c "import secrets; print(secrets.token_urlsafe(48))"

# FIELD_ENCRYPTION_KEY (used from Phase 5 onward to encrypt AI provider API keys)
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

## Notes

- Progress photos, once added (Phase 8), are never served from a public
  path — always through an authenticated backend endpoint.
- AI providers are entirely optional; every core feature (logging food,
  workouts, weight, water) works with zero providers configured.
- Don't commit `.env`. `.env.example` documents every variable with no real
  values.
