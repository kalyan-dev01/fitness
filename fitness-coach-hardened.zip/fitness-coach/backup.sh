#!/usr/bin/env bash
# Timestamped backup of the PostgreSQL database and progress-photo storage
# volume. Intended to be run via cron on the VPS, e.g.:
#   0 3 * * * /path/to/fitness-coach/backup.sh >> /var/log/fitness-backup.log 2>&1
#
# Restore with ./restore.sh -- see that script for usage and for why
# restore order matters (database and photos must be restored from the
# SAME backup run, not mixed-and-matched from different timestamps).

set -Eeuo pipefail

BACKUP_DIR="${BACKUP_DIR:-./backups}"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
COMPOSE_FILE="${COMPOSE_FILE:-docker-compose.prod.yml}"
RETENTION_DAYS="${BACKUP_RETENTION_DAYS:-14}"
MIN_FREE_BYTES=$((500 * 1024 * 1024))  # refuse to start with < 500MB free

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"; }
fail() { log "ERROR: $*"; exit 1; }

trap 'log "Backup FAILED (see error above). Partial files in $BACKUP_DIR/*-'"$TIMESTAMP"'* were left in place for inspection, not treated as valid backups."' ERR

# --- Load env for POSTGRES_* / BACKUP_S3_* vars if not already exported ---
if [ -f .env ]; then
  set -a
  # shellcheck disable=SC1091
  source .env
  set +a
fi

mkdir -p "$BACKUP_DIR"

# --- Disk space check -----------------------------------------------------
avail_bytes=$(df --output=avail -B1 "$BACKUP_DIR" | tail -n1 | tr -d ' ')
if [ "$avail_bytes" -lt "$MIN_FREE_BYTES" ]; then
  fail "Only $((avail_bytes / 1024 / 1024))MB free at $BACKUP_DIR (need at least $((MIN_FREE_BYTES / 1024 / 1024))MB). Aborting before writing a truncated backup."
fi

log "Starting backup..."

# --- Discover the real runtime volume name for progress photos -----------
# Never assume "$(basename $(pwd))_photo_storage" -- Compose's actual
# naming depends on COMPOSE_PROJECT_NAME / the `name:` field / historical
# project renames, and guessing wrong means silently backing up nothing
# (or someone else's volume). Instead, ask Docker directly: find the
# volume Compose tagged with label com.docker.compose.volume=photo_storage
# AND whose working-dir label matches this checkout.
find_compose_volume() {
  local logical_name="$1"
  local vol wd
  for vol in $(docker volume ls --filter "label=com.docker.compose.volume=${logical_name}" --format '{{.Name}}'); do
    wd=$(docker volume inspect "$vol" --format '{{ index .Labels "com.docker.compose.project.working_dir" }}' 2>/dev/null || true)
    if [ "$wd" = "$(pwd)" ]; then
      echo "$vol"
      return 0
    fi
  done
  return 1
}

PHOTO_VOLUME="$(find_compose_volume photo_storage)" \
  || fail "Could not find the photo_storage Docker volume for this project. Is the stack deployed ($COMPOSE_FILE)?"

# --- Database (dumped first: see restore.sh for why order matters) -------
DB_BACKUP_PATH="$BACKUP_DIR/db-$TIMESTAMP.sql.gz"
docker compose -f "$COMPOSE_FILE" exec -T postgres \
  pg_dump -U "${POSTGRES_USER:-fitness}" "${POSTGRES_DB:-fitness_coach}" \
  | gzip > "$DB_BACKUP_PATH"
gzip -t "$DB_BACKUP_PATH" || fail "Database backup at $DB_BACKUP_PATH is corrupt (gzip integrity check failed)"
[ -s "$DB_BACKUP_PATH" ] || fail "Database backup at $DB_BACKUP_PATH is empty"
log "Database backup written and verified: $DB_BACKUP_PATH ($(du -h "$DB_BACKUP_PATH" | cut -f1))"

# --- Progress photos --------------------------------------------------------
PHOTOS_BACKUP_PATH="$BACKUP_DIR/photos-$TIMESTAMP.tar.gz"
docker run --rm \
  -v "${PHOTO_VOLUME}:/data:ro" \
  -v "$(cd "$BACKUP_DIR" && pwd):/backup" \
  alpine tar czf "/backup/photos-$TIMESTAMP.tar.gz" -C /data .
tar tzf "$PHOTOS_BACKUP_PATH" > /dev/null || fail "Photo backup at $PHOTOS_BACKUP_PATH is corrupt (tar integrity check failed)"
log "Photo storage backup written and verified: $PHOTOS_BACKUP_PATH ($(du -h "$PHOTOS_BACKUP_PATH" | cut -f1))"

# --- Manifest: ties the two files together as one atomic backup set ------
MANIFEST_PATH="$BACKUP_DIR/manifest-$TIMESTAMP.txt"
{
  echo "timestamp=$TIMESTAMP"
  echo "db_file=$(basename "$DB_BACKUP_PATH")"
  echo "db_sha256=$(sha256sum "$DB_BACKUP_PATH" | cut -d' ' -f1)"
  echo "photos_file=$(basename "$PHOTOS_BACKUP_PATH")"
  echo "photos_sha256=$(sha256sum "$PHOTOS_BACKUP_PATH" | cut -d' ' -f1)"
} > "$MANIFEST_PATH"
log "Manifest written: $MANIFEST_PATH"

# --- Optional: upload encrypted copies to S3-compatible storage ----------
if [ -n "${BACKUP_S3_BUCKET:-}" ]; then
  if ! command -v aws >/dev/null 2>&1; then
    log "WARNING: BACKUP_S3_BUCKET is set but the 'aws' CLI is not installed -- skipping remote upload. Install awscli to enable this."
  elif [ -z "${BACKUP_S3_ACCESS_KEY_ID:-}" ] || [ -z "${BACKUP_S3_SECRET_ACCESS_KEY:-}" ]; then
    log "WARNING: BACKUP_S3_BUCKET is set but credentials are missing -- skipping remote upload."
  else
    export AWS_ACCESS_KEY_ID="$BACKUP_S3_ACCESS_KEY_ID"
    export AWS_SECRET_ACCESS_KEY="$BACKUP_S3_SECRET_ACCESS_KEY"
    ENDPOINT_ARGS=()
    [ -n "${BACKUP_S3_ENDPOINT:-}" ] && ENDPOINT_ARGS=(--endpoint-url "$BACKUP_S3_ENDPOINT")
    for f in "$DB_BACKUP_PATH" "$PHOTOS_BACKUP_PATH" "$MANIFEST_PATH"; do
      # Server-side encryption at rest; the bucket/endpoint should also be
      # configured for encryption-in-transit (HTTPS endpoint) and, ideally,
      # a bucket-level default encryption policy.
      aws s3 cp "$f" "s3://${BACKUP_S3_BUCKET}/$(basename "$f")" \
        --sse AES256 "${ENDPOINT_ARGS[@]}" \
        || log "WARNING: upload of $(basename "$f") to S3 failed -- local copy is still intact."
    done
    log "Remote upload to s3://${BACKUP_S3_BUCKET}/ attempted."
  fi
fi

# --- Retention: keep the last N days, delete anything older ---------------
find "$BACKUP_DIR" -maxdepth 1 -name "db-*.sql.gz" -mtime "+${RETENTION_DAYS}" -delete
find "$BACKUP_DIR" -maxdepth 1 -name "photos-*.tar.gz" -mtime "+${RETENTION_DAYS}" -delete
find "$BACKUP_DIR" -maxdepth 1 -name "manifest-*.txt" -mtime "+${RETENTION_DAYS}" -delete

log "Backup complete."
