import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: "#32d74b", // iOS systemGreen (dark)
          dark: "#28a745",
          light: "#64e881",
        },
        // Layered dark surfaces — never pure black, each level a touch
        // lighter so cards read as "elevated" against the page like
        // iOS/macOS grouped-table surfaces.
        surface: {
          0: "#0b0c0f", // page background
          1: "#141519", // base card
          2: "#1c1e24", // raised card / modal
          3: "#25272f", // nav chrome, popovers
          border: "#2c2e37",
        },
        ink: {
          DEFAULT: "#f2f3f5", // primary text on dark
          muted: "#9a9ba3", // secondary text
          faint: "#66676f", // tertiary/placeholder
        },
        danger: {
          DEFAULT: "#ff453a",
          muted: "#3a1f1e",
        },
        warning: {
          DEFAULT: "#ffd60a",
          muted: "#3a331a",
        },
      },
      fontFamily: {
        sans: [
          "-apple-system",
          "BlinkMacSystemFont",
          '"SF Pro Text"',
          '"SF Pro Display"',
          "Inter",
          "system-ui",
          '"Segoe UI"',
          "Roboto",
          "Helvetica",
          "Arial",
          "sans-serif",
        ],
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      boxShadow: {
        soft: "0 1px 2px rgba(0,0,0,0.3), 0 8px 24px -12px rgba(0,0,0,0.5)",
        "soft-lg": "0 4px 12px rgba(0,0,0,0.35), 0 24px 48px -24px rgba(0,0,0,0.6)",
        glow: "0 0 0 1px rgba(50,215,75,0.35), 0 0 24px -4px rgba(50,215,75,0.45)",
      },
      backdropBlur: {
        xs: "2px",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(6px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "pop": {
          "0%": { transform: "scale(0.94)", opacity: "0" },
          "100%": { transform: "scale(1)", opacity: "1" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.35s cubic-bezier(0.16,1,0.3,1) both",
        pop: "pop 0.25s cubic-bezier(0.16,1,0.3,1) both",
      },
    },
  },
  plugins: [],
};

export default config;
