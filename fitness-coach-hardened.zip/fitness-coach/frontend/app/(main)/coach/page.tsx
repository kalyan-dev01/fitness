"use client";

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { api, AIConversationOut, AIMessageOut } from "@/lib/api-client";
import { useToast } from "@/components/ui/Toast";
import { PageShell, Spinner } from "@/components/ui/PageShell";

const QUICK_ACTIONS = [
  "Can I eat this?",
  "What should I eat tonight?",
  "Analyze my day",
  "Should I train today?",
  "Why am I not losing weight?",
  "Am I getting stronger?",
];

type LocalMessage = AIMessageOut & { failed?: boolean };

export default function CoachPage() {
  const { showError } = useToast();
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<LocalMessage[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [unavailable, setUnavailable] = useState(false);
  const [history, setHistory] = useState<AIConversationOut[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  async function loadHistory() {
    try {
      setHistory(await api.coach.listConversations());
    } catch (err) {
      showError(err, "Couldn't load past conversations.");
    }
  }

  function openConversation(conversation: AIConversationOut) {
    setConversationId(conversation.id);
    setMessages(conversation.messages);
    setShowHistory(false);
  }

  function startNewConversation() {
    setConversationId(null);
    setMessages([]);
    setUnavailable(false);
    setShowHistory(false);
  }

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function send(text: string) {
    if (!text.trim() || sending) return;
    setSending(true);
    setUnavailable(false);
    setInput("");

    const localId = `local-${Date.now()}`;
    setMessages((prev) => [
      ...prev,
      {
        id: localId,
        role: "USER",
        content: text,
        provider_name: null,
        model: null,
        created_at: new Date().toISOString(),
      },
    ]);

    try {
      const result = await api.coach.send(text, conversationId ?? undefined);
      setConversationId(result.conversation_id);
      if (result.ai_unavailable) {
        setUnavailable(true);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            id: `local-reply-${Date.now()}`,
            role: "ASSISTANT",
            content: result.reply,
            provider_name: result.provider_name,
            model: result.model,
            created_at: new Date().toISOString(),
          },
        ]);
      }
      loadHistory();
    } catch (err) {
      // Mark the optimistic message as failed instead of leaving it
      // hanging with no reply and no explanation.
      setMessages((prev) =>
        prev.map((m) => (m.id === localId ? { ...m, failed: true } : m))
      );
      showError(err, "Couldn't send that message.");
    } finally {
      setSending(false);
    }
  }

  return (
    <PageShell>
      <div className="flex h-[calc(100vh-9.5rem)] flex-col md:h-[calc(100vh-5.5rem)]">
        <div className="mb-3 flex items-center justify-between">
          <h1 className="text-[22px] font-semibold tracking-tight text-ink">🧠 Your Coach</h1>
          <div className="flex gap-2">
            <button onClick={startNewConversation} className="btn-pill">
              New
            </button>
            <button
              onClick={() => {
                setShowHistory((v) => !v);
                if (!showHistory) loadHistory();
              }}
              className="btn-pill"
            >
              History
            </button>
          </div>
        </div>

        <AnimatePresence>
          {showHistory && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-3 max-h-40 overflow-hidden overflow-y-auto rounded-xl2 border border-white/5 bg-surface-1"
            >
              {history.length === 0 && (
                <p className="px-3 py-3 text-center text-[12px] text-ink-faint">
                  No past conversations yet.
                </p>
              )}
              {history.map((c) => (
                <button
                  key={c.id}
                  onClick={() => openConversation(c)}
                  className="block w-full border-b border-white/5 px-3 py-2 text-left text-[12px] text-ink-muted last:border-0 hover:bg-white/5"
                >
                  {c.messages[0]?.content.slice(0, 60) || "Conversation"}
                  {c.messages[0]?.content && c.messages[0].content.length > 60 ? "…" : ""}
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {messages.length === 0 && (
          <div className="mb-4 flex flex-wrap gap-2">
            {QUICK_ACTIONS.map((action) => (
              <button key={action} onClick={() => send(action)} className="btn-pill">
                {action}
              </button>
            ))}
          </div>
        )}

        <div className="flex-1 space-y-3 overflow-y-auto rounded-xl2 border border-white/5 bg-surface-1 p-4">
          {messages.map((m) => (
            <motion.div
              key={m.id}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${m.role === "USER" ? "justify-end" : "justify-start"}`}
            >
              <div className="max-w-[80%]">
                <div
                  className={`rounded-2xl px-4 py-2 text-[14px] leading-relaxed ${
                    m.role === "USER"
                      ? m.failed
                        ? "bg-danger/20 text-red-200"
                        : "bg-brand text-black"
                      : "bg-surface-2 text-ink"
                  }`}
                >
                  {m.content}
                </div>
                {m.failed && (
                  <div className="mt-1 text-right text-[11px] text-danger">
                    Failed to send · tap New to retry
                  </div>
                )}
              </div>
            </motion.div>
          ))}
          {sending && (
            <div className="flex justify-start">
              <div className="flex items-center gap-2 rounded-2xl bg-surface-2 px-4 py-2 text-[13px] text-ink-faint">
                <Spinner className="h-3.5 w-3.5" /> Thinking…
              </div>
            </div>
          )}
          {unavailable && (
            <div className="rounded-xl bg-warning-muted px-3.5 py-2.5 text-center text-[12px] text-yellow-300">
              AI Coach is temporarily unavailable. Please try again shortly.
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
          className="mt-3 flex gap-2"
        >
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a message…"
            className="input-field flex-1 rounded-full"
          />
          <button
            type="submit"
            disabled={sending}
            className="btn-primary rounded-full px-5 disabled:opacity-60"
          >
            ➤
          </button>
        </form>
      </div>
    </PageShell>
  );
}
