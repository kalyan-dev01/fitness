"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { api, ApiError, UserOut } from "@/lib/api-client";
import { useToast } from "@/components/ui/Toast";
import { Spinner } from "@/components/ui/PageShell";

const NAV_ITEMS = [
  { href: "/home", label: "Today", icon: "🏠" },
  { href: "/nutrition", label: "Nutrition", icon: "🍽️" },
  { href: "/workout", label: "Workout", icon: "🏋️" },
  { href: "/progress", label: "Progress", icon: "📈" },
  { href: "/coach", label: "Coach", icon: "🧠" },
];

const SECONDARY_ITEMS = [
  { href: "/ai-providers", label: "AI Providers", icon: "🔌" },
  { href: "/settings", label: "Settings", icon: "⚙️" },
];

export default function MainLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const { showError } = useToast();
  const [user, setUser] = useState<UserOut | null>(null);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    api.auth
      .me()
      .then(setUser)
      .catch((err) => {
        if (err instanceof ApiError && err.status === 401) {
          router.replace("/login");
        } else {
          showError(err, "Couldn't verify your session. Please refresh.");
        }
      })
      .finally(() => setChecking(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [router]);

  async function handleLogout() {
    try {
      await api.auth.logout();
      router.replace("/login");
    } catch (err) {
      showError(err, "Couldn't log out — please try again.");
    }
  }

  if (checking) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-surface-0">
        <Spinner className="h-6 w-6 text-ink-faint" />
      </div>
    );
  }

  if (!user) return null; // redirect already in flight

  return (
    <div className="min-h-screen bg-surface-0 pb-[calc(4.5rem+env(safe-area-inset-bottom))] md:pb-0 md:pl-64">
      {/* Desktop sidebar */}
      <aside className="glass fixed inset-y-0 left-0 hidden w-64 flex-col border-r border-white/5 p-4 md:flex">
        <div className="mb-8 flex items-center gap-2 px-2 pt-2">
          <span className="text-xl">🏋️</span>
          <span className="text-[15px] font-semibold tracking-tight text-ink">
            Fitness Coach
          </span>
        </div>
        <nav className="flex-1 space-y-0.5">
          {NAV_ITEMS.map((item) => (
            <SidebarLink key={item.href} item={item} active={pathname?.startsWith(item.href)} />
          ))}
          <div className="my-3 h-px bg-white/5" />
          {SECONDARY_ITEMS.map((item) => (
            <SidebarLink key={item.href} item={item} active={pathname?.startsWith(item.href)} />
          ))}
        </nav>
        <button
          onClick={handleLogout}
          className="mt-4 rounded-xl px-3 py-2.5 text-left text-[13px] font-medium text-ink-faint transition hover:bg-white/5 hover:text-ink-muted"
        >
          Log out
        </button>
      </aside>

      <main className="mx-auto max-w-3xl px-4 pb-10 pt-[calc(1.25rem+env(safe-area-inset-top))] md:px-8 md:pt-10">
        {children}
      </main>

      {/* Mobile bottom tab bar */}
      <nav className="glass fixed inset-x-0 bottom-0 flex border-t border-white/5 pb-[env(safe-area-inset-bottom)] md:hidden">
        {NAV_ITEMS.map((item) => {
          const active = pathname?.startsWith(item.href);
          return (
            <Link
              key={item.href}
              href={item.href}
              className="relative flex flex-1 flex-col items-center gap-0.5 py-2.5 text-center"
            >
              {active && (
                <motion.div
                  layoutId="tab-active"
                  className="absolute inset-x-3 top-0 h-0.5 rounded-full bg-brand"
                  transition={{ type: "spring", stiffness: 500, damping: 36 }}
                />
              )}
              <span className={`text-[17px] transition ${active ? "" : "opacity-50"}`}>
                {item.icon}
              </span>
              <span
                className={`text-[10px] font-medium transition ${
                  active ? "text-brand" : "text-ink-faint"
                }`}
              >
                {item.label}
              </span>
            </Link>
          );
        })}
      </nav>
    </div>
  );
}

function SidebarLink({
  item,
  active,
}: {
  item: { href: string; label: string; icon: string };
  active?: boolean;
}) {
  return (
    <Link href={item.href} className="relative block">
      {active && (
        <motion.div
          layoutId="sidebar-active"
          className="absolute inset-0 rounded-xl bg-brand/15"
          transition={{ type: "spring", stiffness: 500, damping: 38 }}
        />
      )}
      <span
        className={`relative flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-[14px] font-medium transition ${
          active ? "text-brand" : "text-ink-muted hover:text-ink"
        }`}
      >
        <span className="text-[15px]">{item.icon}</span>
        {item.label}
      </span>
    </Link>
  );
}
