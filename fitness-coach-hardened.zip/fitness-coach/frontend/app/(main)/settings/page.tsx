"use client";

import { useEffect, useState } from "react";
import { api, NotificationSettingsOut, ProfileOut } from "@/lib/api-client";
import { useToast } from "@/components/ui/Toast";
import { Card, PageHeader, PageShell, Spinner } from "@/components/ui/PageShell";

const ACTIVITY_LEVELS = ["SEDENTARY", "LIGHT", "MODERATE", "ACTIVE", "VERY_ACTIVE"] as const;

export default function SettingsPage() {
  const { showError, showSuccess } = useToast();
  const [profile, setProfile] = useState<ProfileOut | null>(null);
  const [saving, setSaving] = useState(false);

  const [notifSettings, setNotifSettings] = useState<NotificationSettingsOut | null>(null);
  const [isDark, setIsDark] = useState(true);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    api.profile
      .get()
      .then(setProfile)
      .catch((err) => showError(err, "Couldn't load your profile."));
    api.notificationSettings
      .get()
      .then(setNotifSettings)
      .catch((err) => showError(err, "Couldn't load notification settings."));
    setIsDark(document.documentElement.classList.contains("dark"));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function toggleTheme() {
    const next = !isDark;
    setIsDark(next);
    document.documentElement.classList.toggle("dark", next);
    localStorage.setItem("theme", next ? "dark" : "light");
  }

  async function toggleNotification(key: keyof NotificationSettingsOut) {
    if (!notifSettings) return;
    const previous = notifSettings;
    // Optimistic toggle for snappy feel, rolled back on failure.
    setNotifSettings({ ...notifSettings, [key]: !notifSettings[key] });
    try {
      const updated = await api.notificationSettings.update({
        [key]: !previous[key],
      });
      setNotifSettings(updated);
    } catch (err) {
      setNotifSettings(previous);
      showError(err, "Couldn't update that notification setting.");
    }
  }

  async function downloadExport() {
    setExporting(true);
    try {
      const res = await fetch(api.export.downloadUrl(), { credentials: "include" });
      if (!res.ok) throw new Error(`Export failed (${res.status})`);
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `fitness-coach-export-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      showError(err, "Couldn't export your data.");
    } finally {
      setExporting(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!profile) return;
    setSaving(true);
    try {
      const updated = await api.profile.update({
        name: profile.name,
        age: profile.age,
        sex: profile.sex,
        height_cm: profile.height_cm,
        activity_level: profile.activity_level,
        training_frequency: profile.training_frequency,
      });
      setProfile(updated);
      showSuccess("Profile saved.");
    } catch (err) {
      showError(err, "Couldn't save your profile.");
    } finally {
      setSaving(false);
    }
  }

  if (!profile) {
    return (
      <PageShell>
        <div className="flex justify-center py-20">
          <Spinner className="h-5 w-5 text-ink-faint" />
        </div>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <PageHeader title="Settings" />

      <Card as="form" className="mb-5 space-y-4">
        <h2 className="text-[13px] font-semibold text-ink">Profile</h2>
        <div>
          <label className="label-xs">Name</label>
          <input
            value={profile.name ?? ""}
            onChange={(e) => setProfile({ ...profile, name: e.target.value })}
            className="input-field"
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label-xs">Age</label>
            <input
              type="number"
              value={profile.age ?? ""}
              onChange={(e) =>
                setProfile({ ...profile, age: e.target.value ? Number(e.target.value) : null })
              }
              className="input-field"
            />
          </div>
          <div>
            <label className="label-xs">Sex</label>
            <select
              value={profile.sex ?? ""}
              onChange={(e) =>
                setProfile({ ...profile, sex: (e.target.value || null) as ProfileOut["sex"] })
              }
              className="input-field"
            >
              <option value="">—</option>
              <option value="MALE">Male</option>
              <option value="FEMALE">Female</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="label-xs">Height (cm)</label>
            <input
              type="number"
              step="0.1"
              value={profile.height_cm ?? ""}
              onChange={(e) =>
                setProfile({
                  ...profile,
                  height_cm: e.target.value ? Number(e.target.value) : null,
                })
              }
              className="input-field"
            />
          </div>
          <div>
            <label className="label-xs">Training days/week</label>
            <input
              type="number"
              min={0}
              max={14}
              value={profile.training_frequency ?? ""}
              onChange={(e) =>
                setProfile({
                  ...profile,
                  training_frequency: e.target.value ? Number(e.target.value) : null,
                })
              }
              className="input-field"
            />
          </div>
        </div>

        <div>
          <label className="label-xs">Activity level</label>
          <select
            value={profile.activity_level ?? ""}
            onChange={(e) => setProfile({ ...profile, activity_level: e.target.value || null })}
            className="input-field"
          >
            <option value="">—</option>
            {ACTIVITY_LEVELS.map((level) => (
              <option key={level} value={level}>
                {level.replace("_", " ").toLowerCase()}
              </option>
            ))}
          </select>
        </div>

        <button onClick={handleSubmit} disabled={saving} className="btn-primary w-full">
          {saving ? "Saving…" : "Save profile"}
        </button>
      </Card>

      <Card className="mb-5">
        <h2 className="mb-3 text-[13px] font-semibold text-ink">Appearance</h2>
        <button onClick={toggleTheme} className="btn-secondary">
          {isDark ? "Switch to light mode" : "Switch to dark mode"}
        </button>
      </Card>

      {notifSettings && (
        <Card className="mb-5">
          <h2 className="mb-1 text-[13px] font-semibold text-ink">Notifications</h2>
          <p className="mb-3 text-[12px] text-ink-faint">
            These show as reminder banners while the app is open. They don't yet work as
            background push notifications when the app is closed.
          </p>
          <div className="space-y-2.5">
            {(
              [
                ["remind_log_weight", "Log weight"],
                ["remind_drink_water", "Drink water"],
                ["remind_workout", "Workout"],
                ["remind_log_meals", "Log meals"],
                ["remind_weekly_report", "Weekly report"],
              ] as const
            ).map(([key, label]) => (
              <label key={key} className="flex items-center justify-between text-[13px] text-ink">
                {label}
                <input
                  type="checkbox"
                  checked={notifSettings[key]}
                  onChange={() => toggleNotification(key)}
                  className="h-4 w-4 accent-brand"
                />
              </label>
            ))}
          </div>
        </Card>
      )}

      <Card>
        <h2 className="mb-2 text-[13px] font-semibold text-ink">Data export</h2>
        <p className="mb-3 text-[12px] text-ink-faint">
          Download your nutrition, weight, workout, and AI conversation history as a JSON file.
        </p>
        <button onClick={downloadExport} disabled={exporting} className="btn-secondary">
          {exporting ? "Exporting…" : "Export my data"}
        </button>
      </Card>
    </PageShell>
  );
}
