"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { api, AIProviderOut, ApiError } from "@/lib/api-client";
import { useToast } from "@/components/ui/Toast";
import { Card, EmptyState, PageHeader, PageShell, Spinner } from "@/components/ui/PageShell";

const KNOWN_PROVIDERS = [
  { value: "gemini", label: "Google Gemini" },
  { value: "groq", label: "Groq" },
  { value: "openrouter", label: "OpenRouter" },
  { value: "mistral", label: "Mistral" },
  { value: "ollama", label: "Ollama (local)" },
  { value: "anthropic", label: "Anthropic (paid — manual only)" },
];

const STATUS_STYLES: Record<string, string> = {
  HEALTHY: "bg-brand/15 text-brand",
  DEGRADED: "bg-warning-muted text-yellow-300",
  DOWN: "bg-danger/15 text-red-300",
  UNKNOWN: "bg-white/5 text-ink-faint",
};

export default function AIProvidersPage() {
  const { showError, showSuccess } = useToast();
  const [providers, setProviders] = useState<AIProviderOut[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);

  // Add-provider form state
  const [newName, setNewName] = useState(KNOWN_PROVIDERS[0].value);
  const [newApiKey, setNewApiKey] = useState("");
  const [newModel, setNewModel] = useState("");
  const [newBaseUrl, setNewBaseUrl] = useState("");
  const [creating, setCreating] = useState(false);

  // Per-row transient state
  const [testingId, setTestingId] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editModel, setEditModel] = useState("");
  const [editBaseUrl, setEditBaseUrl] = useState("");

  async function load() {
    try {
      setProviders(await api.aiProviders.list());
    } catch (err) {
      showError(err, "Couldn't load your AI providers.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const alreadyConfigured = new Set(providers.map((p) => p.name));
  const addableProviders = KNOWN_PROVIDERS.filter((p) => !alreadyConfigured.has(p.value));

  // The "default" provider is whichever enabled provider has the lowest
  // priority number — this is the one actually used first in the
  // fallback chain, so it's the one the UI should visibly call out.
  const defaultId = providers
    .filter((p) => p.is_enabled)
    .sort((a, b) => a.priority - b.priority)[0]?.id;

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    if (!newApiKey.trim()) return;
    setCreating(true);
    try {
      await api.aiProviders.create({
        name: newName,
        api_key: newApiKey,
        model: newModel || undefined,
        base_url: newBaseUrl || undefined,
      });
      setNewApiKey("");
      setNewModel("");
      setNewBaseUrl("");
      setShowAdd(false);
      await load();
      showSuccess("Provider added.");
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        showError(err, err.detail);
      } else {
        showError(err, "Couldn't add that provider.");
      }
    } finally {
      setCreating(false);
    }
  }

  async function handleDelete(id: string) {
    setBusyId(id);
    try {
      await api.aiProviders.delete(id);
      setProviders((prev) => prev.filter((p) => p.id !== id));
      showSuccess("Provider removed.");
    } catch (err) {
      showError(err, "Couldn't delete that provider.");
    } finally {
      setBusyId(null);
    }
  }

  async function handleTest(id: string) {
    setTestingId(id);
    try {
      const result = await api.aiProviders.test(id);
      if (result.success) {
        showSuccess(`Connected — ${result.model ?? "OK"} (${result.latency_ms}ms)`);
      } else {
        showError(null, result.error_message ?? "Connection test failed.");
      }
      await load(); // refresh health block regardless of outcome
    } catch (err) {
      showError(err, "Couldn't run the connection test.");
    } finally {
      setTestingId(null);
    }
  }

  async function toggleEnabled(provider: AIProviderOut) {
    setBusyId(provider.id);
    try {
      const updated = await api.aiProviders.update(provider.id, {
        is_enabled: !provider.is_enabled,
      });
      setProviders((prev) => prev.map((p) => (p.id === provider.id ? updated : p)));
    } catch (err) {
      showError(err, "Couldn't update that provider.");
    } finally {
      setBusyId(null);
    }
  }

  async function toggleAutoFallback(provider: AIProviderOut) {
    setBusyId(provider.id);
    try {
      const updated = await api.aiProviders.update(provider.id, {
        auto_fallback_enabled: !provider.auto_fallback_enabled,
      });
      setProviders((prev) => prev.map((p) => (p.id === provider.id ? updated : p)));
    } catch (err) {
      showError(err, "Couldn't update automatic fallback.");
    } finally {
      setBusyId(null);
    }
  }

  async function makeDefault(provider: AIProviderOut) {
    setBusyId(provider.id);
    try {
      const lowest = Math.min(0, ...providers.map((p) => p.priority));
      const updated = await api.aiProviders.update(provider.id, {
        priority: lowest - 1,
        is_enabled: true,
      });
      setProviders((prev) => prev.map((p) => (p.id === provider.id ? updated : p)));
      showSuccess(`${provider.display_name} is now the default provider.`);
    } catch (err) {
      showError(err, "Couldn't set that provider as default.");
    } finally {
      setBusyId(null);
    }
  }

  function startEdit(provider: AIProviderOut) {
    setEditingId(provider.id);
    setEditModel(provider.model ?? "");
    setEditBaseUrl(provider.base_url ?? "");
  }

  async function saveEdit(provider: AIProviderOut) {
    setBusyId(provider.id);
    try {
      const updated = await api.aiProviders.update(provider.id, {
        model: editModel || null,
        base_url: editBaseUrl || null,
      });
      setProviders((prev) => prev.map((p) => (p.id === provider.id ? updated : p)));
      setEditingId(null);
      showSuccess("Provider configuration updated.");
    } catch (err) {
      showError(err, "Couldn't save that configuration.");
    } finally {
      setBusyId(null);
    }
  }

  const sortedProviders = [...providers].sort((a, b) => a.priority - b.priority);

  return (
    <PageShell>
      <PageHeader
        title="AI Providers"
        subtitle="Configure model, endpoint, and fallback order — no server access needed"
        action={
          addableProviders.length > 0 && (
            <button onClick={() => setShowAdd((v) => !v)} className="btn-primary px-3.5 py-2 text-[13px]">
              {showAdd ? "Cancel" : "+ Add"}
            </button>
          )
        }
      />

      <AnimatePresence>
        {showAdd && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mb-5 overflow-hidden"
          >
            <Card as="form" className="space-y-3">
              <div>
                <label className="label-xs">Provider</label>
                <select
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="input-field"
                >
                  {addableProviders.map((p) => (
                    <option key={p.value} value={p.value}>
                      {p.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="label-xs">API key</label>
                <input
                  type="password"
                  value={newApiKey}
                  onChange={(e) => setNewApiKey(e.target.value)}
                  required
                  className="input-field"
                  autoComplete="off"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label-xs">Model override (optional)</label>
                  <input
                    value={newModel}
                    onChange={(e) => setNewModel(e.target.value)}
                    placeholder="uses provider default"
                    className="input-field"
                  />
                </div>
                <div>
                  <label className="label-xs">Base URL override (optional)</label>
                  <input
                    value={newBaseUrl}
                    onChange={(e) => setNewBaseUrl(e.target.value)}
                    placeholder="for self-hosted / proxy"
                    className="input-field"
                  />
                </div>
              </div>
              <button onClick={handleCreate} disabled={creating} className="btn-primary w-full">
                {creating ? "Adding…" : "Add provider"}
              </button>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {loading ? (
        <div className="flex justify-center py-16">
          <Spinner className="h-5 w-5 text-ink-faint" />
        </div>
      ) : sortedProviders.length === 0 ? (
        <Card>
          <EmptyState>
            No AI providers configured yet — add one above to enable the Coach, Quick Add
            parsing, and AI reports.
          </EmptyState>
        </Card>
      ) : (
        <div className="space-y-3">
          <p className="text-[12px] text-ink-faint">
            Lowest-numbered enabled provider is tried first; if it fails, providers with automatic
            fallback enabled are tried next.
          </p>
          {sortedProviders.map((provider) => {
            const isDefault = provider.id === defaultId;
            const isEditing = editingId === provider.id;
            const isBusy = busyId === provider.id;
            return (
              <Card key={provider.id} className={!provider.is_enabled ? "opacity-60" : ""}>
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[14px] font-semibold text-ink">
                        {provider.display_name}
                      </span>
                      {isDefault && (
                        <span className="rounded-full bg-brand/15 px-2 py-0.5 text-[10px] font-semibold text-brand">
                          DEFAULT
                        </span>
                      )}
                      {provider.health && (
                        <span
                          className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${
                            STATUS_STYLES[provider.health.status] ?? STATUS_STYLES.UNKNOWN
                          }`}
                        >
                          {provider.health.status}
                        </span>
                      )}
                      {!provider.is_free_only && (
                        <span className="rounded-full bg-warning-muted px-2 py-0.5 text-[10px] font-medium text-yellow-300">
                          PAID
                        </span>
                      )}
                    </div>
                    <div className="mt-1 text-[12px] text-ink-faint">
                      {provider.model ?? "default model"} · priority {provider.priority}
                      {provider.key_hint && ` · key ${provider.key_hint}`}
                    </div>
                    {provider.base_url && (
                      <div className="mt-0.5 truncate text-[11px] text-ink-faint">
                        {provider.base_url}
                      </div>
                    )}
                  </div>

                  <label className="relative inline-flex shrink-0 cursor-pointer items-center">
                    <input
                      type="checkbox"
                      checked={provider.is_enabled}
                      onChange={() => toggleEnabled(provider)}
                      disabled={isBusy}
                      className="peer sr-only"
                    />
                    <div className="h-6 w-11 rounded-full bg-white/10 transition peer-checked:bg-brand peer-disabled:opacity-50" />
                    <div className="absolute left-1 h-4 w-4 rounded-full bg-white transition peer-checked:translate-x-5" />
                  </label>
                </div>

                <AnimatePresence>
                  {isEditing && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-3 space-y-2 overflow-hidden border-t border-white/5 pt-3"
                    >
                      <div>
                        <label className="label-xs">Model</label>
                        <input
                          value={editModel}
                          onChange={(e) => setEditModel(e.target.value)}
                          placeholder="uses provider default"
                          className="input-field py-1.5"
                        />
                      </div>
                      <div>
                        <label className="label-xs">Base URL</label>
                        <input
                          value={editBaseUrl}
                          onChange={(e) => setEditBaseUrl(e.target.value)}
                          placeholder="uses provider default"
                          className="input-field py-1.5"
                        />
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => saveEdit(provider)}
                          disabled={isBusy}
                          className="btn-primary flex-1 py-1.5 text-[12px]"
                        >
                          {isBusy ? "Saving…" : "Save"}
                        </button>
                        <button
                          onClick={() => setEditingId(null)}
                          className="btn-secondary flex-1 py-1.5 text-[12px]"
                        >
                          Cancel
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-white/5 pt-3">
                  <button
                    onClick={() => handleTest(provider.id)}
                    disabled={testingId === provider.id}
                    className="btn-pill"
                  >
                    {testingId === provider.id ? <Spinner className="h-3 w-3" /> : "Test connection"}
                  </button>
                  {!isEditing && (
                    <button onClick={() => startEdit(provider)} className="btn-pill">
                      Edit model / URL
                    </button>
                  )}
                  {!isDefault && provider.is_enabled && (
                    <button onClick={() => makeDefault(provider)} disabled={isBusy} className="btn-pill">
                      Make default
                    </button>
                  )}
                  {provider.is_free_only && (
                    <label className="btn-pill flex items-center gap-1.5">
                      <input
                        type="checkbox"
                        checked={provider.auto_fallback_enabled}
                        onChange={() => toggleAutoFallback(provider)}
                        disabled={isBusy}
                        className="h-3 w-3 accent-brand"
                      />
                      Auto-fallback
                    </label>
                  )}
                  <button
                    onClick={() => handleDelete(provider.id)}
                    disabled={isBusy}
                    className="btn-pill ml-auto text-danger hover:text-red-400"
                  >
                    Delete
                  </button>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </PageShell>
  );
}
