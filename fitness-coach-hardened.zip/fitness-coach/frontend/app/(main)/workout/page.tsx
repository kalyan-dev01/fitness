"use client";

import { useEffect, useState } from "react";
import { LineChart, Line, XAxis, Tooltip, ResponsiveContainer } from "recharts";
import {
  api,
  ExerciseOut,
  ExerciseSetInput,
  ExerciseStrengthPoint,
  ExerciseVolumePoint,
  ProgressionOut,
  WorkoutSessionOut,
} from "@/lib/api-client";
import { useToast } from "@/components/ui/Toast";
import { Card, EmptyState, PageHeader, PageShell, Spinner } from "@/components/ui/PageShell";
import { motion } from "framer-motion";

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

const chartTooltipStyle = {
  background: "#1c1e24",
  border: "1px solid #2c2e37",
  borderRadius: 12,
};

export default function WorkoutPage() {
  const { showError, showSuccess } = useToast();
  const [exercises, setExercises] = useState<ExerciseOut[]>([]);
  const [sessions, setSessions] = useState<WorkoutSessionOut[]>([]);
  const [selectedExerciseId, setSelectedExerciseId] = useState("");
  const [sets, setSets] = useState<ExerciseSetInput[]>([{ weight_kg: 0, reps: 0 }]);
  const [suggestion, setSuggestion] = useState<ProgressionOut | null>(null);
  const [saving, setSaving] = useState(false);
  const [volumePoints, setVolumePoints] = useState<ExerciseVolumePoint[]>([]);
  const [strengthPoints, setStrengthPoints] = useState<ExerciseStrengthPoint[]>([]);

  useEffect(() => {
    api.exercises
      .list()
      .then((list) => {
        setExercises(list);
        if (list.length) setSelectedExerciseId(list[0].id);
      })
      .catch((err) => showError(err, "Couldn't load your exercise list."));
    api.workouts
      .list()
      .then(setSessions)
      .catch((err) => showError(err, "Couldn't load your workout history."));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!selectedExerciseId) return;
    api.progression
      .suggestion(selectedExerciseId)
      .then(setSuggestion)
      .catch(() => setSuggestion(null));
    api.analytics
      .workoutVolume(selectedExerciseId)
      .then((r) => setVolumePoints(r.points))
      .catch(() => setVolumePoints([]));
    api.analytics
      .strength(selectedExerciseId)
      .then((r) => setStrengthPoints(r.points))
      .catch(() => setStrengthPoints([]));
  }, [selectedExerciseId]);

  function updateSet(index: number, field: keyof ExerciseSetInput, value: number) {
    setSets((prev) => prev.map((s, i) => (i === index ? { ...s, [field]: value } : s)));
  }

  function addSet() {
    setSets((prev) => [...prev, { weight_kg: prev.at(-1)?.weight_kg ?? 0, reps: 0 }]);
  }

  async function handleLog() {
    if (!selectedExerciseId) return;
    setSaving(true);
    try {
      await api.workouts.log({
        date: today(),
        exercises: [{ exercise_id: selectedExerciseId, sets }],
      });
      setSets([{ weight_kg: 0, reps: 0 }]);
      setSessions(await api.workouts.list());
      setSuggestion(await api.progression.suggestion(selectedExerciseId));
      api.analytics.workoutVolume(selectedExerciseId).then((r) => setVolumePoints(r.points));
      api.analytics.strength(selectedExerciseId).then((r) => setStrengthPoints(r.points));
      showSuccess("Workout logged.");
    } catch (err) {
      showError(err, "Couldn't save that workout — nothing was logged.");
    } finally {
      setSaving(false);
    }
  }

  const exerciseName = (id: string) => exercises.find((e) => e.id === id)?.name ?? "—";

  return (
    <PageShell>
      <PageHeader title="Workout" />

      <Card className="mb-6">
        <label className="label-xs">Exercise</label>
        <select
          value={selectedExerciseId}
          onChange={(e) => setSelectedExerciseId(e.target.value)}
          className="input-field mb-3"
        >
          {exercises.map((e) => (
            <option key={e.id} value={e.id}>
              {e.name}
            </option>
          ))}
        </select>

        {suggestion && (
          <div className="mb-3 rounded-xl bg-brand/[0.07] px-3.5 py-2.5 text-[13px] text-ink">
            {suggestion.suggested_next_weight_kg ? (
              <>
                Suggested next weight:{" "}
                <span className="font-semibold text-brand">
                  {suggestion.suggested_next_weight_kg}kg
                </span>
              </>
            ) : (
              suggestion.reasoning
            )}
          </div>
        )}

        {strengthPoints.length > 1 && (
          <div className="mb-1 h-24">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={strengthPoints}>
                <XAxis dataKey="date" hide />
                <Tooltip formatter={(v: number) => [`${v}kg`, "Best weight"]} contentStyle={chartTooltipStyle} />
                <Line
                  type="monotone"
                  dataKey="best_weight_kg"
                  stroke="#32d74b"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
        {volumePoints.length > 1 && (
          <div className="mb-3 h-20">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={volumePoints}>
                <XAxis dataKey="date" hide />
                <Tooltip formatter={(v: number) => [`${v}`, "Volume (kg×reps)"]} contentStyle={chartTooltipStyle} />
                <Line
                  type="monotone"
                  dataKey="volume"
                  stroke="#66676f"
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        <div className="space-y-2">
          {sets.map((set, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -6 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-2"
            >
              <span className="w-6 text-[12px] text-ink-faint">#{i + 1}</span>
              <input
                type="number"
                placeholder="kg"
                value={set.weight_kg || ""}
                onChange={(e) => updateSet(i, "weight_kg", Number(e.target.value))}
                className="input-field w-20 py-1.5"
              />
              <span className="text-ink-faint">×</span>
              <input
                type="number"
                placeholder="reps"
                value={set.reps || ""}
                onChange={(e) => updateSet(i, "reps", Number(e.target.value))}
                className="input-field w-20 py-1.5"
              />
            </motion.div>
          ))}
        </div>

        <button onClick={addSet} className="mt-2.5 text-[12px] font-medium text-brand hover:underline">
          + Add set
        </button>

        <button onClick={handleLog} disabled={saving} className="btn-primary mt-4 w-full">
          {saving ? "Saving…" : "Log workout"}
        </button>
      </Card>

      <Card className="!p-0">
        <h2 className="border-b border-white/5 px-4 py-3 text-[13px] font-semibold text-ink">
          Recent sessions
        </h2>
        <ul className="divide-y divide-white/5">
          {sessions.map((session) => (
            <li key={session.id} className="px-4 py-3 text-[13px]">
              <div className="mb-1 font-medium text-ink">{session.date}</div>
              {session.exercises.map((we) => (
                <div key={we.id} className="text-ink-muted">
                  {exerciseName(we.exercise_id)}:{" "}
                  {we.sets
                    .map((s) => `${s.weight_kg}kg×${s.reps}${s.is_pr ? " 🏆" : ""}`)
                    .join(", ")}
                </div>
              ))}
            </li>
          ))}
          {sessions.length === 0 && <EmptyState>No workouts logged yet.</EmptyState>}
        </ul>
      </Card>
    </PageShell>
  );
}
