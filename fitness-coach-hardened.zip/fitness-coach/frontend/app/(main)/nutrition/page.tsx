"use client";

import { useEffect, useState } from "react";
import { LineChart, Line, XAxis, Tooltip, ResponsiveContainer } from "recharts";
import { api, ApiError, FoodOut, DailyNutritionSummary, ParsedFoodItem } from "@/lib/api-client";
import { useToast } from "@/components/ui/Toast";
import { Card, EmptyState, PageHeader, PageShell, Spinner } from "@/components/ui/PageShell";
import { motion, AnimatePresence } from "framer-motion";

const MEAL_TYPES = [
  "BREAKFAST",
  "LUNCH",
  "DINNER",
  "SNACK",
  "PRE_WORKOUT",
  "POST_WORKOUT",
] as const;

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

export default function NutritionPage() {
  const { showError, showSuccess, showInfo } = useToast();
  const [summary, setSummary] = useState<DailyNutritionSummary | null>(null);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<FoodOut[]>([]);
  const [selectedFood, setSelectedFood] = useState<FoodOut | null>(null);
  const [quantity, setQuantity] = useState(100);
  const [rawCooked, setRawCooked] = useState<"RAW" | "COOKED" | "NA">("RAW");
  const [mealType, setMealType] = useState<(typeof MEAL_TYPES)[number]>("BREAKFAST");
  const [adding, setAdding] = useState(false);

  const [quickAddText, setQuickAddText] = useState("");
  const [parsedItems, setParsedItems] = useState<ParsedFoodItem[]>([]);
  const [parsing, setParsing] = useState(false);
  const [parseUnavailable, setParseUnavailable] = useState(false);
  const [nutritionTrend, setNutritionTrend] = useState<
    { date: string; calories: number; protein: number }[]
  >([]);

  const date = today();

  async function loadSummary() {
    try {
      const data = await api.nutrition.daily(date);
      setSummary(data);
    } catch (err) {
      showError(err, "Couldn't load today's nutrition summary.");
    }
  }

  useEffect(() => {
    loadSummary();
    api.analytics
      .nutrition(14)
      .then((series) => {
        const byDate = new Map<string, { calories: number; protein: number }>();
        series.calories.forEach((p) => byDate.set(p.date, { calories: p.value, protein: 0 }));
        series.protein.forEach((p) => {
          const existing = byDate.get(p.date) ?? { calories: 0, protein: 0 };
          byDate.set(p.date, { ...existing, protein: p.value });
        });
        setNutritionTrend(
          Array.from(byDate.entries())
            .sort((a, b) => a[0].localeCompare(b[0]))
            .map(([date, v]) => ({ date, ...v }))
        );
      })
      .catch((err) => showError(err, "Couldn't load your 14-day nutrition trend."));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!query) {
      setResults([]);
      return;
    }
    const handle = setTimeout(() => {
      api.foods
        .search(query)
        .then(setResults)
        .catch((err) => {
          setResults([]);
          showError(err, "Food search failed.");
        });
    }, 250);
    return () => clearTimeout(handle);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  async function handleQuickAddParse() {
    if (!quickAddText.trim()) return;
    setParsing(true);
    setParseUnavailable(false);
    try {
      const result = await api.coach.parseFood(quickAddText);
      if (result.ai_unavailable) {
        setParseUnavailable(true);
        setParsedItems([]);
      } else {
        setParsedItems(result.items);
        if (result.items.length === 0) {
          showInfo(
            "Couldn't recognize any food items in that text — try rephrasing or use search below."
          );
        }
      }
    } catch (err) {
      showError(err, "Quick Add couldn't parse that text. Please try again.");
    } finally {
      setParsing(false);
    }
  }

  async function handleConfirmQuickAdd() {
    const matched = parsedItems.filter((i) => i.matched_food_id && !i.needs_manual_match);
    if (matched.length === 0) return;
    setAdding(true);
    try {
      await api.meals.create({
        date,
        meal_type: mealType,
        items: matched.map((i) => ({
          food_id: i.matched_food_id!,
          quantity: i.quantity,
          unit: i.unit,
          raw_cooked: i.raw_cooked as "RAW" | "COOKED" | "NA",
        })),
      });
      setParsedItems([]);
      setQuickAddText("");
      showSuccess("Added to your diary.");
      await loadSummary();
    } catch (err) {
      showError(err, "Couldn't add those items to your diary.");
    } finally {
      setAdding(false);
    }
  }

  function removeParsedItem(index: number) {
    setParsedItems((prev) => prev.filter((_, i) => i !== index));
  }

  function selectFood(food: FoodOut) {
    setSelectedFood(food);
    const states = new Set(food.servings.map((s) => s.raw_cooked));
    setRawCooked(states.has("RAW") ? "RAW" : (food.servings[0]?.raw_cooked as any) ?? "NA");
  }

  async function handleAdd() {
    if (!selectedFood) return;
    setAdding(true);
    try {
      const unit = selectedFood.servings.find((s) => s.raw_cooked === rawCooked)?.unit
        ?? selectedFood.default_unit;
      await api.meals.create({
        date,
        meal_type: mealType,
        items: [
          {
            food_id: selectedFood.id,
            quantity,
            unit,
            raw_cooked: rawCooked,
          },
        ],
      });
      setSelectedFood(null);
      setQuery("");
      setResults([]);
      showSuccess("Added to your diary.");
      await loadSummary();
    } catch (err) {
      showError(err instanceof ApiError ? err : err, "Couldn't add that item.");
    } finally {
      setAdding(false);
    }
  }

  return (
    <PageShell>
      <PageHeader title="Nutrition" subtitle={date} />

      {summary && (
        <Card className="mb-6 grid grid-cols-4 gap-2">
          <Stat label="Calories" value={summary.calories} />
          <Stat label="Protein" value={`${summary.protein_g}g`} />
          <Stat label="Carbs" value={`${summary.carbs_g}g`} />
          <Stat label="Fat" value={`${summary.fat_g}g`} />
        </Card>
      )}

      {nutritionTrend.length > 1 && (
        <Card className="mb-6">
          <h2 className="mb-2 text-[11px] font-semibold uppercase tracking-wide text-ink-faint">
            Calories — last 14 days
          </h2>
          <div className="h-24">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={nutritionTrend}>
                <XAxis dataKey="date" hide />
                <Tooltip
                  formatter={(v: number) => [`${v} kcal`, "Calories"]}
                  contentStyle={{ background: "#1c1e24", border: "1px solid #2c2e37", borderRadius: 12 }}
                />
                <Line type="monotone" dataKey="calories" stroke="#32d74b" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      )}

      <Card className="mb-6">
        <h2 className="mb-3 text-[15px] font-semibold text-ink">Quick Add</h2>
        <p className="mb-2.5 text-[12px] text-ink-faint">
          Describe what you ate in plain language — e.g. "50g oats, 150ml milk and 2 eggs".
        </p>
        <div className="mb-2 flex gap-2">
          <input
            value={quickAddText}
            onChange={(e) => setQuickAddText(e.target.value)}
            placeholder="50g oats, 150ml milk and 2 eggs"
            className="input-field flex-1"
          />
          <button
            onClick={handleQuickAddParse}
            disabled={parsing}
            className="btn-secondary px-4"
          >
            {parsing ? <Spinner className="h-4 w-4" /> : "Parse"}
          </button>
        </div>

        {parseUnavailable && (
          <p className="rounded-xl bg-warning-muted px-3 py-2 text-[12px] text-yellow-300">
            AI Coach is unavailable right now, so Quick Add can't parse text.
            Use the search box below to add foods manually.
          </p>
        )}

        <AnimatePresence>
          {parsedItems.length > 0 && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-2 overflow-hidden"
            >
              {parsedItems.map((item, i) => (
                <div
                  key={i}
                  className={`flex items-center justify-between rounded-xl border px-3 py-2 text-[13px] ${
                    item.needs_manual_match
                      ? "border-warning/20 bg-warning-muted"
                      : "border-white/5 bg-surface-2"
                  }`}
                >
                  <div>
                    <span className="font-medium text-ink">
                      {item.matched_food_name ?? item.raw_name}
                    </span>
                    <span className="ml-2 text-ink-faint">
                      {item.quantity}
                      {item.unit}
                    </span>
                    {item.needs_manual_match ? (
                      <span className="ml-2 text-[11px] text-yellow-400">
                        no match — add manually below
                      </span>
                    ) : (
                      <span className="ml-2 text-[11px] text-ink-faint">
                        {item.calories} kcal · {item.protein_g}g protein
                        {!item.is_verified && " (estimated)"}
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => removeParsedItem(i)}
                    className="text-[11px] text-ink-faint hover:text-danger"
                  >
                    remove
                  </button>
                </div>
              ))}
              <button
                onClick={handleConfirmQuickAdd}
                disabled={adding || !parsedItems.some((i) => i.matched_food_id)}
                className="btn-primary mt-1 w-full"
              >
                {adding ? "Adding…" : "Confirm & add to diary"}
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </Card>

      <Card>
        <h2 className="mb-3 text-[15px] font-semibold text-ink">Search &amp; add food</h2>

        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search foods, e.g. chicken, rice, dal…"
          className="input-field mb-2"
        />

        {results.length > 0 && !selectedFood && (
          <ul className="mb-2 max-h-48 divide-y divide-white/5 overflow-y-auto rounded-xl border border-white/5 bg-surface-2">
            {results.map((food) => (
              <li key={food.id}>
                <button
                  onClick={() => selectFood(food)}
                  className="flex w-full items-center justify-between px-3 py-2.5 text-left text-[13px] transition hover:bg-white/5"
                >
                  <span className="text-ink">{food.name}</span>
                  {!food.is_verified && (
                    <span className="rounded bg-warning-muted px-1.5 py-0.5 text-[10px] text-yellow-300">
                      estimated
                    </span>
                  )}
                </button>
              </li>
            ))}
          </ul>
        )}

        {selectedFood && (
          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            animate={{ opacity: 1, scale: 1 }}
            className="mb-2 space-y-3 rounded-xl border border-white/5 bg-surface-2 p-3.5"
          >
            <div className="flex items-center justify-between text-[13px] font-medium">
              <span className="text-ink">{selectedFood.name}</span>
              <button
                onClick={() => setSelectedFood(null)}
                className="text-[11px] text-ink-faint hover:text-ink"
              >
                change
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label-xs">Quantity</label>
                <input
                  type="number"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="input-field py-1.5"
                />
              </div>
              <div>
                <label className="label-xs">Meal</label>
                <select
                  value={mealType}
                  onChange={(e) => setMealType(e.target.value as any)}
                  className="input-field py-1.5"
                >
                  {MEAL_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {t.replace("_", " ").toLowerCase()}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {new Set(selectedFood.servings.map((s) => s.raw_cooked)).size > 1 && (
              <div className="flex gap-2 text-[12px]">
                {["RAW", "COOKED"].map((state) => (
                  <button
                    key={state}
                    onClick={() => setRawCooked(state as "RAW" | "COOKED")}
                    className={`rounded-full px-3 py-1 transition ${
                      rawCooked === state
                        ? "bg-brand text-black"
                        : "bg-white/[0.06] text-ink-muted"
                    }`}
                  >
                    {state.toLowerCase()}
                  </button>
                ))}
              </div>
            )}

            <button onClick={handleAdd} disabled={adding} className="btn-primary w-full">
              {adding ? "Adding…" : "Add to diary"}
            </button>
          </motion.div>
        )}
      </Card>

      {summary && summary.meals.length > 0 && (
        <div className="mt-6 space-y-4">
          {summary.meals.map((meal) => (
            <Card key={meal.id}>
              <h3 className="mb-2 text-[13px] font-semibold capitalize text-ink">
                {meal.meal_type.replace("_", " ").toLowerCase()}
              </h3>
              <ul className="space-y-1 text-[13px] text-ink-muted">
                {meal.items.map((item) => (
                  <li key={item.id} className="flex justify-between">
                    <span>
                      {item.label_snapshot} — {item.quantity}
                      {item.unit}
                      {item.raw_cooked !== "NA" && ` (${item.raw_cooked.toLowerCase()})`}
                    </span>
                    <span>{item.calories_snapshot} kcal</span>
                  </li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      )}
    </PageShell>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div>
      <div className="text-[15px] font-semibold text-ink">{value}</div>
      <div className="text-[10px] text-ink-faint">{label}</div>
    </div>
  );
}
