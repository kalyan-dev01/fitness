"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { api, DailyNutritionSummary, WaterDailyOut, WeightTrendOut } from "@/lib/api-client";
import { useToast } from "@/components/ui/Toast";
import { Card, PageHeader, PageShell, Spinner } from "@/components/ui/PageShell";

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

const WATER_QUICK_ADD = [250, 500, 750];

export default function HomePage() {
  const { showError } = useToast();
  const [summary, setSummary] = useState<DailyNutritionSummary | null>(null);
  const [water, setWater] = useState<WaterDailyOut | null>(null);
  const [weightTrend, setWeightTrend] = useState<WeightTrendOut | null>(null);
  const [insight, setInsight] = useState<string | null>(null);
  const [insightUnavailable, setInsightUnavailable] = useState(false);
  const [insightLoading, setInsightLoading] = useState(true);
  const [addingWater, setAddingWater] = useState<number | null>(null);

  async function loadWater() {
    try {
      setWater(await api.water.daily(today()));
    } catch (err) {
      showError(err, "Couldn't load today's water total.");
    }
  }

  useEffect(() => {
    api.nutrition
      .daily(today())
      .then(setSummary)
      .catch((err) => showError(err, "Couldn't load today's nutrition summary."));
    loadWater();
    api.weight
      .trend()
      .then(setWeightTrend)
      .catch((err) => showError(err, "Couldn't load your weight trend."));
    api.coach
      .send("Give me a one or two sentence insight on how my day is going so far.")
      .then((r) => {
        if (r.ai_unavailable) {
          setInsightUnavailable(true);
        } else {
          setInsight(r.reply);
        }
      })
      .catch(() => setInsightUnavailable(true))
      .finally(() => setInsightLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function addWater(ml: number) {
    setAddingWater(ml);
    try {
      await api.water.log(today(), ml);
      await loadWater();
    } catch (err) {
      showError(err, "Couldn't log that water amount.");
    } finally {
      setAddingWater(null);
    }
  }

  return (
    <PageShell>
      <PageHeader title="Today" subtitle="How am I doing today?" />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat label="Calories" value={summary?.calories ?? "–"} unit="kcal" />
        <Stat label="Protein" value={summary?.protein_g ?? "–"} unit="g" />
        <Stat label="Carbs" value={summary?.carbs_g ?? "–"} unit="g" />
        <Stat label="Fat" value={summary?.fat_g ?? "–"} unit="g" />
      </div>

      {insightLoading ? (
        <div className="mt-4 flex items-center gap-2 rounded-xl2 border border-brand/15 bg-brand/[0.06] px-4 py-3.5 text-[13px] text-ink-muted">
          <Spinner className="h-3.5 w-3.5" /> Thinking about your day…
        </div>
      ) : insight && !insightUnavailable ? (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 rounded-xl2 border border-brand/15 bg-brand/[0.06] p-4"
        >
          <div className="mb-1 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-wide text-brand">
            <span>🧠</span> Coach Insight
          </div>
          <p className="text-[14px] leading-relaxed text-ink">{insight}</p>
        </motion.div>
      ) : insightUnavailable ? (
        <div className="mt-4 rounded-xl2 border border-white/5 bg-surface-1 px-4 py-3 text-[13px] text-ink-faint">
          AI Coach is temporarily unavailable — your logging still works as normal.
        </div>
      ) : null}

      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        <Card>
          <div className="mb-3 flex items-baseline justify-between">
            <span className="text-[11px] font-medium uppercase tracking-wide text-ink-faint">
              Water
            </span>
            <span className="text-[14px] font-medium text-ink">
              {water ? `${(water.total_ml / 1000).toFixed(1)}L` : "–"}
              {water?.target_ml ? ` / ${(water.target_ml / 1000).toFixed(1)}L` : ""}
            </span>
          </div>
          <div className="flex gap-2">
            {WATER_QUICK_ADD.map((ml) => (
              <button
                key={ml}
                onClick={() => addWater(ml)}
                disabled={addingWater !== null}
                className="btn-secondary flex-1 py-2 text-[12px] disabled:opacity-40"
              >
                {addingWater === ml ? <Spinner className="h-3.5 w-3.5" /> : `+${ml}ml`}
              </button>
            ))}
          </div>
        </Card>

        <Card>
          <div className="mb-1 text-[11px] font-medium uppercase tracking-wide text-ink-faint">
            Weight
          </div>
          <div className="text-[19px] font-semibold text-ink">
            {weightTrend?.latest_kg !== null && weightTrend?.latest_kg !== undefined
              ? `${weightTrend.latest_kg} kg`
              : "No entries yet"}
          </div>
          {weightTrend?.seven_day_avg_kg != null && (
            <div className="mt-0.5 text-[12px] text-ink-faint">
              7-day avg: {weightTrend.seven_day_avg_kg} kg
            </div>
          )}
        </Card>
      </div>
    </PageShell>
  );
}

function Stat({
  label,
  value,
  unit,
}: {
  label: string;
  value: number | string;
  unit: string;
}) {
  return (
    <Card className="p-3.5">
      <div className="text-[11px] font-medium uppercase tracking-wide text-ink-faint">
        {label}
      </div>
      <div className="mt-1 text-[20px] font-semibold text-ink">
        {value} <span className="text-[12px] font-normal text-ink-faint">{unit}</span>
      </div>
    </Card>
  );
}
