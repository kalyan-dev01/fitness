"use client";

import { useEffect, useState } from "react";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import {
  api,
  DailyReviewOut,
  ProgressPhotoOut,
  SeriesPoint,
  WeeklyReportOut,
  WeightEntryOut,
  WeightTrendOut,
} from "@/lib/api-client";
import { useToast } from "@/components/ui/Toast";
import { Card, EmptyState, PageHeader, PageShell, Spinner } from "@/components/ui/PageShell";
import { motion } from "framer-motion";

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

export default function ProgressPage() {
  const { showError, showSuccess } = useToast();
  const [entries, setEntries] = useState<WeightEntryOut[]>([]);
  const [trend, setTrend] = useState<WeightTrendOut | null>(null);
  const [chartPoints, setChartPoints] = useState<SeriesPoint[]>([]);
  const [weight, setWeight] = useState("");
  const [source, setSource] = useState("Gym");
  const [saving, setSaving] = useState(false);

  const [dailyReview, setDailyReview] = useState<DailyReviewOut | null>(null);
  const [dailyUnavailable, setDailyUnavailable] = useState(false);
  const [loadingDaily, setLoadingDaily] = useState(false);
  const [weeklyReport, setWeeklyReport] = useState<WeeklyReportOut | null>(null);
  const [weeklyUnavailable, setWeeklyUnavailable] = useState(false);
  const [loadingWeekly, setLoadingWeekly] = useState(false);

  const [photos, setPhotos] = useState<ProgressPhotoOut[]>([]);
  const [photoAngle, setPhotoAngle] = useState("FRONT");
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  async function load() {
    try {
      const [list, t, chart] = await Promise.all([
        api.weight.list(),
        api.weight.trend(),
        api.analytics.weight(90),
      ]);
      setEntries(list);
      setTrend(t);
      setChartPoints(chart.points);
    } catch (err) {
      showError(err, "Couldn't load your weight history.");
    }
  }

  useEffect(() => {
    load();
    api.progressPhotos
      .list()
      .then(setPhotos)
      .catch((err) => showError(err, "Couldn't load your progress photos."));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleLog(e: React.FormEvent) {
    e.preventDefault();
    if (!weight) return;
    setSaving(true);
    try {
      await api.weight.log({
        date: today(),
        weight_kg: Number(weight),
        source: source || undefined,
      });
      setWeight("");
      await load();
      showSuccess("Weight logged.");
    } catch (err) {
      showError(err, "Couldn't save that weight entry.");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(id: string) {
    try {
      await api.weight.delete(id);
      await load();
    } catch (err) {
      showError(err, "Couldn't delete that entry.");
    }
  }

  async function loadDailyReview() {
    setLoadingDaily(true);
    setDailyUnavailable(false);
    try {
      const review = await api.reports.daily();
      if (review.ai_unavailable) {
        setDailyUnavailable(true);
        setDailyReview(null);
      } else {
        setDailyReview(review);
      }
    } catch (err) {
      showError(err, "Couldn't generate today's review.");
    } finally {
      setLoadingDaily(false);
    }
  }

  async function loadWeeklyReport() {
    setLoadingWeekly(true);
    setWeeklyUnavailable(false);
    try {
      const report = await api.reports.weekly();
      if (report.ai_unavailable) {
        setWeeklyUnavailable(true);
        setWeeklyReport(null);
      } else {
        setWeeklyReport(report);
      }
    } catch (err) {
      showError(err, "Couldn't generate this week's report.");
    } finally {
      setLoadingWeekly(false);
    }
  }

  async function handlePhotoUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingPhoto(true);
    try {
      await api.progressPhotos.upload(file, today(), photoAngle);
      setPhotos(await api.progressPhotos.list());
      showSuccess("Photo added.");
    } catch (err) {
      showError(err, "Couldn't upload that photo.");
    } finally {
      setUploadingPhoto(false);
      e.target.value = "";
    }
  }

  async function handleDeletePhoto(id: string) {
    try {
      await api.progressPhotos.delete(id);
      setPhotos(await api.progressPhotos.list());
    } catch (err) {
      showError(err, "Couldn't delete that photo.");
    }
  }

  return (
    <PageShell>
      <PageHeader title="Progress" />

      {trend && trend.latest_kg !== null && (
        <Card className="mb-5">
          <div className="flex items-baseline justify-between">
            <div>
              <div className="text-[22px] font-semibold text-ink">{trend.latest_kg} kg</div>
              <div className="text-[12px] text-ink-faint">
                as of {trend.latest_date}
                {trend.change_from_previous_kg !== null &&
                  ` · ${trend.change_from_previous_kg > 0 ? "+" : ""}${trend.change_from_previous_kg}kg from last entry`}
              </div>
            </div>
            {trend.goal_weight_kg !== null && (
              <div className="text-right text-[12px] text-ink-faint">
                Goal
                <div className="text-[14px] font-medium text-ink">{trend.goal_weight_kg} kg</div>
              </div>
            )}
          </div>

          {chartPoints.length > 1 && (
            <div className="mt-3 h-32">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartPoints}>
                  <XAxis dataKey="date" hide />
                  <YAxis domain={["dataMin - 1", "dataMax + 1"]} hide />
                  <Tooltip
                    formatter={(v: number) => [`${v} kg`, "Weight"]}
                    labelFormatter={(d) => d}
                    contentStyle={{ background: "#1c1e24", border: "1px solid #2c2e37", borderRadius: 12 }}
                  />
                  <Line type="monotone" dataKey="value" stroke="#32d74b" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}

          <div className="mt-3 grid grid-cols-2 gap-3 border-t border-white/5 pt-3 text-[13px] text-ink">
            <div>
              <span className="text-ink-faint">7-day avg: </span>
              {trend.seven_day_avg_kg ?? "–"} kg
            </div>
            <div>
              <span className="text-ink-faint">30-day change: </span>
              {trend.thirty_day_change_kg ?? "–"} kg
            </div>
          </div>
        </Card>
      )}

      <Card as="form" className="mb-5 flex items-end gap-3">
        <div className="flex-1">
          <label className="label-xs">Weight (kg)</label>
          <input
            type="number"
            step="0.1"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            required
            className="input-field"
          />
        </div>
        <div className="flex-1">
          <label className="label-xs">Source</label>
          <input
            value={source}
            onChange={(e) => setSource(e.target.value)}
            placeholder="Gym"
            className="input-field"
          />
        </div>
        <button onClick={handleLog} disabled={saving} className="btn-primary">
          {saving ? "Saving…" : "Log"}
        </button>
      </Card>

      <Card className="mb-5 !p-0">
        <h2 className="border-b border-white/5 px-4 py-3 text-[13px] font-semibold text-ink">
          History
        </h2>
        <ul className="divide-y divide-white/5">
          {entries.map((entry) => (
            <li key={entry.id} className="flex items-center justify-between px-4 py-3 text-[13px]">
              <div>
                <span className="font-medium text-ink">{entry.weight_kg} kg</span>
                <span className="ml-2 text-ink-faint">
                  {entry.date}
                  {entry.source && ` · ${entry.source}`}
                </span>
              </div>
              <button
                onClick={() => handleDelete(entry.id)}
                className="text-[11px] text-ink-faint hover:text-danger"
              >
                delete
              </button>
            </li>
          ))}
          {entries.length === 0 && <EmptyState>No weight entries yet.</EmptyState>}
        </ul>
      </Card>

      <Card className="mb-5">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-[13px] font-semibold text-ink">Today's Review</h2>
          <button
            onClick={loadDailyReview}
            disabled={loadingDaily}
            className="text-[12px] font-medium text-brand hover:underline disabled:opacity-60"
          >
            {loadingDaily ? "Loading…" : dailyReview ? "Refresh" : "Generate"}
          </button>
        </div>
        {dailyUnavailable && (
          <p className="rounded-xl bg-warning-muted px-3 py-2 text-[12px] text-yellow-300">
            AI Coach is temporarily unavailable — try again in a bit.
          </p>
        )}
        {dailyReview && (
          <div className="space-y-2 text-[13px]">
            <p className="whitespace-pre-line text-ink">{dailyReview.review_text}</p>
            <div className="grid grid-cols-2 gap-2 border-t border-white/5 pt-2 text-[12px] text-ink-faint">
              <span>
                Calories: {dailyReview.calories}
                {dailyReview.calorie_target ? ` / ${dailyReview.calorie_target}` : ""}
              </span>
              <span>
                Protein: {dailyReview.protein_g}g
                {dailyReview.protein_target_g ? ` / ${dailyReview.protein_target_g}g` : ""}
              </span>
              <span>Water: {(dailyReview.water_ml / 1000).toFixed(1)}L</span>
              <span>Workout: {dailyReview.workout_logged ? "Logged" : "Not logged"}</span>
            </div>
          </div>
        )}
      </Card>

      <Card className="mb-5">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="text-[13px] font-semibold text-ink">Weekly Coach Report</h2>
          <button
            onClick={loadWeeklyReport}
            disabled={loadingWeekly}
            className="text-[12px] font-medium text-brand hover:underline disabled:opacity-60"
          >
            {loadingWeekly ? "Loading…" : "Generate this week's report"}
          </button>
        </div>
        {weeklyUnavailable && (
          <p className="rounded-xl bg-warning-muted px-3 py-2 text-[12px] text-yellow-300">
            AI Coach is temporarily unavailable — try again in a bit.
          </p>
        )}
        {weeklyReport && (
          <div className="space-y-3 text-[13px]">
            <p className="text-ink">{weeklyReport.conclusion}</p>
            <div className="grid grid-cols-2 gap-2 border-t border-white/5 pt-2 text-[12px] text-ink-faint">
              <span>Avg calories: {weeklyReport.avg_calories}</span>
              <span>Avg protein: {weeklyReport.avg_protein_g}g</span>
              <span>Workouts: {weeklyReport.workouts_logged}</span>
              <span>Weight change: {weeklyReport.weight_change_kg ?? "–"}kg</span>
            </div>
            <div className="rounded-xl bg-surface-2 p-3 text-[12px] text-ink-muted">
              <div className="mb-1 font-medium text-ink">Next week (suggested)</div>
              <pre className="whitespace-pre-wrap font-sans">
                {JSON.stringify(weeklyReport.next_week_targets, null, 2)}
              </pre>
            </div>
          </div>
        )}
      </Card>

      <Card>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-[13px] font-semibold text-ink">Progress Photos</h2>
          <span className="text-[11px] text-ink-faint">Private — never public</span>
        </div>

        <div className="mb-4 flex items-center gap-2">
          <select
            value={photoAngle}
            onChange={(e) => setPhotoAngle(e.target.value)}
            className="input-field w-auto py-1.5"
          >
            <option value="FRONT">Front</option>
            <option value="SIDE">Side</option>
            <option value="BACK">Back</option>
          </select>
          <label className="btn-pill cursor-pointer py-1.5">
            {uploadingPhoto ? <Spinner className="h-3.5 w-3.5" /> : "Add photo"}
            <input
              type="file"
              accept="image/png,image/jpeg,image/webp"
              onChange={handlePhotoUpload}
              disabled={uploadingPhoto}
              className="hidden"
            />
          </label>
        </div>

        {photos.length > 0 ? (
          <div className="grid grid-cols-3 gap-2">
            {photos.map((photo) => (
              <motion.div
                key={photo.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="group relative aspect-square overflow-hidden rounded-xl bg-surface-2"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={api.progressPhotos.imageUrl(photo.id)}
                  alt={`${photo.angle} progress photo from ${photo.date}`}
                  className="h-full w-full object-cover"
                />
                <div className="absolute inset-x-0 bottom-0 bg-black/60 px-1.5 py-1 text-[10px] text-white">
                  {photo.date} · {photo.angle.toLowerCase()}
                </div>
                <button
                  onClick={() => handleDeletePhoto(photo.id)}
                  className="absolute right-1 top-1 rounded-full bg-black/60 px-1.5 py-0.5 text-[10px] text-white opacity-0 transition group-hover:opacity-100"
                >
                  delete
                </button>
              </motion.div>
            ))}
          </div>
        ) : (
          <EmptyState>No progress photos yet.</EmptyState>
        )}
      </Card>
    </PageShell>
  );
}
