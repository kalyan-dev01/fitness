"use client";

import { createContext, useCallback, useContext, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ApiError } from "@/lib/api-client";

type ToastKind = "error" | "success" | "info";

interface Toast {
  id: number;
  kind: ToastKind;
  message: string;
}

interface ToastContextValue {
  /** Report any caught error. Understands ApiError vs. network/unknown errors. */
  showError: (err: unknown, fallback?: string) => void;
  showSuccess: (message: string) => void;
  showInfo: (message: string) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

let nextId = 1;

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const dismiss = useCallback((id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const push = useCallback(
    (kind: ToastKind, message: string) => {
      const id = nextId++;
      setToasts((prev) => [...prev, { id, kind, message }]);
      // Errors stay a little longer than confirmations — worth reading, not
      // just glancing at.
      window.setTimeout(() => dismiss(id), kind === "error" ? 6000 : 3200);
    },
    [dismiss]
  );

  const showError = useCallback(
    (err: unknown, fallback = "Something went wrong. Please try again.") => {
      let message = fallback;
      if (err instanceof ApiError) {
        message = err.detail || fallback;
      } else if (err instanceof TypeError && err.message === "Failed to fetch") {
        message = "Can't reach the server — check your connection and try again.";
      } else if (err instanceof Error && err.message) {
        message = err.message;
      }
      push("error", message);
      // Always console-visible too, so it's diagnosable outside the UI.
      // eslint-disable-next-line no-console
      console.error(err);
    },
    [push]
  );

  const showSuccess = useCallback((message: string) => push("success", message), [push]);
  const showInfo = useCallback((message: string) => push("info", message), [push]);

  return (
    <ToastContext.Provider value={{ showError, showSuccess, showInfo }}>
      {children}
      <div
        className="pointer-events-none fixed inset-x-0 top-[env(safe-area-inset-top)] z-[100] flex flex-col items-center gap-2 px-4 pt-3"
        aria-live="polite"
      >
        <AnimatePresence>
          {toasts.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: -16, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -10, scale: 0.98 }}
              transition={{ type: "spring", stiffness: 420, damping: 32 }}
              onClick={() => dismiss(t.id)}
              className={`pointer-events-auto glass w-full max-w-sm cursor-pointer rounded-2xl border px-4 py-3 text-sm shadow-soft-lg ${
                t.kind === "error"
                  ? "border-danger/30 text-red-100"
                  : t.kind === "success"
                    ? "border-brand/30 text-ink"
                    : "border-white/10 text-ink"
              }`}
            >
              <div className="flex items-start gap-2.5">
                <span className="mt-0.5">
                  {t.kind === "error" ? "⚠️" : t.kind === "success" ? "✅" : "ℹ️"}
                </span>
                <span className="leading-snug">{t.message}</span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext);
  if (!ctx) {
    throw new Error("useToast must be used within a ToastProvider");
  }
  return ctx;
}
