"""
Quick Add parsing (spec section 15). The AI's only job is turning free text
into a rough structured list — it never determines final nutrition values.
Matching against the food database and computing calories is deterministic
code, and nothing here is ever saved to the diary automatically; the
caller (the /coach/parse-food endpoint) always returns this for the user
to confirm or edit before a separate call to POST /meals actually logs it.
"""
import json
import logging
import re

from pydantic import BaseModel, ValidationError
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.ai.provider_manager import ProviderManager
from app.db.models.food import Food, RawCooked, Unit
from app.schemas.coach import ParsedFoodItem

logger = logging.getLogger(__name__)


class _RawParsedItem(BaseModel):
    """Strict validation of the AI's raw JSON before any of it is trusted
    -- a model that ignores the schema (extra fields, wrong types, a
    string where a number was asked for) is rejected here rather than
    silently coerced or allowed to propagate further."""

    name: str
    quantity: float = 1
    unit: str = "serving"


class _RawParseResponse(BaseModel):
    items: list[_RawParsedItem] = []

_PARSE_SYSTEM_PROMPT = """\
Extract food items from the user's message into JSON only, no prose, no \
markdown fences. Schema:
{"items": [{"name": "string", "quantity": number, "unit": "g|ml|piece|tsp|tbsp|cup|serving"}]}
Use the food's common name (e.g. "oats", "milk", "eggs"). If no quantity is \
stated for a countable item, use quantity 1. If unit is unclear, use \
"serving". Return ONLY the JSON object.
"""

_UNIT_ALIASES = {
    "gram": "g", "grams": "g", "gm": "g",
    "ml": "ml", "milliliter": "ml", "millilitre": "ml",
    "piece": "piece", "pieces": "piece", "pc": "piece",
    "tsp": "tsp", "teaspoon": "tsp",
    "tbsp": "tbsp", "tablespoon": "tbsp",
    "cup": "cup", "cups": "cup",
    "serving": "serving", "servings": "serving",
}


def _extract_json(text: str) -> dict:
    # Strip markdown fences if the model added them despite instructions
    cleaned = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()
    return json.loads(cleaned)


def _parse_and_validate(raw_text: str) -> list[_RawParsedItem] | None:
    try:
        data = _extract_json(raw_text)
        validated = _RawParseResponse.model_validate(data)
    except (json.JSONDecodeError, AttributeError, ValidationError) as exc:
        logger.warning("AI food-parse response failed validation: %s", exc)
        return None
    return validated.items


async def parse_food_text(db: Session, user_id, text: str) -> list[ParsedFoodItem]:
    manager = ProviderManager(db, user_id)
    response = await manager.generate(text, system_prompt=_PARSE_SYSTEM_PROMPT)

    raw_items = _parse_and_validate(response.text)
    if raw_items is None:
        # One safe retry on malformed output -- a strict re-ask of the
        # exact same prompt occasionally succeeds where the first
        # generation didn't follow the schema. Never retried more than
        # once, and never trusted without re-validating the same way.
        retry = await manager.generate(text, system_prompt=_PARSE_SYSTEM_PROMPT)
        raw_items = _parse_and_validate(retry.text)

    if raw_items is None:
        # Still malformed after the retry -- never guess at bad output.
        # Deterministic fallback: surface nothing rather than risk a bad
        # parse silently making it into the diary later (nothing here is
        # ever saved automatically; the caller always returns this for the
        # user to confirm or edit first).
        return []

    results: list[ParsedFoodItem] = []
    for raw in raw_items:
        name = raw.name.strip()
        if not name:
            continue
        quantity = raw.quantity or 1
        unit_raw = raw.unit.strip().lower()
        unit = _UNIT_ALIASES.get(unit_raw, "serving")

        match = db.scalar(
            select(Food).options(selectinload(Food.servings)).where(Food.name.ilike(f"%{name}%"))
        )

        if match is None:
            results.append(
                ParsedFoodItem(
                    raw_name=name, quantity=quantity, unit=unit, needs_manual_match=True
                )
            )
            continue

        serving = next(
            (s for s in match.servings if s.unit.value == unit),
            match.servings[0] if match.servings else None,
        )
        if serving is None:
            results.append(
                ParsedFoodItem(
                    raw_name=name, quantity=quantity, unit=unit,
                    matched_food_id=match.id, matched_food_name=match.name,
                    needs_manual_match=True,
                )
            )
            continue

        is_per_100 = serving.unit in (Unit.G, Unit.ML)
        factor = (quantity / 100.0) if is_per_100 else quantity
        results.append(
            ParsedFoodItem(
                raw_name=name, quantity=quantity, unit=serving.unit.value,
                raw_cooked=serving.raw_cooked.value,
                matched_food_id=match.id, matched_food_name=match.name,
                is_verified=match.is_verified,
                calories=round(serving.calories * factor, 1),
                protein_g=round(serving.protein_g * factor, 1),
                carbs_g=round(serving.carbs_g * factor, 1),
                fat_g=round(serving.fat_g * factor, 1),
                needs_manual_match=False,
            )
        )

    return results
