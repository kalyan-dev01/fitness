"""
Security primitives: password hashing, JWT session tokens, and symmetric
encryption for at-rest secrets (used later by the AI provider credential
store — included now so the pattern is established from day one).
"""
from datetime import datetime, timedelta, timezone
from typing import Any

from cryptography.fernet import Fernet
from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import get_settings

settings = get_settings()

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain_password: str, password_hash: str) -> bool:
    return pwd_context.verify(plain_password, password_hash)


def create_access_token(
    subject: str, token_version: int = 0, expires_delta: timedelta | None = None
) -> str:
    expire = datetime.now(timezone.utc) + (
        expires_delta
        if expires_delta is not None
        else timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    to_encode: dict[str, Any] = {"sub": subject, "ver": token_version, "exp": expire}
    return jwt.encode(to_encode, settings.JWT_SECRET, algorithm=settings.JWT_ALGORITHM)


class DecodedToken:
    __slots__ = ("subject", "token_version")

    def __init__(self, subject: str, token_version: int):
        self.subject = subject
        self.token_version = token_version


def decode_access_token(token: str) -> DecodedToken | None:
    """
    Returns None on any invalid/expired/malformed token. Callers must also
    compare `token_version` against the user's current value in the DB —
    that's what makes logout / "log out everywhere" actually revoke a
    token instead of just deleting the cookie.
    """
    try:
        payload = jwt.decode(
            token, settings.JWT_SECRET, algorithms=[settings.JWT_ALGORITHM]
        )
    except JWTError:
        return None
    subject = payload.get("sub")
    if not subject:
        return None
    try:
        token_version = int(payload.get("ver", 0))
    except (TypeError, ValueError):
        return None
    return DecodedToken(subject=subject, token_version=token_version)


def _fernet() -> Fernet:
    if not settings.FIELD_ENCRYPTION_KEY:
        raise RuntimeError(
            "FIELD_ENCRYPTION_KEY is not set. Generate one with "
            "`python -c \"from cryptography.fernet import Fernet; "
            "print(Fernet.generate_key().decode())\"` and put it in .env."
        )
    return Fernet(settings.FIELD_ENCRYPTION_KEY.encode())


def encrypt_secret(plaintext: str) -> str:
    """Used for AI provider API keys (Phase 5) — never store them plaintext."""
    return _fernet().encrypt(plaintext.encode()).decode()


def decrypt_secret(ciphertext: str) -> str:
    return _fernet().decrypt(ciphertext.encode()).decode()


def mask_secret(plaintext: str, visible: int = 4) -> str:
    """Return a display-safe hint, e.g. 'sk-...ab12'. Never send the real key back."""
    if len(plaintext) <= visible:
        return "*" * len(plaintext)
    return f"{'*' * 6}...{plaintext[-visible:]}"
