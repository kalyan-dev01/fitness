"""
Application configuration.

All secrets/config come from environment variables (see .env.example).
Nothing here should contain a real secret value.
"""
import sys
from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict

# Values that must never be used in production -- these are exactly the
# placeholder defaults shipped in .env.example / this file, so a deploy
# that forgot to set a real secret gets caught here instead of quietly
# running with a guessable key.
_WEAK_JWT_SECRETS = {"", "change-me-in-.env", "replace-with-a-long-random-value"}
_WEAK_FIELD_KEYS = {"", "replace-with-a-generated-fernet-key"}


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # App
    APP_NAME: str = "Fitness Coach"
    ENV: str = "development"  # development | test | production
    DEBUG: bool = True
    LOG_LEVEL: str = "INFO"

    # Database
    DATABASE_URL: str = (
        "postgresql+psycopg2://fitness:fitness@localhost:5432/fitness_coach"
    )
    DB_POOL_SIZE: int = 10
    DB_MAX_OVERFLOW: int = 5
    DB_POOL_TIMEOUT_SECONDS: int = 30
    DB_POOL_RECYCLE_SECONDS: int = 1800  # recycle connections every 30 min

    # Auth
    JWT_SECRET: str = "change-me-in-.env"  # noqa: S105 - placeholder default only
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 14  # 14 days
    COOKIE_NAME: str = "fc_session"
    COOKIE_SECURE: bool = False  # set True in production (HTTPS)
    CSRF_COOKIE_NAME: str = "fc_csrf"
    CSRF_HEADER_NAME: str = "X-CSRF-Token"

    # Encryption for AI provider API keys stored at rest
    FIELD_ENCRYPTION_KEY: str = ""  # Fernet key, generate with cryptography.fernet.Fernet.generate_key()

    # CORS -- a single origin, since auth relies on a same-site cookie.
    FRONTEND_ORIGIN: str = "http://localhost:3000"

    # Progress photo storage -- a private directory, never served statically.
    # Mount this as a persistent Docker volume in production so photos
    # survive container restarts/redeploys.
    PROGRESS_PHOTO_STORAGE_DIR: str = "/app/storage/progress_photos"
    PROGRESS_PHOTO_MAX_BYTES: int = 10 * 1024 * 1024  # 10MB

    # Rate limiting (Postgres-backed -- see app/core/rate_limit.py). All
    # windows are per user-or-IP key and configurable per deployment.
    RATE_LIMIT_AUTH_MAX: int = 10
    RATE_LIMIT_AUTH_WINDOW_SECONDS: int = 60
    RATE_LIMIT_AI_MAX: int = 20
    RATE_LIMIT_AI_WINDOW_SECONDS: int = 60
    RATE_LIMIT_UPLOAD_MAX: int = 20
    RATE_LIMIT_UPLOAD_WINDOW_SECONDS: int = 300
    RATE_LIMIT_DEFAULT_MAX: int = 120
    RATE_LIMIT_DEFAULT_WINDOW_SECONDS: int = 60

    # AI provider reliability
    AI_REQUEST_TIMEOUT_SECONDS: float = 30.0
    AI_CONNECT_TIMEOUT_SECONDS: float = 10.0
    AI_MAX_RETRIES: int = 2
    AI_RETRY_BASE_DELAY_SECONDS: float = 0.5
    AI_MAX_CONCURRENT_REQUESTS: int = 4
    AI_MAX_STORED_MESSAGES_PER_CONVERSATION: int = 200

    # Error monitoring integration point (e.g. Sentry DSN). Left blank by
    # default so the app stays dependency-light; when set, wire it up in
    # main.py's startup hook. Never logged.
    SENTRY_DSN: str = ""

    def is_production(self) -> bool:
        return self.ENV.lower() == "production"


@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    _validate_production_settings(settings)
    return settings


def _validate_production_settings(settings: Settings) -> None:
    """
    Fail fast and loud rather than silently booting with insecure defaults.
    This runs once, at process startup (get_settings is lru_cache'd), so a
    misconfigured production deploy never serves a single request.
    """
    if not settings.is_production():
        return

    errors: list[str] = []
    if settings.JWT_SECRET in _WEAK_JWT_SECRETS or len(settings.JWT_SECRET) < 32:
        errors.append(
            "JWT_SECRET is missing or too short for production (need a real "
            "random value >= 32 chars). Generate with: "
            'python -c "import secrets; print(secrets.token_urlsafe(48))"'
        )
    if settings.FIELD_ENCRYPTION_KEY in _WEAK_FIELD_KEYS:
        errors.append(
            "FIELD_ENCRYPTION_KEY is missing. Generate with: "
            'python -c "from cryptography.fernet import Fernet; '
            'print(Fernet.generate_key().decode())"'
        )
    if settings.DEBUG:
        errors.append("DEBUG must be false in production (ENV=production).")
    if not settings.COOKIE_SECURE:
        errors.append("COOKIE_SECURE must be true in production (served over HTTPS).")
    if settings.FRONTEND_ORIGIN.startswith("http://") and "localhost" not in settings.FRONTEND_ORIGIN:
        errors.append(
            "FRONTEND_ORIGIN looks like plain HTTP in production -- use https://"
        )

    if errors:
        joined = "\n  - ".join(errors)
        message = f"Refusing to start in production with insecure configuration:\n  - {joined}"
        # Printed to stderr directly (in addition to raising) so it's
        # visible even if this happens before logging is configured.
        print(message, file=sys.stderr)
        raise RuntimeError(message)
