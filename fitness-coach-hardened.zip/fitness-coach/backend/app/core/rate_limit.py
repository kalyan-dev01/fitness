"""
Postgres-backed fixed-window rate limiter.

Replaces the old process-local in-memory limiter, which reset on every
worker restart and gave each uvicorn worker/container its own independent
counters -- meaning the *effective* limit was `configured_limit *
worker_count`, and trivially bypassable by whichever backend replica
happened to receive the next request.

This implementation uses a single shared table (`rate_limit_counters`)
and an atomic `INSERT ... ON CONFLICT ... DO UPDATE` to increment a
per-(limiter, key, window) counter. That statement is safe under
concurrent access from any number of workers/containers because the
increment happens inside Postgres itself, not in application memory.

Trade-off: fixed windows allow a short burst at the window boundary
(e.g. N requests just before a window ends and another N just after).
That's an acceptable, well-understood trade-off for this app's threat
model (abuse/brute-force throttling, not precise quota billing); a
sliding-window-log implementation would be more precise but needs
unbounded per-key storage and is unnecessary here.
"""
import random
from datetime import datetime, timedelta, timezone

from fastapi import HTTPException, Request, status
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.db.session import SessionLocal

settings = get_settings()


class RateLimiter:
    def __init__(self, *, name: str, max_requests: int, window_seconds: int):
        self.name = name
        self.max_requests = max_requests
        self.window_seconds = window_seconds

    def check(self, db: Session, identifier: str) -> None:
        now = datetime.now(timezone.utc)
        epoch = now.timestamp()
        window_start_epoch = epoch - (epoch % self.window_seconds)
        window_start = datetime.fromtimestamp(window_start_epoch, tz=timezone.utc)
        window_end = window_start + timedelta(seconds=self.window_seconds)
        bucket_key = f"{self.name}:{identifier}:{int(window_start_epoch)}"

        row = db.execute(
            text(
                """
                INSERT INTO rate_limit_counters (key, count, expires_at)
                VALUES (:key, 1, :expires_at)
                ON CONFLICT (key)
                DO UPDATE SET count = rate_limit_counters.count + 1
                RETURNING count
                """
            ),
            {"key": bucket_key, "expires_at": window_end},
        ).one()
        db.commit()

        # Opportunistic cleanup of expired buckets -- cheap, small chance
        # per request, avoids needing a separate cron job just to keep
        # this table from growing forever.
        if random.random() < 0.01:  # noqa: S311 - not security-sensitive
            db.execute(
                text("DELETE FROM rate_limit_counters WHERE expires_at < :now"),
                {"now": now},
            )
            db.commit()

        if row.count > self.max_requests:
            retry_after = max(1, int((window_end - now).total_seconds()))
            raise HTTPException(
                status.HTTP_429_TOO_MANY_REQUESTS,
                "Too many requests. Please wait before trying again.",
                headers={"Retry-After": str(retry_after)},
            )


# Stricter than the general API -- brute-force protection matters most on
# auth endpoints. Rate-limited by client IP (there's no authenticated user
# yet at login/register time).
auth_rate_limiter = RateLimiter(
    name="auth",
    max_requests=settings.RATE_LIMIT_AUTH_MAX,
    window_seconds=settings.RATE_LIMIT_AUTH_WINDOW_SECONDS,
)

# AI endpoints are the most expensive calls in the app (real provider
# latency/cost) and the most attractive target for request storms.
ai_rate_limiter = RateLimiter(
    name="ai",
    max_requests=settings.RATE_LIMIT_AI_MAX,
    window_seconds=settings.RATE_LIMIT_AI_WINDOW_SECONDS,
)

# Upload endpoints -- bounded separately from the AI limiter since large
# file uploads have a different cost profile (disk/bandwidth, not AI spend).
upload_rate_limiter = RateLimiter(
    name="upload",
    max_requests=settings.RATE_LIMIT_UPLOAD_MAX,
    window_seconds=settings.RATE_LIMIT_UPLOAD_WINDOW_SECONDS,
)

# A generous default for everything else, mainly to blunt scripted abuse
# rather than to constrain normal interactive use.
default_rate_limiter = RateLimiter(
    name="default",
    max_requests=settings.RATE_LIMIT_DEFAULT_MAX,
    window_seconds=settings.RATE_LIMIT_DEFAULT_WINDOW_SECONDS,
)


def _client_ip(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def rate_limit_by_key(limiter: RateLimiter):
    """FastAPI dependency for endpoints with no authenticated user yet
    (register/login) -- keys purely by client IP."""

    def dependency(request: Request) -> None:
        db = SessionLocal()
        try:
            limiter.check(db, _client_ip(request))
        finally:
            db.close()

    return dependency


def rate_limit_by_user_or_ip(limiter: RateLimiter):
    """
    FastAPI dependency for authenticated endpoints. Declares its own
    `get_current_user` sub-dependency (rather than reading request.state)
    so FastAPI's dependency graph -- not parameter ordering -- guarantees
    the user is resolved before this ever runs, and keys by the real user
    id (more accurate than IP behind shared NAT/proxies).

    Imported lazily to avoid a circular import (deps.py doesn't import
    this module).
    """
    from fastapi import Depends as _Depends

    from app.api.deps import get_current_user
    from app.db.models.user import User

    def dependency(current_user: User = _Depends(get_current_user)) -> None:
        db = SessionLocal()
        try:
            limiter.check(db, f"user:{current_user.id}")
        finally:
            db.close()

    return dependency
