"""
CSRF protection via the double-submit-cookie pattern.

Because auth uses an HTTP-only cookie (browsers attach it automatically to
same-origin AND cross-origin requests), a malicious page on another origin
could otherwise trigger a state-changing request that the browser
"helpfully" attaches valid session credentials to. SameSite=strict on the
session cookie already blocks the vast majority of that (see
core/security.py / api/auth.py), but this middleware adds an explicit,
independent second layer: any POST/PUT/PATCH/DELETE that carries a session
cookie must also echo back a matching CSRF token in a request header. A
cross-site attacker can trigger the browser to *send* cookies, but cannot
*read* this app's cookies to learn the token value to put in the header
(browsers enforce that), so the two checks fail independently of each
other -- defense in depth rather than redundant.

Login/register are exempt: no session exists yet at that point, so there
is nothing to forge into. The CSRF cookie is minted by /auth/login and
/auth/register themselves once the session is established.
"""
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

from app.core.config import get_settings

_SAFE_METHODS = {"GET", "HEAD", "OPTIONS", "TRACE"}
_EXEMPT_PATHS = {"/api/auth/login", "/api/auth/register"}

settings = get_settings()


class CSRFMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        if request.method in _SAFE_METHODS or request.url.path in _EXEMPT_PATHS:
            return await call_next(request)

        session_cookie = request.cookies.get(settings.COOKIE_NAME)
        if not session_cookie:
            # No session cookie -> nothing to forge (this request will hit
            # the normal 401 from get_current_user, not a CSRF check).
            return await call_next(request)

        csrf_cookie = request.cookies.get(settings.CSRF_COOKIE_NAME)
        csrf_header = request.headers.get(settings.CSRF_HEADER_NAME)

        if not csrf_cookie or not csrf_header or csrf_cookie != csrf_header:
            return JSONResponse(
                status_code=403,
                content={"detail": "CSRF token missing or invalid."},
            )

        return await call_next(request)
