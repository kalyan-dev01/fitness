import json

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from app.ai.provider_manager import NoAvailableProviderError, ProviderManager
from app.ai.provider_base import ProviderCallError
from app.ai.system_prompts.coach_v1 import get_current_system_prompt
from app.api.deps import get_current_user
from app.core.config import get_settings
from app.core.rate_limit import ai_rate_limiter, rate_limit_by_user_or_ip
from app.db.models.ai_conversation import AIConversation, AIMessage, MessageRole
from app.db.models.user import User
from app.db.session import get_db

_ai_rate_limit_dep = Depends(rate_limit_by_user_or_ip(ai_rate_limiter))
_settings = get_settings()
from app.schemas.coach import (
    AIConversationOut,
    CoachMessageCreate,
    CoachMessageOut,
    ParseFoodRequest,
    ParseFoodResponse,
)
from app.services.context_builder import build_context
from app.services.food_parser import parse_food_text

router = APIRouter(prefix="/coach", tags=["coach"])

UNAVAILABLE_MESSAGE = (
    "AI Coach is temporarily unavailable right now. Your food, workout, "
    "weight, and water logging all still work as normal — try asking me "
    "again in a bit."
)


def _get_or_create_conversation(db: Session, user_id, conversation_id) -> AIConversation:
    if conversation_id:
        conversation = db.scalar(
            select(AIConversation).where(
                AIConversation.id == conversation_id, AIConversation.user_id == user_id
            )
        )
        if conversation is None:
            raise HTTPException(status.HTTP_404_NOT_FOUND, "Conversation not found")
        return conversation

    conversation = AIConversation(user_id=user_id)
    db.add(conversation)
    db.flush()
    return conversation


def _trim_old_messages(db: Session, conversation_id) -> None:
    """
    Bound how many AIMessage rows a single conversation can accumulate.

    Note this is a *storage* control, not a token-usage control: the coach
    already only ever sends the current question plus a freshly built
    CoachContext snapshot to the AI provider (see context_builder.py) --
    it never replays prior conversation turns into the prompt, so token
    usage per request was already bounded regardless of conversation
    length. Without this, though, ai_messages rows grow without limit for
    a long-lived user, which is a real (if slower) storage problem and
    makes `GET /coach/conversations` (which eagerly loads every message)
    increasingly expensive. Oldest messages beyond the cap are dropped;
    this is a simple retention cap rather than a summarization pipeline --
    summarizing would preserve more context but adds a second AI call
    (cost/latency/failure surface) this pass didn't implement.
    """
    max_messages = _settings.AI_MAX_STORED_MESSAGES_PER_CONVERSATION
    count = db.scalar(
        select(func.count(AIMessage.id)).where(AIMessage.conversation_id == conversation_id)
    )
    if count is None or count < max_messages:
        return
    overflow = count - max_messages + 1  # +1 to make room for the new message
    oldest_ids = db.scalars(
        select(AIMessage.id)
        .where(AIMessage.conversation_id == conversation_id)
        .order_by(AIMessage.created_at.asc())
        .limit(overflow)
    ).all()
    if oldest_ids:
        db.query(AIMessage).filter(AIMessage.id.in_(oldest_ids)).delete(synchronize_session=False)


@router.post("/message", response_model=CoachMessageOut)
async def send_message(
    payload: CoachMessageCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    _rate_limit: None = _ai_rate_limit_dep,
):
    conversation = _get_or_create_conversation(db, current_user.id, payload.conversation_id)

    db.add(
        AIMessage(
            conversation_id=conversation.id, user_id=current_user.id,
            role=MessageRole.USER, content=payload.message,
        )
    )
    _trim_old_messages(db, conversation.id)
    db.commit()

    context = build_context(db, current_user, payload.message)
    system_prompt = f"{get_current_system_prompt()}\n\nContext:\n{context.as_prompt_text()}"

    manager = ProviderManager(db, current_user.id)
    try:
        result = await manager.generate(
            payload.message,
            system_prompt=system_prompt,
            explicit_provider_id=payload.provider_id,
        )
    except NoAvailableProviderError:
        db.add(
            AIMessage(
                conversation_id=conversation.id, user_id=current_user.id,
                role=MessageRole.ASSISTANT, content=UNAVAILABLE_MESSAGE,
                error_detail="No available AI provider",
            )
        )
        db.commit()
        return CoachMessageOut(
            conversation_id=conversation.id, reply=UNAVAILABLE_MESSAGE,
            provider_name=None, model=None, ai_unavailable=True,
        )
    except ProviderCallError as exc:
        # A real, non-fallback-eligible error (e.g. malformed request) —
        # surface it plainly rather than pretending it's a generic outage.
        db.add(
            AIMessage(
                conversation_id=conversation.id, user_id=current_user.id,
                role=MessageRole.ASSISTANT, content=UNAVAILABLE_MESSAGE,
                error_detail=exc.error.message,
            )
        )
        db.commit()
        return CoachMessageOut(
            conversation_id=conversation.id, reply=UNAVAILABLE_MESSAGE,
            provider_name=None, model=None, ai_unavailable=True,
        )

    token_usage = json.dumps(
        {"input_tokens": result.input_tokens, "output_tokens": result.output_tokens}
    )
    db.add(
        AIMessage(
            conversation_id=conversation.id, user_id=current_user.id,
            role=MessageRole.ASSISTANT, content=result.text,
            provider_name=result.provider_name, model=result.model,
            token_usage_json=token_usage, latency_ms=result.latency_ms,
        )
    )
    db.commit()

    return CoachMessageOut(
        conversation_id=conversation.id, reply=result.text,
        provider_name=result.provider_name, model=result.model,
    )


@router.get("/conversations", response_model=list[AIConversationOut])
def list_conversations(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    conversations = db.scalars(
        select(AIConversation)
        .options(selectinload(AIConversation.messages))
        .where(AIConversation.user_id == current_user.id)
        .order_by(AIConversation.created_at.desc())
    ).all()
    return list(conversations)


@router.get("/conversations/{conversation_id}", response_model=AIConversationOut)
def get_conversation(
    conversation_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    conversation = db.scalar(
        select(AIConversation)
        .options(selectinload(AIConversation.messages))
        .where(AIConversation.id == conversation_id, AIConversation.user_id == current_user.id)
    )
    if conversation is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Conversation not found")
    return conversation


@router.post("/parse-food", response_model=ParseFoodResponse)
async def parse_food(
    payload: ParseFoodRequest,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    _rate_limit: None = _ai_rate_limit_dep,
):
    try:
        items = await parse_food_text(db, current_user.id, payload.text)
    except NoAvailableProviderError:
        return ParseFoodResponse(items=[], ai_unavailable=True)
    except ProviderCallError:
        return ParseFoodResponse(items=[], ai_unavailable=True)
    return ParseFoodResponse(items=items)
