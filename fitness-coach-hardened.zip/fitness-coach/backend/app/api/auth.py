import secrets
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.core.config import get_settings
from app.core.rate_limit import auth_rate_limiter, rate_limit_by_key
from app.core.security import create_access_token, hash_password, verify_password
from app.db.models.user import User
from app.db.session import get_db
from app.schemas.auth import LoginRequest, RegisterRequest, UserOut

router = APIRouter(prefix="/auth", tags=["auth"])
_auth_rate_limit_dep = Depends(rate_limit_by_key(auth_rate_limiter))
settings = get_settings()


def _set_session_cookies(response: Response, user: User) -> None:
    token = create_access_token(
        subject=str(user.id),
        token_version=user.token_version,
        expires_delta=timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES),
    )
    response.set_cookie(
        key=settings.COOKIE_NAME,
        value=token,
        httponly=True,
        secure=settings.COOKIE_SECURE,
        samesite="strict",
        max_age=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        path="/",
    )
    # CSRF double-submit cookie: deliberately NOT httponly, since the
    # frontend JS must read it and echo it back in a request header for
    # every state-changing request. It carries no authority on its own —
    # an attacker who can read this cookie via XSS already owns the
    # session, so this only ever needs to defend against cross-site
    # request forgery (a browser sending the session cookie automatically
    # to a form/fetch on another origin without also being able to read
    # or set this cookie's value on our origin).
    response.set_cookie(
        key=settings.CSRF_COOKIE_NAME,
        value=secrets.token_urlsafe(32),
        httponly=False,
        secure=settings.COOKIE_SECURE,
        samesite="strict",
        max_age=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        path="/",
    )


def _clear_session_cookies(response: Response) -> None:
    response.delete_cookie(settings.COOKIE_NAME, path="/")
    response.delete_cookie(settings.CSRF_COOKIE_NAME, path="/")


@router.post("/register", response_model=UserOut, status_code=status.HTTP_201_CREATED)
def register(
    payload: RegisterRequest,
    response: Response,
    db: Session = Depends(get_db),
    _rate_limit: None = _auth_rate_limit_dep,
):
    existing = db.scalar(select(User).where(User.email == payload.email))
    if existing is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email already registered")

    user = User(email=payload.email, password_hash=hash_password(payload.password))
    db.add(user)
    db.commit()
    db.refresh(user)

    _set_session_cookies(response, user)
    return user


@router.post("/login", response_model=UserOut)
def login(
    payload: LoginRequest,
    response: Response,
    db: Session = Depends(get_db),
    _rate_limit: None = _auth_rate_limit_dep,
):
    user = db.scalar(select(User).where(User.email == payload.email))
    invalid = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid email or password"
    )
    # Always run the hash comparison, even for an unknown email, using a
    # fixed dummy hash — otherwise "unknown email" returns faster than
    # "wrong password" and leaks which emails are registered (account
    # enumeration via timing).
    password_hash = user.password_hash if user is not None else pwd_context_dummy_hash()
    password_ok = verify_password(payload.password, password_hash)

    if user is None or user.deleted_at is not None or not password_ok:
        raise invalid
    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Account disabled")

    _set_session_cookies(response, user)
    return user


_DUMMY_HASH_CACHE: list[str] = []


def pwd_context_dummy_hash() -> str:
    """A precomputed bcrypt hash of a random value, used only to burn the
    same amount of CPU time as a real verify_password call when the
    account doesn't exist. Computed once per process, not once per
    request, since hashing is expensive."""
    if not _DUMMY_HASH_CACHE:
        _DUMMY_HASH_CACHE.append(hash_password(secrets.token_urlsafe(24)))
    return _DUMMY_HASH_CACHE[0]


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(
    response: Response,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    # Bumping token_version invalidates THIS token (and any other token
    # issued to this user) immediately, server-side -- not just deleting
    # the cookie client-side. A stolen/copied token stops working the
    # moment the legitimate user logs out.
    current_user.token_version += 1
    db.add(current_user)
    db.commit()
    _clear_session_cookies(response)


@router.post("/logout-everywhere", status_code=status.HTTP_204_NO_CONTENT)
def logout_everywhere(
    response: Response,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Same mechanism as /logout -- kept as a distinct, discoverable
    endpoint for a "log out of all devices" security control (e.g. after
    a suspected compromise), and clears the cookies on this device too."""
    current_user.token_version += 1
    db.add(current_user)
    db.commit()
    _clear_session_cookies(response)


@router.get("/me", response_model=UserOut)
def me(current_user: User = Depends(get_current_user)):
    return current_user
