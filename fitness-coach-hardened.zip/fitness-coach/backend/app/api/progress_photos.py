import shutil
import tempfile
import uuid
from datetime import date as date_type
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile, status
from fastapi.responses import Response
from PIL import Image, UnidentifiedImageError
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.core.config import get_settings
from app.core.rate_limit import rate_limit_by_user_or_ip, upload_rate_limiter
from app.db.models.progress_photo import PhotoAngle, ProgressPhoto
from app.db.models.user import User
from app.db.session import get_db
from app.schemas.progress_photo import ProgressPhotoOut

router = APIRouter(prefix="/progress-photos", tags=["progress-photos"])
settings = get_settings()

_upload_rate_limit_dep = Depends(rate_limit_by_user_or_ip(upload_rate_limiter))

# Declared client Content-Type is advisory only (trivially spoofable) --
# actual validation happens by decoding the file with Pillow below and
# checking the format it detects, which reads real magic bytes/structure
# rather than trusting a header.
ALLOWED_CONTENT_TYPES = {"image/jpeg", "image/png", "image/webp"}
_PIL_FORMAT_TO_EXTENSION = {"JPEG": ".jpg", "PNG": ".png", "WEBP": ".webp"}
_CHUNK_SIZE = 1024 * 1024  # 1MB read chunks while streaming to disk


def _storage_root() -> Path:
    root = Path(settings.PROGRESS_PHOTO_STORAGE_DIR).resolve()
    root.mkdir(parents=True, exist_ok=True)
    return root


def _user_dir(user_id: uuid.UUID) -> Path:
    d = _storage_root() / str(user_id)
    d.mkdir(parents=True, exist_ok=True)
    return d


@router.get("", response_model=list[ProgressPhotoOut])
def list_photos(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    photos = db.scalars(
        select(ProgressPhoto)
        .where(ProgressPhoto.user_id == current_user.id)
        .order_by(ProgressPhoto.date.desc())
    ).all()
    return list(photos)


@router.post("", response_model=ProgressPhotoOut, status_code=status.HTTP_201_CREATED)
async def upload_photo(
    date: date_type = Form(...),
    angle: PhotoAngle = Form(...),
    notes: str | None = Form(default=None),
    file: UploadFile = File(...),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
    _rate_limit: None = _upload_rate_limit_dep,
):
    """
    Streams the upload to a private temp file in fixed-size chunks,
    enforcing the size cap WHILE reading -- a malicious client sending
    gigabytes of data is stopped as soon as the limit is crossed, instead
    of first buffering the whole thing into RAM via `await file.read()`
    (the old behavior, which let a single oversized upload exhaust
    backend memory and take the process down).

    File type is validated by actually decoding the image with Pillow
    (real magic-byte/structure validation), not by trusting the
    client-supplied Content-Type header or filename extension. A
    malformed or corrupt "image" that isn't decodable is rejected before
    it's ever moved into permanent storage.

    The final filename is always server-generated (uuid4 + the extension
    Pillow itself detected) -- nothing derived from client input reaches
    the filesystem path, which also rules out path traversal.
    """
    if file.content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status.HTTP_400_BAD_REQUEST,
            f"Unsupported file type: {file.content_type}. Use JPEG, PNG, or WebP.",
        )

    max_bytes = settings.PROGRESS_PHOTO_MAX_BYTES
    tmp_dir = _storage_root() / ".tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)

    bytes_written = 0
    tmp_fd, tmp_path_str = tempfile.mkstemp(dir=tmp_dir, prefix="upload-", suffix=".part")
    tmp_path = Path(tmp_path_str)
    try:
        with open(tmp_fd, "wb") as out:
            while True:
                chunk = await file.read(_CHUNK_SIZE)
                if not chunk:
                    break
                bytes_written += len(chunk)
                if bytes_written > max_bytes:
                    raise HTTPException(
                        status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                        f"File too large (max {max_bytes // (1024 * 1024)}MB)",
                    )
                out.write(chunk)

        if bytes_written == 0:
            raise HTTPException(status.HTTP_400_BAD_REQUEST, "Empty file upload")

        # Real content validation: decode + verify, then re-open to get a
        # usable format string (Image.verify() leaves the file object in a
        # state that can't be used for anything else afterwards).
        try:
            with Image.open(tmp_path) as img:
                img.verify()
            with Image.open(tmp_path) as img:
                detected_format = img.format
                img.load()  # force full decode -- catches truncated/malformed data
        except (UnidentifiedImageError, OSError, ValueError) as exc:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                "File is not a valid, decodable image.",
            ) from exc

        extension = _PIL_FORMAT_TO_EXTENSION.get(detected_format or "")
        if extension is None:
            raise HTTPException(
                status.HTTP_400_BAD_REQUEST,
                f"Unsupported image format: {detected_format}. Use JPEG, PNG, or WebP.",
            )

        filename = f"{uuid.uuid4()}{extension}"
        final_path = _user_dir(current_user.id) / filename
        shutil.move(str(tmp_path), str(final_path))
        # shutil.move succeeded -- tmp_path no longer exists, skip the
        # finally-block cleanup attempt for it.
        tmp_path = None  # type: ignore[assignment]
    finally:
        if tmp_path is not None:
            tmp_path.unlink(missing_ok=True)

    content_type = {v: k for k, v in {
        "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp",
    }.items()}[extension]

    photo = ProgressPhoto(
        user_id=current_user.id,
        date=date,
        angle=angle,
        storage_key=f"{current_user.id}/{filename}",
        content_type=content_type,
        notes=notes,
    )
    db.add(photo)
    db.commit()
    db.refresh(photo)
    return photo


def _get_owned(db: Session, user_id: uuid.UUID, photo_id: str) -> ProgressPhoto:
    photo = db.scalar(
        select(ProgressPhoto).where(
            ProgressPhoto.id == photo_id, ProgressPhoto.user_id == user_id
        )
    )
    if photo is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Photo not found")
    return photo


def _resolve_within_storage_root(storage_key: str) -> Path:
    """
    Defense in depth: storage_key is always server-generated (see
    upload_photo above) and never derived from client input, so this
    should never actually resolve outside the storage root. This check
    exists anyway as a second, independent guarantee against path
    traversal in case a future change ever lets a less-trusted value into
    storage_key.
    """
    root = _storage_root()
    candidate = (root / storage_key).resolve()
    if candidate != root and root not in candidate.parents:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Photo not found")
    return candidate


@router.get("/{photo_id}/image")
def get_photo_image(
    photo_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """
    The only route that ever returns image bytes. Ownership is checked
    before touching the filesystem -- there is no public URL for any
    progress photo, by design.
    """
    photo = _get_owned(db, current_user.id, photo_id)
    file_path = _resolve_within_storage_root(photo.storage_key)
    if not file_path.is_file():
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Photo file missing on disk")

    return Response(
        content=file_path.read_bytes(),
        media_type=photo.content_type,
        headers={
            # Progress photos are private per-user data -- never let a
            # shared/browser cache or CDN store a copy that another
            # session on the same machine (or an intermediary cache)
            # could later serve back.
            "Cache-Control": "private, no-store",
        },
    )


@router.delete("/{photo_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_photo(
    photo_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    photo = _get_owned(db, current_user.id, photo_id)
    file_path = _resolve_within_storage_root(photo.storage_key)
    file_path.unlink(missing_ok=True)
    db.delete(photo)
    db.commit()
