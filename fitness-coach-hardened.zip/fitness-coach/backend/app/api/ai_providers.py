import uuid
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.ai.provider_manager import _now
from app.ai.registry import PROVIDER_DEFAULTS, build_provider
from app.api.deps import get_current_user
from app.core.security import decrypt_secret, encrypt_secret, mask_secret
from app.db.models.ai_provider import AIProvider, AIProviderCredential, AIProviderUsage
from app.db.models.user import User
from app.db.session import get_db
from app.schemas.ai_provider import (
    AIProviderCreate,
    AIProviderOut,
    AIProviderUpdate,
    ProviderUsageDayOut,
    ProviderUsageOut,
    TestConnectionOut,
)

router = APIRouter(prefix="/ai/providers", tags=["ai-providers"])


def _to_out(provider: AIProvider) -> AIProviderOut:
    return AIProviderOut(
        id=provider.id,
        name=provider.name,
        display_name=provider.display_name,
        base_url=provider.base_url,
        model=provider.model,
        is_enabled=provider.is_enabled,
        is_free_only=provider.is_free_only,
        priority=provider.priority,
        auto_fallback_enabled=provider.auto_fallback_enabled,
        key_hint=provider.credential.key_hint if provider.credential else None,
        health=provider.health,
    )


def _get_owned(db: Session, user_id: uuid.UUID, provider_id: str) -> AIProvider:
    provider = db.scalar(
        select(AIProvider)
        .options(selectinload(AIProvider.credential), selectinload(AIProvider.health))
        .where(AIProvider.id == provider_id, AIProvider.user_id == user_id)
    )
    if provider is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Provider not found")
    return provider


@router.get("", response_model=list[AIProviderOut])
def list_providers(
    current_user: User = Depends(get_current_user), db: Session = Depends(get_db)
):
    providers = db.scalars(
        select(AIProvider)
        .options(selectinload(AIProvider.credential), selectinload(AIProvider.health))
        .where(AIProvider.user_id == current_user.id)
        .order_by(AIProvider.priority)
    ).all()
    return [_to_out(p) for p in providers]


@router.post("", response_model=AIProviderOut, status_code=status.HTTP_201_CREATED)
def create_provider(
    payload: AIProviderCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    # Prevent duplicate provider entries: the same provider `name` (e.g.
    # "gemini") configured twice for one user produces confusing UI state
    # and, since both compete on priority, unpredictable fallback order —
    # there is never a legitimate reason for a user to have two.
    existing = db.scalar(
        select(AIProvider).where(
            AIProvider.user_id == current_user.id, AIProvider.name == payload.name
        )
    )
    if existing is not None:
        raise HTTPException(
            status.HTTP_409_CONFLICT,
            f"A '{payload.name}' provider is already configured. Edit the existing "
            "entry instead of adding a duplicate.",
        )

    defaults = PROVIDER_DEFAULTS.get(payload.name)

    # Cost-safety guardrail (spec 39): paid providers must never be created
    # with automatic fallback pre-enabled, regardless of what the client sends.
    is_free_only = payload.is_free_only if defaults is None else defaults.is_free_only
    auto_fallback = payload.auto_fallback_enabled and is_free_only

    provider = AIProvider(
        user_id=current_user.id,
        name=payload.name,
        display_name=payload.display_name or (defaults.display_name if defaults else payload.name),
        base_url=payload.base_url or (defaults.base_url if defaults else None),
        model=payload.model or (defaults.default_model if defaults else None),
        is_free_only=is_free_only,
        priority=payload.priority,
        auto_fallback_enabled=auto_fallback,
    )
    db.add(provider)
    db.flush()  # get provider.id before creating the credential row

    encrypted = encrypt_secret(payload.api_key)
    db.add(
        AIProviderCredential(
            provider_id=provider.id,
            encrypted_api_key=encrypted,
            key_hint=mask_secret(payload.api_key),
        )
    )
    db.commit()

    return _to_out(_get_owned(db, current_user.id, str(provider.id)))


@router.put("/{provider_id}", response_model=AIProviderOut)
def update_provider(
    provider_id: str,
    payload: AIProviderUpdate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    provider = _get_owned(db, current_user.id, provider_id)

    for field in ("display_name", "base_url", "model", "is_enabled", "priority"):
        value = getattr(payload, field)
        if value is not None:
            setattr(provider, field, value)

    # is_free_only and auto_fallback_enabled interact — never let a paid
    # provider end up with automatic fallback on.
    if payload.is_free_only is not None:
        provider.is_free_only = payload.is_free_only
    if payload.auto_fallback_enabled is not None:
        provider.auto_fallback_enabled = payload.auto_fallback_enabled and provider.is_free_only

    if payload.api_key:
        encrypted = encrypt_secret(payload.api_key)
        if provider.credential:
            provider.credential.encrypted_api_key = encrypted
            provider.credential.key_hint = mask_secret(payload.api_key)
        else:
            db.add(
                AIProviderCredential(
                    provider_id=provider.id,
                    encrypted_api_key=encrypted,
                    key_hint=mask_secret(payload.api_key),
                )
            )

    db.commit()
    return _to_out(_get_owned(db, current_user.id, provider_id))


@router.delete("/{provider_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_provider(
    provider_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    provider = _get_owned(db, current_user.id, provider_id)
    db.delete(provider)
    db.commit()


@router.post("/{provider_id}/activate", response_model=AIProviderOut)
def activate_provider(
    provider_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    provider = _get_owned(db, current_user.id, provider_id)
    provider.is_enabled = True
    db.commit()
    return _to_out(_get_owned(db, current_user.id, provider_id))


@router.post("/{provider_id}/disable", response_model=AIProviderOut)
def disable_provider(
    provider_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    provider = _get_owned(db, current_user.id, provider_id)
    provider.is_enabled = False
    db.commit()
    return _to_out(_get_owned(db, current_user.id, provider_id))


@router.post("/{provider_id}/test", response_model=TestConnectionOut)
async def test_provider_connection(
    provider_id: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    provider_row = _get_owned(db, current_user.id, provider_id)
    if provider_row.credential is None:
        raise HTTPException(status.HTTP_400_BAD_REQUEST, "No API key configured for this provider")

    api_key = decrypt_secret(provider_row.credential.encrypted_api_key)
    provider = build_provider(
        name=provider_row.name,
        base_url=provider_row.base_url,
        api_key=api_key,
        model=provider_row.model,
    )
    result = await provider.test_connection()

    from app.ai.provider_manager import ProviderManager  # local import avoids a cycle

    manager = ProviderManager(db, current_user.id)
    manager.update_health(
        provider_row,
        success=result.success,
        error_category=result.error.category.value if result.error else None,
        latency_ms=result.latency_ms,
        retry_after_seconds=result.error.retry_after_seconds if result.error else None,
    )
    db.commit()

    return TestConnectionOut(
        success=result.success,
        model=result.model,
        latency_ms=result.latency_ms,
        error_category=result.error.category.value if result.error else None,
        error_message=result.error.message if result.error else None,
    )


@router.get("/{provider_id}/usage", response_model=ProviderUsageOut)
def get_provider_usage(
    provider_id: str,
    days: int = 30,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    provider = _get_owned(db, current_user.id, provider_id)
    cutoff = _now().date() - timedelta(days=days)
    usage_rows = db.scalars(
        select(AIProviderUsage)
        .where(AIProviderUsage.provider_id == provider.id, AIProviderUsage.date >= cutoff)
        .order_by(AIProviderUsage.date.desc())
    ).all()

    return ProviderUsageOut(
        provider_id=provider.id,
        provider_name=provider.name,
        days=[
            ProviderUsageDayOut(
                date=str(u.date),
                requests=u.requests,
                successes=u.successes,
                failures=u.failures,
                input_tokens_approx=u.input_tokens_approx,
                output_tokens_approx=u.output_tokens_approx,
                avg_latency_ms=(round(u.total_latency_ms / u.requests) if u.requests else None),
            )
            for u in usage_rows
        ],
    )
