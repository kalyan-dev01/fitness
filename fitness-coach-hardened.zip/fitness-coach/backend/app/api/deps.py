import uuid

from fastapi import Cookie, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.security import decode_access_token
from app.db.models.user import User
from app.db.session import get_db

settings = get_settings()


def get_current_user(
    db: Session = Depends(get_db),
    session_token: str | None = Cookie(default=None, alias=settings.COOKIE_NAME),
) -> User:
    credentials_error = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Not authenticated",
    )
    if not session_token:
        raise credentials_error

    decoded = decode_access_token(session_token)
    if decoded is None:
        raise credentials_error

    try:
        user_id = uuid.UUID(decoded.subject)
    except ValueError as exc:
        raise credentials_error from exc

    user = db.get(User, user_id)
    if user is None or not user.is_active or user.deleted_at is not None:
        raise credentials_error

    # Revocation check: logout (and "log out everywhere") bump
    # user.token_version, which immediately invalidates every token issued
    # before that point, even ones an attacker may have stolen and that
    # haven't expired yet.
    if decoded.token_version != user.token_version:
        raise credentials_error

    return user
