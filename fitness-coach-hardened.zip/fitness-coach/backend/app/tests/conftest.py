"""
These tests assume a reachable PostgreSQL instance (docker-compose provides
one). Set TEST_DATABASE_URL to point at a disposable test database — never
run tests against production data.
"""
import os

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

os.environ.setdefault(
    "DATABASE_URL",
    os.environ.get(
        "TEST_DATABASE_URL",
        "postgresql+psycopg2://fitness:fitness@localhost:5432/fitness_coach_test",
    ),
)
os.environ.setdefault("FIELD_ENCRYPTION_KEY", "zxJhq2wQe8sSU2hM3n8vN1v6mZ8yqf4qk3l5m7p9q0A=")
os.environ.setdefault("JWT_SECRET", "test-secret")

from app.core.config import get_settings
from app.db.base import Base  # noqa: E402
from app.db import models  # noqa: E402, F401
from app.db.session import get_db  # noqa: E402
from app.main import app  # noqa: E402

_settings = get_settings()
engine = create_engine(os.environ["DATABASE_URL"])
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


@pytest.fixture(scope="session", autouse=True)
def _create_schema():
    Base.metadata.create_all(bind=engine)
    yield
    Base.metadata.drop_all(bind=engine)


@pytest.fixture(autouse=True)
def _reset_rate_limiter():
    from sqlalchemy import text

    from app.db.session import SessionLocal

    def _clear():
        db = SessionLocal()
        try:
            db.execute(text("DELETE FROM rate_limit_counters"))
            db.commit()
        except Exception:
            db.rollback()
        finally:
            db.close()

    _clear()
    yield
    _clear()


@pytest.fixture()
def db_session():
    session = TestingSessionLocal()
    try:
        yield session
    finally:
        session.rollback()
        session.close()


@pytest.fixture()
def client(db_session):
    def _override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = _override_get_db
    with _CSRFAutoHeaderClient(app) as c:
        yield c
    app.dependency_overrides.clear()


class _CSRFAutoHeaderClient(TestClient):
    """
    A real browser's JS reads the (deliberately non-httponly) CSRF cookie
    and echoes it back in a header on every state-changing request -- see
    core/csrf.py. TestClient has no JS layer to do that, so this thin
    wrapper reproduces exactly that behavior for every test, instead of
    every single test in the suite having to know about CSRF headers.
    """

    def request(self, method, url, **kwargs):
        headers = dict(kwargs.pop("headers", None) or {})
        csrf_cookie = self.cookies.get(_settings.CSRF_COOKIE_NAME)
        if csrf_cookie and _settings.CSRF_HEADER_NAME not in headers:
            headers[_settings.CSRF_HEADER_NAME] = csrf_cookie
        kwargs["headers"] = headers
        return super().request(method, url, **kwargs)
