"""
Tests for the security controls added in the production-hardening pass:
CSRF (double-submit cookie), session revocation via token_version, and
that the rate limiter actually blocks past its threshold. The CSRF
auto-header behavior in conftest's client fixture is deliberately bypassed
in some tests here (using the raw httpx client / manual header removal)
to prove the middleware itself is doing the enforcing, not just that
"normal" requests happen to work.
"""
from app.core.config import get_settings

settings = get_settings()


def _register(client, email="csrf@example.com"):
    return client.post(
        "/api/auth/register", json={"email": email, "password": "correcthorse"}
    )


def test_state_changing_request_without_csrf_header_is_rejected(client):
    _register(client, email="csrf-missing@example.com")
    # Bypass the test client's auto-attached CSRF header to simulate a
    # cross-site attacker who has a victim's session cookie riding along
    # (via the browser) but cannot read the CSRF cookie's value.
    resp = client.post(
        "/api/weight",
        json={"date": "2026-09-01", "weight_kg": 70.0},
        headers={settings.CSRF_HEADER_NAME: ""},
    )
    assert resp.status_code == 403


def test_state_changing_request_with_wrong_csrf_header_is_rejected(client):
    _register(client, email="csrf-wrong@example.com")
    resp = client.post(
        "/api/weight",
        json={"date": "2026-09-01", "weight_kg": 70.0},
        headers={settings.CSRF_HEADER_NAME: "not-the-real-token"},
    )
    assert resp.status_code == 403


def test_state_changing_request_with_correct_csrf_header_succeeds(client):
    _register(client, email="csrf-correct@example.com")
    csrf_token = client.cookies.get(settings.CSRF_COOKIE_NAME)
    resp = client.post(
        "/api/weight",
        json={"date": "2026-09-01", "weight_kg": 70.0},
        headers={settings.CSRF_HEADER_NAME: csrf_token},
    )
    assert resp.status_code in (200, 201)


def test_get_requests_do_not_require_csrf_header(client):
    _register(client, email="csrf-get@example.com")
    resp = client.get("/api/weight", headers={settings.CSRF_HEADER_NAME: ""})
    assert resp.status_code == 200


def test_logout_revokes_session_token(client):
    _register(client, email="revoke@example.com")
    me_before = client.get("/api/auth/me")
    assert me_before.status_code == 200

    old_session_cookie = client.cookies.get(settings.COOKIE_NAME)
    client.post("/api/auth/logout")

    # Simulate an attacker replaying a copy of the old, valid-looking JWT
    # after the legitimate user logged out -- it must no longer work, even
    # though the token itself hasn't expired yet.
    client.cookies.set(settings.COOKIE_NAME, old_session_cookie)
    me_after = client.get("/api/auth/me")
    assert me_after.status_code == 401


def test_readiness_endpoint_reports_database_ok(client):
    resp = client.get("/health/ready")
    assert resp.status_code == 200
    assert resp.json()["database"] == "ok"


def test_liveness_endpoint_does_not_touch_database(client):
    resp = client.get("/health/live")
    assert resp.status_code == 200
    assert resp.json()["status"] == "ok"
