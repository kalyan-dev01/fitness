import logging
import uuid

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import text
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.api import (
    ai_providers,
    analytics,
    auth,
    coach,
    custom_foods,
    exercises,
    export,
    foods,
    goals,
    meals,
    notification_settings,
    profile,
    progress_photos,
    progression,
    recipes,
    reports,
    water,
    weight,
    workouts,
)
from app.core.config import get_settings
from app.core.csrf import CSRFMiddleware
from app.core.logging import configure_logging
from app.core.security_headers import SecurityHeadersMiddleware
from app.db.session import SessionLocal, dispose_engine

settings = get_settings()
configure_logging(debug=settings.DEBUG)
logger = logging.getLogger(__name__)

app = FastAPI(title=settings.APP_NAME, debug=settings.DEBUG)


@app.middleware("http")
async def add_request_id(request: Request, call_next):
    """
    Every request gets a correlation id: generated from the incoming
    X-Request-ID header when a reverse proxy already set one (Caddy can be
    configured to do this), otherwise minted here. Echoed back in the
    response and attached to request.state so any handler/log line during
    this request can include it -- makes it possible to trace one user's
    request across app logs, AI provider error logs, and DB error logs.
    """
    request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
    request.state.request_id = request_id
    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id
    return response


app.add_middleware(SecurityHeadersMiddleware)
app.add_middleware(CSRFMiddleware)
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.FRONTEND_ORIGIN],
    allow_credentials=True,  # required: session lives in an HTTP-only cookie
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(StarletteHTTPException)
async def http_exception_handler(request: Request, exc: StarletteHTTPException):
    # Consistent error shape for every raised HTTPException across the
    # API, with the request id attached so a user-reported error can be
    # matched to server-side logs.
    request_id = getattr(request.state, "request_id", None)
    return JSONResponse(
        status_code=exc.status_code,
        content={"detail": exc.detail, "request_id": request_id},
        headers=getattr(exc, "headers", None),
    )


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    request_id = getattr(request.state, "request_id", None)
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content={"detail": exc.errors(), "request_id": request_id},
    )


@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    # Last-resort safety net: never let a raw traceback or exception
    # message reach the client (stack traces / DB internals / provider
    # error text can leak implementation details). Full detail still goes
    # to the server-side log, tagged with the request id for correlation.
    request_id = getattr(request.state, "request_id", None)
    logger.exception("Unhandled exception (request_id=%s)", request_id)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "detail": "An unexpected error occurred. Please try again." if not settings.DEBUG else str(exc),
            "request_id": request_id,
        },
    )


app.include_router(auth.router, prefix="/api")
app.include_router(profile.router, prefix="/api")
app.include_router(goals.router, prefix="/api")
app.include_router(foods.router, prefix="/api")
app.include_router(custom_foods.router, prefix="/api")
app.include_router(recipes.router, prefix="/api")
app.include_router(meals.router, prefix="/api")
app.include_router(weight.router, prefix="/api")
app.include_router(water.router, prefix="/api")
app.include_router(exercises.router, prefix="/api")
app.include_router(workouts.router, prefix="/api")
app.include_router(progression.router, prefix="/api")
app.include_router(ai_providers.router, prefix="/api")
app.include_router(coach.router, prefix="/api")
app.include_router(reports.router, prefix="/api")
app.include_router(analytics.router, prefix="/api")
app.include_router(progress_photos.router, prefix="/api")
app.include_router(notification_settings.router, prefix="/api")
app.include_router(export.router, prefix="/api")


@app.get("/api/health")
def health():
    """Kept for backward compatibility with anything already polling this
    path; behaves the same as /health/live (process-is-up only, no DB
    check) -- use /health/ready for a check that actually verifies the
    database is reachable."""
    return {"status": "ok", "app": settings.APP_NAME, "env": settings.ENV}


@app.get("/health/live")
def health_live():
    """
    Liveness: is the process itself running and able to respond at all?
    Deliberately does NOT touch the database -- a liveness probe that
    depends on an external service can cause an orchestrator to kill and
    restart a perfectly healthy process just because Postgres had a
    momentary blip, which makes outages worse, not better.
    """
    return {"status": "ok"}


@app.get("/health/ready")
def health_ready():
    """
    Readiness: can this instance actually serve real traffic right now?
    Verifies Postgres connectivity with a real round-trip query. Used by
    Docker Compose healthchecks and should be what any load
    balancer/reverse proxy uses to decide whether to route traffic here --
    a backend that reports "ready" while Postgres is unreachable would
    otherwise accept requests it cannot actually fulfil.
    """
    db = SessionLocal()
    try:
        db.execute(text("SELECT 1"))
    except Exception as exc:  # noqa: BLE001 - readiness probe: any DB failure means "not ready"
        logger.warning("Readiness check failed: database unreachable (%s)", exc)
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content={"status": "not_ready", "database": "unreachable"},
        )
    finally:
        db.close()
    return {"status": "ready", "database": "ok"}


@app.on_event("startup")
def on_startup():
    logger.info("Starting %s (env=%s)", settings.APP_NAME, settings.ENV)


@app.on_event("shutdown")
def on_shutdown():
    logger.info("Shutting down %s", settings.APP_NAME)
    dispose_engine()
