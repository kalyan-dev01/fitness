from collections.abc import Generator

from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker

from app.core.config import get_settings

settings = get_settings()

# pool_pre_ping avoids handing out dead connections after e.g. a Postgres
# restart. pool_recycle proactively retires connections before any
# infrastructure-level idle timeout (load balancers, pgbouncer, cloud DB
# providers) can close them out from under us. Explicit pool_size/
# max_overflow/pool_timeout keep a burst of concurrent requests from
# either exhausting Postgres's own max_connections or hanging forever
# waiting for a pool slot -- both configurable per deployment.
engine = create_engine(
    settings.DATABASE_URL,
    pool_pre_ping=True,
    pool_size=settings.DB_POOL_SIZE,
    max_overflow=settings.DB_MAX_OVERFLOW,
    pool_timeout=settings.DB_POOL_TIMEOUT_SECONDS,
    pool_recycle=settings.DB_POOL_RECYCLE_SECONDS,
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def dispose_engine() -> None:
    """Called from the app shutdown hook so in-flight connections are
    closed cleanly instead of being cut off mid-transaction when the
    container receives SIGTERM."""
    engine.dispose()
