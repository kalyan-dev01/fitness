from sqlalchemy import Boolean, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.base import Base, SoftDeleteMixin, TimestampMixin, UUIDPK


class User(UUIDPK, TimestampMixin, SoftDeleteMixin, Base):
    __tablename__ = "users"

    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    # Bumped on logout (and can be bumped on password change / "log out
    # everywhere") to invalidate every previously issued JWT for this user
    # in one step, without a server-side session table per token. Every
    # access token embeds the token_version it was issued with; deps.py
    # rejects any token whose version doesn't match the current value.
    token_version: Mapped[int] = mapped_column(Integer, default=0, server_default="0")

    profile: Mapped["UserProfile"] = relationship(
        back_populates="user", uselist=False, cascade="all, delete-orphan"
    )
    goals: Mapped[list["Goal"]] = relationship(
        back_populates="user", cascade="all, delete-orphan"
    )
