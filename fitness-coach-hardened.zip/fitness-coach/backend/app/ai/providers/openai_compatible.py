"""
Shared implementation for any provider exposing an OpenAI-style
/chat/completions endpoint. Provider-specific quirks (headers, model
listing endpoints, usage reporting) are handled by thin subclasses.
"""
import asyncio
import logging
import random
import time

import httpx

from app.ai.provider_base import (
    AIProvider,
    ErrorCategory,
    GenerationResult,
    ProviderCallError,
    ProviderError,
    TestConnectionResult,
)
from app.core.config import get_settings

logger = logging.getLogger(__name__)
_settings = get_settings()

_STATUS_TO_CATEGORY = {
    400: ErrorCategory.INVALID_REQUEST,
    401: ErrorCategory.INVALID_CREDENTIALS,
    403: ErrorCategory.PERMISSION_DENIED,
    408: ErrorCategory.TIMEOUT,
    429: ErrorCategory.RATE_LIMITED,
}

# Retrying these categories is safe -- the request itself wasn't the
# problem, the provider/network was transiently unavailable. Retrying
# INVALID_CREDENTIALS, PERMISSION_DENIED, or INVALID_REQUEST would just
# fail identically every time while burning latency (and, for paid
# providers, quota) on calls that can never succeed.
_RETRYABLE_CATEGORIES = {
    ErrorCategory.TIMEOUT,
    ErrorCategory.SERVER_ERROR,
    ErrorCategory.NETWORK_ERROR,
}

# Shared across every provider instance in this process: bounds how many
# AI HTTP calls are in flight at once regardless of how many concurrent
# app requests are being handled, so a request storm degrades to queueing
# behind this limit instead of opening unbounded outbound connections (and
# unbounded cost) all at once.
_concurrency_semaphore = asyncio.Semaphore(_settings.AI_MAX_CONCURRENT_REQUESTS)


def _categorize_http_error(status_code: int) -> ErrorCategory:
    if status_code in _STATUS_TO_CATEGORY:
        return _STATUS_TO_CATEGORY[status_code]
    if 500 <= status_code < 600:
        return ErrorCategory.SERVER_ERROR
    return ErrorCategory.UNKNOWN


class OpenAICompatibleProvider(AIProvider):
    def __init__(
        self,
        *,
        name: str,
        base_url: str,
        api_key: str,
        model: str,
        timeout_seconds: float | None = None,
        connect_timeout_seconds: float | None = None,
        extra_headers: dict | None = None,
    ):
        self.name = name
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.timeout_seconds = timeout_seconds or _settings.AI_REQUEST_TIMEOUT_SECONDS
        self.connect_timeout_seconds = (
            connect_timeout_seconds or _settings.AI_CONNECT_TIMEOUT_SECONDS
        )
        self.extra_headers = extra_headers or {}

    def _headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            **self.extra_headers,
        }

    async def _post_once(self, messages: list[dict], max_tokens: int | None) -> tuple[dict, int]:
        start = time.monotonic()
        payload: dict = {"model": self.model, "messages": messages}
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        timeout = httpx.Timeout(self.timeout_seconds, connect=self.connect_timeout_seconds)
        try:
            async with _concurrency_semaphore:
                async with httpx.AsyncClient(timeout=timeout) as client:
                    response = await client.post(
                        f"{self.base_url}/chat/completions",
                        headers=self._headers(),
                        json=payload,
                    )
        except httpx.TimeoutException as exc:
            raise ProviderCallError(
                ProviderError(ErrorCategory.TIMEOUT, f"{self.name} request timed out")
            ) from exc
        except httpx.RequestError as exc:
            raise ProviderCallError(
                ProviderError(ErrorCategory.NETWORK_ERROR, f"{self.name} unreachable: {exc}")
            ) from exc

        latency_ms = int((time.monotonic() - start) * 1000)

        if response.status_code >= 400:
            retry_after = response.headers.get("Retry-After")
            raise ProviderCallError(
                ProviderError(
                    category=_categorize_http_error(response.status_code),
                    message=f"{self.name} returned {response.status_code}: {response.text[:300]}",
                    retry_after_seconds=int(retry_after) if retry_after and retry_after.isdigit() else None,
                    status_code=response.status_code,
                )
            )

        return response.json(), latency_ms

    async def _chat_completion(
        self, messages: list[dict], *, max_tokens: int | None = None
    ) -> tuple[dict, int]:
        """
        Retries only categories in _RETRYABLE_CATEGORIES, with exponential
        backoff plus jitter (jitter avoids every concurrent request that
        hit the same transient failure retrying in lockstep and
        re-creating the exact spike that caused it). A provider-supplied
        Retry-After (e.g. on a 429) is honored as a floor on the delay
        rather than being ignored in favor of our own backoff schedule.
        """
        max_attempts = _settings.AI_MAX_RETRIES + 1
        last_error: ProviderCallError | None = None

        for attempt in range(1, max_attempts + 1):
            try:
                return await self._post_once(messages, max_tokens)
            except ProviderCallError as exc:
                last_error = exc
                if exc.error.category not in _RETRYABLE_CATEGORIES or attempt == max_attempts:
                    raise
                base_delay = _settings.AI_RETRY_BASE_DELAY_SECONDS * (2 ** (attempt - 1))
                delay = max(base_delay, exc.error.retry_after_seconds or 0)
                delay += random.uniform(0, base_delay)  # noqa: S311 - jitter, not security-sensitive
                logger.warning(
                    "%s call failed (%s), retrying attempt %d/%d in %.2fs",
                    self.name, exc.error.category.value, attempt, max_attempts, delay,
                )
                await asyncio.sleep(delay)

        # Unreachable in practice (the loop always returns or raises), but
        # keeps type-checkers/linters happy and fails safe if it ever is.
        assert last_error is not None
        raise last_error

    async def generate_text(
        self, prompt: str, *, system_prompt: str | None = None, max_tokens: int | None = None
    ) -> GenerationResult:
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})

        data, latency_ms = await self._chat_completion(messages, max_tokens=max_tokens)

        try:
            choice = data["choices"][0]
            text = choice["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise ProviderCallError(
                ProviderError(
                    ErrorCategory.UNKNOWN,
                    f"{self.name} returned an unexpected response shape: {exc}",
                )
            ) from exc

        if text is None:
            # "Thinking"-capable models (e.g. Gemini 3 series) can spend an
            # entire small max_tokens budget on internal reasoning tokens
            # and return content: null with finish_reason "length" -- not a
            # transport error, but not usable text either. Treat it as a
            # provider call failure so ProviderManager can fall back/report
            # it, rather than letting `None` propagate into callers that
            # assume a string (e.g. JSON parsing in food_parser.py).
            finish_reason = choice.get("finish_reason") if isinstance(choice, dict) else None
            raise ProviderCallError(
                ProviderError(
                    ErrorCategory.UNKNOWN,
                    f"{self.name} returned empty content (finish_reason={finish_reason}); "
                    "the model likely spent its token budget on internal reasoning -- "
                    "raise max_tokens for this provider/model.",
                )
            )

        usage = data.get("usage", {})
        return GenerationResult(
            text=text,
            model=data.get("model", self.model),
            input_tokens=usage.get("prompt_tokens"),
            output_tokens=usage.get("completion_tokens"),
            latency_ms=latency_ms,
        )

    async def generate_structured(
        self, prompt: str, *, json_schema: dict, system_prompt: str | None = None
    ) -> GenerationResult:
        # Prompt-engineered JSON mode -- not every OpenAI-compatible
        # provider reliably supports native structured output/function
        # calling through this generic adapter, so this stays the safe
        # common denominator here. Callers (e.g. food_parser.py) are
        # responsible for validating the returned text against a strict
        # Pydantic model and must not trust it blindly -- this method's
        # job is only to ask the model clearly and return raw text.
        instruction = (
            "Respond with ONLY valid JSON matching this schema, no prose, "
            f"no markdown fences: {json_schema}"
        )
        combined_system = f"{system_prompt}\n\n{instruction}" if system_prompt else instruction
        return await self.generate_text(prompt, system_prompt=combined_system)

    async def test_connection(self) -> TestConnectionResult:
        # Small, cheap request -- never a full-size call just to check
        # connectivity. 8 tokens is too small: "thinking" models spend a
        # variable amount of that budget on internal reasoning tokens
        # before ever emitting visible content, so a tiny cap reliably
        # produces content: null on those models even though the provider
        # itself is healthy. 64 is still cheap but gives reasoning models
        # room to actually answer "Hi".
        try:
            result = await self.generate_text("Hi", max_tokens=64)
            return TestConnectionResult(
                success=True, model=result.model, latency_ms=result.latency_ms
            )
        except ProviderCallError as exc:
            return TestConnectionResult(success=False, error=exc.error)
