"""
Known provider defaults. Base URLs and default models are starting points
only — per spec section 77/78, verify these against each provider's
current docs before relying on them; they change without notice.

Every entry here is OpenAI-compatible at the API-shape level. Anthropic is
deliberately NOT wired through this shared path (it uses its own native
message format) and is excluded from PROVIDER_DEFAULTS' automatic-fallback
eligibility regardless of configuration — see is_free_only handling in
ProviderManager.
"""
from dataclasses import dataclass

from app.ai.providers.openai_compatible import OpenAICompatibleProvider


@dataclass
class ProviderDefaults:
    display_name: str
    base_url: str
    default_model: str
    is_free_only: bool  # starting recommendation — user can override


PROVIDER_DEFAULTS: dict[str, ProviderDefaults] = {
    "gemini": ProviderDefaults(
        display_name="Google Gemini",
        base_url="https://generativelanguage.googleapis.com/v1beta/openai",
        # gemini-2.5-flash is retired. Verified current as of Sept 2026;
        # Google ships new Flash point releases every few months, so this
        # WILL go stale again — the per-provider "model" override in the
        # UI (see 3b) is the durable fix, not this constant.
        default_model="gemini-3.7-flash",
        is_free_only=True,
    ),
    "groq": ProviderDefaults(
        display_name="Groq",
        base_url="https://api.groq.com/openai/v1",
        # llama-3.3-70b-versatile was decommissioned by Groq on 2026-08-16.
        # Groq's own recommended replacement is openai/gpt-oss-120b.
        default_model="openai/gpt-oss-120b",
        is_free_only=True,
    ),
    "openrouter": ProviderDefaults(
        display_name="OpenRouter",
        base_url="https://openrouter.ai/api/v1",
        default_model="openrouter/auto",
        is_free_only=True,
    ),
    "mistral": ProviderDefaults(
        display_name="Mistral",
        base_url="https://api.mistral.ai/v1",
        default_model="mistral-small-latest",
        is_free_only=True,
    ),
    "ollama": ProviderDefaults(
        display_name="Ollama (local)",
        base_url="http://localhost:11434/v1",
        default_model="llama3",
        is_free_only=True,
    ),
    "anthropic": ProviderDefaults(
        display_name="Anthropic",
        base_url="https://api.anthropic.com/v1",  # not actually used — see note below
        default_model="claude-sonnet-4-6",
        is_free_only=False,  # paid — never eligible for automatic fallback
    ),
}


def build_provider(
    *, name: str, base_url: str | None, api_key: str, model: str | None
) -> OpenAICompatibleProvider:
    """
    Anthropic isn't OpenAI-compatible in its native form; if/when it's
    actually wired up, give it its own adapter class instead of forcing it
    through this path. It's included in PROVIDER_DEFAULTS purely so it
    shows up correctly in the manual-only provider list — calling
    build_provider("anthropic", ...) today will produce a client pointed
    at the wrong endpoint shape and should be replaced before Anthropic is
    actually enabled as a usable provider.
    """
    defaults = PROVIDER_DEFAULTS.get(name)
    resolved_base_url = base_url or (defaults.base_url if defaults else None)
    resolved_model = model or (defaults.default_model if defaults else None)
    if not resolved_base_url or not resolved_model:
        raise ValueError(f"No base_url/model configured or defaulted for provider '{name}'")

    return OpenAICompatibleProvider(
        name=name, base_url=resolved_base_url, api_key=api_key, model=resolved_model
    )
