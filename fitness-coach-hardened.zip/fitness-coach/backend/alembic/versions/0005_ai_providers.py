"""ai provider manager

Revision ID: 0005_ai_providers
Revises: 0004_workout
Create Date: 2026-10-08

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0005_ai_providers"
down_revision: Union[str, None] = "0004_workout"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    bind = op.get_bind()
    health_status_enum = postgresql.ENUM(
        "HEALTHY", "RATE_LIMITED", "QUOTA_EXHAUSTED", "INVALID_KEY",
        "UNAVAILABLE", "DISABLED", "UNKNOWN",
        name="provider_health_status_enum",
    )
    health_status_enum.create(bind, checkfirst=True)
    # SQLAlchemy's own before_create DDL event will try to CREATE TYPE
    # again when this enum object is reused as a column type below; that
    # second create is not checkfirst-safe, so without this flag a clean
    # database raises DuplicateObject. See spec note on enum creation.
    health_status_enum.create_type = False

    op.create_table(
        "ai_providers",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column("name", sa.String(60), nullable=False),
        sa.Column("display_name", sa.String(100), nullable=False),
        sa.Column("base_url", sa.String(300), nullable=True),
        sa.Column("model", sa.String(150), nullable=True),
        sa.Column("is_enabled", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("is_free_only", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("priority", sa.Integer(), nullable=False, server_default="100"),
        sa.Column("auto_fallback_enabled", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_ai_providers_user_id", "ai_providers", ["user_id"])

    op.create_table(
        "ai_provider_credentials",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "provider_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("ai_providers.id", ondelete="CASCADE"), nullable=False, unique=True,
        ),
        sa.Column("encrypted_api_key", sa.Text(), nullable=False),
        sa.Column("key_hint", sa.String(30), nullable=False),
    )

    op.create_table(
        "ai_provider_models",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "provider_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("ai_providers.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column("model_name", sa.String(150), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("last_refreshed_at", sa.DateTime(timezone=True), nullable=True),
    )
    op.create_index("ix_ai_provider_models_provider_id", "ai_provider_models", ["provider_id"])

    op.create_table(
        "ai_provider_health",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "provider_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("ai_providers.id", ondelete="CASCADE"), nullable=False, unique=True,
        ),
        sa.Column(
            "status", health_status_enum, nullable=False, server_default="UNKNOWN"
        ),
        sa.Column("last_tested_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_success_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_failure_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_latency_ms", sa.Integer(), nullable=True),
        sa.Column("last_error_category", sa.String(100), nullable=True),
        sa.Column("cooldown_until", sa.DateTime(timezone=True), nullable=True),
    )

    op.create_table(
        "ai_provider_usage",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "provider_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("ai_providers.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column("date", sa.Date(), nullable=False),
        sa.Column("requests", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("successes", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("failures", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("input_tokens_approx", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("output_tokens_approx", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("total_latency_ms", sa.Integer(), nullable=False, server_default="0"),
    )
    op.create_index("ix_ai_provider_usage_provider_id", "ai_provider_usage", ["provider_id"])
    op.create_unique_constraint(
        "uq_ai_provider_usage_provider_date", "ai_provider_usage", ["provider_id", "date"]
    )

    op.create_table(
        "ai_provider_events",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "provider_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("ai_providers.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column("event_type", sa.String(50), nullable=False),
        sa.Column("detail", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_ai_provider_events_provider_id", "ai_provider_events", ["provider_id"])


def downgrade() -> None:
    op.drop_table("ai_provider_events")
    op.drop_table("ai_provider_usage")
    op.drop_table("ai_provider_health")
    op.drop_table("ai_provider_models")
    op.drop_table("ai_provider_credentials")
    op.drop_table("ai_providers")
    op.execute("DROP TYPE IF EXISTS provider_health_status_enum")
