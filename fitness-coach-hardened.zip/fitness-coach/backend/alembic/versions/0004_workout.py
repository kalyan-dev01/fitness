"""workout tracking: exercises, sessions, sets

Revision ID: 0004_workout
Revises: 0003_weight_water
Create Date: 2026-10-01

"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0004_workout"
down_revision: Union[str, None] = "0003_weight_water"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    bind = op.get_bind()
    muscle_group_enum = postgresql.ENUM(
        "CHEST", "BACK", "SHOULDERS", "LEGS", "ARMS", "CORE", "OTHER",
        name="muscle_group_enum",
    )
    muscle_group_enum.create(bind, checkfirst=True)
    # SQLAlchemy's own before_create DDL event will try to CREATE TYPE
    # again when this enum object is reused as a column type below; that
    # second create is not checkfirst-safe, so without this flag a clean
    # database raises DuplicateObject. See spec note on enum creation.
    muscle_group_enum.create_type = False

    op.create_table(
        "exercises",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column("name", sa.String(150), nullable=False),
        sa.Column("muscle_group", muscle_group_enum, nullable=False),
        sa.Column("is_custom", sa.Boolean(), nullable=False, server_default=sa.false()),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=True,
        ),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_exercises_name", "exercises", ["name"])

    op.create_table(
        "workout_sessions",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "user_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column("date", sa.Date(), nullable=False),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("ended_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
    )
    op.create_index("ix_workout_sessions_user_id", "workout_sessions", ["user_id"])
    op.create_index("ix_workout_sessions_date", "workout_sessions", ["date"])

    op.create_table(
        "workout_exercises",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "session_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("workout_sessions.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column(
            "exercise_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("exercises.id", ondelete="RESTRICT"), nullable=False,
        ),
        sa.Column("order_index", sa.Integer(), nullable=False, server_default="0"),
    )
    op.create_index("ix_workout_exercises_session_id", "workout_exercises", ["session_id"])

    op.create_table(
        "exercise_sets",
        sa.Column("id", postgresql.UUID(as_uuid=True), primary_key=True),
        sa.Column(
            "workout_exercise_id", postgresql.UUID(as_uuid=True),
            sa.ForeignKey("workout_exercises.id", ondelete="CASCADE"), nullable=False,
        ),
        sa.Column("set_number", sa.Integer(), nullable=False),
        sa.Column("weight_kg", sa.Float(), nullable=False),
        sa.Column("reps", sa.Integer(), nullable=False),
        sa.Column("rpe", sa.Float(), nullable=True),
        sa.Column("rir", sa.Integer(), nullable=True),
        sa.Column("notes", sa.Text(), nullable=True),
        sa.Column("is_pr", sa.Boolean(), nullable=False, server_default=sa.false()),
    )
    op.create_index(
        "ix_exercise_sets_workout_exercise_id", "exercise_sets", ["workout_exercise_id"]
    )


def downgrade() -> None:
    op.drop_table("exercise_sets")
    op.drop_table("workout_exercises")
    op.drop_table("workout_sessions")
    op.drop_table("exercises")
    op.execute("DROP TYPE IF EXISTS muscle_group_enum")
